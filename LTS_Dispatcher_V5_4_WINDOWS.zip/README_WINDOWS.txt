LTS DISPATCHER V3.6 - WINDOWS

Same Google Sheets / TP setup as the Mac V3.6 version.

Main Google Sheet:
- Contacts
- Send History
- Settings
- Users
- Import Review

Separate TP Google Sheet:
- VIE-LTS-TP Liste
- daily tabs DD.MM.YYYY
- B = SCHICHT
- C = NAME
- first driver row = 4

GOOGLE SHEETS SETUP:
1. Apps Script Web App URL
2. API Token
3. TP Spreadsheet ID

The TP Spreadsheet ID is the part between /d/ and /edit in:
https://docs.google.com/spreadsheets/d/SPREADSHEET_ID/edit

Windows:
- WhatsApp Desktop for WhatsApp sending/calls
- Microsoft Outlook for email

First install:
1. Run INSTALL_WINDOWS.bat
2. Run START_WINDOWS.bat

Use the V3.6 Google_Apps_Script_Code.gs from this ZIP.
If updating an old deployment:
Deploy -> Manage deployments -> Edit -> New version -> Deploy
Keep the same /exec URL and API token.


V3.7 - STRONG DRIVER MATCHING
=============================

Shift matching is now much more reliable.

MATCHING PRIORITY
-----------------
1. Driver ID
2. Phone number
3. Email address
4. Exact normalized name
5. Name ignoring LTS / accents / punctuation / spacing
6. Safe fuzzy spelling match

Examples that now match:
LTS Agholor Blessing
Agholor Blessing

Gödi Dorián
Godi Dorian

Small spelling mistakes can be matched only when there is one strong,
unambiguous contact result.

DRIVER ID HELPER
----------------
When Dispatcher adds or edits a TP shift, it stores:
- Driver ID
- Phone
- Email

in hidden helper columns X, Y and Z of the daily TP sheet.

The visible TP layout stays unchanged:
B = SCHICHT
C = NAME

This means future matching does not depend on the driver name spelling.

OLD TP ROWS
-----------
Old/manual TP rows without a stored Driver ID still use the fallback matching:
phone/email/name/fuzzy name.

IMPORTANT - APPS SCRIPT UPDATE
------------------------------
Replace your current Apps Script with the V3.7 Google_Apps_Script_Code.gs.

Then:
Deploy -> Manage deployments -> Edit -> New version -> Deploy

Keep the same /exec URL, API token and TP Spreadsheet ID.


V3.8 - REMINDER BEFORE: DAYS / HOURS / MINUTES
==============================================

Shift Reminders now has two controls:

Reminder before: [amount] [unit]

Units:
- Day(s)
- Hour(s)
- Minute(s)

Examples:
1 Day(s)     = send 24 hours before the actual TP shift start
1 Hour(s)    = send 1 hour before the actual TP shift start
30 Minute(s) = send 30 minutes before the actual TP shift start
15 Minute(s) = send 15 minutes before the actual TP shift start

The driver-facing report time rule is unchanged:
report_time = actual TP start minus 30 minutes.

Only the message SEND TIME is controlled by Reminder before.


LTS DISPATCHER V4.0 - CLEAN CONTACTS / AUTO SYNC / QR PROFILES
===============================================================

CONTACTS
--------
Final visible columns:
Driver ID
Name
WhatsApp Phone
Email
Status
Last Contacted
Notes

Preferred and Group are removed.
Legacy personal-file / QR-file columns are not used.

Google Contacts are synchronized by header name and the new Apps Script
normalizes the Contacts sheet to the final layout above.

AUTO SYNC
---------
When Google mode is active, Dispatcher refreshes Contacts automatically
about every 15 seconds. REFRESH GOOGLE still forces an immediate refresh.
Manual Google Sheet changes such as Notes are pulled into Dispatcher.

ATTACHMENTS
-----------
Normal messages support COMMON FILES only.
Personal attachment folders and driver-specific attachment checkboxes are removed.

QR
--
QR is separate from normal messaging.

VIEW QR
- creates the driver's QR card and opens it locally.

SEND QR
- generates each selected driver's QR card automatically
- QR payload: D:<Driver ID>
- sends it through WhatsApp
- no Google Drive QR file or manual filename is required

QR card design:
- white square background
- large centered QR
- driver name centered below
- Driver ID centered below the name
- bold black text

CHECKBOXES
----------
Driver and Shift Reminder tables use larger/taller rows.
Double-clicking the Shift Reminder checkbox no longer opens Edit Shift.

IMPORTANT GOOGLE UPDATE
-----------------------
This version requires the included Google_Apps_Script_Code.gs.

Replace the current Apps Script code, KEEP YOUR EXISTING API TOKEN, then:
Deploy -> Manage deployments -> Edit -> New version -> Deploy

Keep the same /exec URL and TP Spreadsheet ID.


V4.1 - SMOOTH SYNC / UNIVERSAL SELECTION / QR CACHE
====================================================

GOOGLE AUTO SYNC
----------------
Automatic Google contact sync now runs in a background thread.
The UI is no longer blocked while Google responds.

Automatic check interval: about 60 seconds.
The Contacts table is rebuilt only when Google data actually changed.
REFRESH GOOGLE remains available for immediate manual refresh.

UNIVERSAL SELECTION
-------------------
Drivers:
- click checkbox = check/uncheck
- header checkbox = all visible / clear visible
- Cmd+A (Mac) / Ctrl+A (Windows) = check all visible
- Cmd+Shift+A / Ctrl+Shift+A = clear visible
- Space = toggle highlighted row(s)

Shift Reminders:
- same select-all / clear shortcuts
- Space toggles highlighted Ready rows
- checkbox double-click does not open Edit Shift

Scheduled:
- large checkbox column
- master checkbox
- SELECT ALL
- CLEAR
- DELETE CHECKED
- Cmd+A / Ctrl+A = check all scheduled jobs
- Cmd+Shift+A / Ctrl+Shift+A = clear checks
- Space = toggle highlighted jobs
- Delete / Backspace = delete checked jobs
- multiple scheduled jobs can be deleted in one confirmation

QR CACHE
--------
QR cards are generated automatically in the background when:
- a driver is added
- a driver is edited
- Google sync detects new/changed contacts

SEND QR uses the cached QR immediately when available.
If a QR is missing or stale, Dispatcher regenerates it automatically.


No QR filenames or folders need to be managed by the user.


V4.2 - SELECTED QR GENERATION / QR FOLDER IN APP
=================================================

QR STORAGE
----------
Generated QR files are now stored inside the Dispatcher program folder:

Mac example:
LTS_Dispatcher_V4_2_MAC/QR/

Windows example:
LTS_Dispatcher_V4_2_WINDOWS/QR/

No hidden home-folder QR storage is used for generated QR cards.

GENERATE QR CODE
----------------
The old REBUILD ALL QR button is replaced with:
GENERATE QR CODE

It uses the checked driver selection:
- 1 checked driver  -> generates 1 QR
- 10 checked drivers -> generates 10 QR codes
- all drivers checked -> generates all of them

OPEN QR FOLDER
--------------
OPEN QR FOLDER opens the QR folder manually.
Generating QR codes does NOT automatically open the folder.

SEND QR
-------
SEND QR still uses the correct generated/cached QR automatically.
If the QR is missing, it is generated automatically before sending.


V4.3 - QR SELECTION FIX
=======================

GENERATE QR CODE now acts ONLY on checked drivers.

Examples:
- 1 checked driver = 1 QR generated
- 2 checked drivers = 2 QR codes generated
- 10 checked drivers = 10 QR codes generated
- all checked = all generated

Simply highlighting/selecting a row is not enough; the checkbox controls QR generation.

Google refresh/connect no longer generates QR cards for the entire driver database.
SEND QR can still generate a missing QR automatically when needed.
Adding/editing an individual driver can still refresh that driver's QR only.

Existing QR files already in the QR folder are not deleted automatically.


V4.4 - FLEXIBLE SHIFT TIMES
===========================

ADD / EDIT SHIFT time fields are now editable.

- Existing shift times are preserved exactly when editing.
- The time dropdown still offers quick 15-minute suggestions.
- You can type any valid HH:MM time manually.
- New shifts no longer force 04:30 / 09:00 as default values.

Examples:
05:10
06:25
09:40
13:55

The saved TP format remains:
VIE<start>-<end>


V4.5 - SHIFT EDIT / 24-HOUR TIMES / DRIVER SEARCH
==================================================

EDIT SHIFT
----------
If exactly one shift checkbox is checked, EDIT SHIFT now uses that row even
when the row was not separately highlighted.

Clicking a shift checkbox also highlights that row.

TIME SELECTION
--------------
Start and End dropdowns now contain the full 24-hour day every 15 minutes:

00:00
00:15
00:30
...
23:30
23:45

You may still type any valid HH:MM time manually.

DRIVER SEARCH
-------------
The Driver field in ADD SHIFT / EDIT SHIFT is now searchable.
Type part of the driver's name or the Driver ID to filter the list, then choose
the matching driver.


V4.6 - DRIVER SEARCH TYPING FIX
================================

The driver search field in ADD SHIFT / EDIT SHIFT no longer opens the dropdown
after every typed letter.

You can now type the full driver name or Driver ID normally without interruption.

The list is still filtered in the background while you type.
When you want to see the filtered results:
- click the dropdown arrow, or
- press the Down arrow key

Then choose the driver.


V4.7 - LIVE DRIVER SEARCH RESULTS
=================================

ADD SHIFT / EDIT SHIFT driver search now works like autocomplete:

- keep typing the full name or Driver ID normally
- matching results appear automatically below the field
- the result list does NOT steal typing focus
- click a result to choose it
- Down Arrow moves into the result list
- Enter can accept a unique match
- Escape closes the result list

This replaces the previous combobox behavior that interrupted typing.


V4.8 - CLEAN SHIFT EDITOR
=========================

Removed the hint/help text from ADD SHIFT / EDIT SHIFT.
The dialog now shows only the driver search, start/end time fields, and action buttons.


V4.9 - QR EXPLANATION MESSAGE
=============================

SEND QR now sends the QR image together with a short explanation:

Hallo <Name> 👋

Das ist dein persönlicher LTS QR-Code.
Er dient zur schnellen Identifikation im LTS-System.

Bitte speichere ihn auf deinem Handy und halte ihn bei Bedarf zum Scannen bereit.

Normal SEND messages are unchanged.


V5.0 - OPTIONAL DRIVER QR ATTACHMENT
====================================

Message / Attachments now includes:

[ ] Attach common files
[ ] Attach driver QR

When Attach driver QR is enabled:
- every selected driver receives their own QR
- the QR is generated automatically if missing
- common files and driver QR can be used together
- scheduled messages remember the QR attachment setting

When Attach driver QR is disabled:
- normal message sending works exactly as before

The separate VIEW QR / SEND QR / GENERATE QR CODE tools remain available.


V5.1 - SHIFT REMINDER SEND NOW
==============================

Shift Reminders now has two separate actions:

SCHEDULE REMINDERS
- uses the selected Reminder before setting
- examples: 1 Day(s), 1 Hour(s), 30 Minute(s)

SEND NOW
- sends the checked Ready shift reminders immediately
- uses the selected WhatsApp / Email channel
- does not create a scheduled job

The driver-facing report time remains:
actual TP start minus 30 minutes.


V5.2 - TAB BAR CLEANUP + HISTORY SEARCH
=======================================

Bottom Dispatcher send bar:
- shown only on the Dispatcher tab
- hidden on Shift Reminders
- hidden on Scheduled
- hidden on History

History:
- added Search field
- search by Driver Name
- search by Driver ID
- results filter instantly while typing
- up to 500 matching history rows are shown


V5.3 - SHIFT REMINDER SEARCH
============================

Shift Reminders now has a Search field above the shift list.

Search works instantly by:
- Driver Name
- Driver ID

The checkbox header / Select All shortcut applies to the currently visible
filtered Ready shifts, so searching and selecting a group works naturally.

V5.4 - DISPATCHER LOWER SEND BAR FIX
------------------------------------
- Fixed the Dispatcher lower send bar disappearing after switching to another tab and returning.
- The send bar is restored in the correct Tkinter pack order before the expanding notebook.
- No Google Apps Script redeployment is required for this update.
