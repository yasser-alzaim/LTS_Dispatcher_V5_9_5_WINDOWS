/**
 * LTS Dispatcher Google Sheets Backend
 *
 * Put this code in Extensions -> Apps Script inside your LTS Google Sheet.
 * Change API_TOKEN below before deployment.
 *
 * Deploy:
 *   Deploy -> New deployment -> Web app
 *   Execute as: Me
 *   Who has access: Anyone
 * Copy the /exec URL into LTS Dispatcher.
 */

const API_TOKEN = 'CHANGE_THIS_TO_A_LONG_RANDOM_TOKEN';

const CONTACTS_SHEET = 'Contacts';
const HISTORY_SHEET = 'Send History';

const CONTACT_HEADERS = [
  'Driver ID','Name','WhatsApp Phone','Email','Status','Last Contacted','Notes'
];

const FIELD_TO_HEADER = {
  id:'Driver ID',
  name:'Name',
  phone:'WhatsApp Phone',
  email:'Email',
  status:'Status',
  last_contacted:'Last Contacted',
  notes:'Notes'
};

function doGet(e) {
  return jsonOut({ok:true, service:'LTS Dispatcher Google Sheets Backend'});
}

function doPost(e) {
  try {
    const body = JSON.parse((e.postData && e.postData.contents) || '{}');

    if (!body.token || body.token !== API_TOKEN) {
      return jsonOut({ok:false,error:'Unauthorized: API token is incorrect.'});
    }

    const action = String(body.action || '');

    if (action === 'ping') {
      return jsonOut({ok:true, spreadsheet:SpreadsheetApp.getActive().getName()});
    }

    if (action === 'getContacts') {
      return jsonOut({ok:true, contacts:getContacts_()});
    }

    if (action === 'syncContactLayout') {
      normalizeContactLayout_();
      return jsonOut({ok:true});
    }

    if (action === 'addDriver') {
      addDriver_(body.driver || {});
      return jsonOut({ok:true});
    }

    if (action === 'editDriver') {
      editDriver_(String(body.original_id || ''), body.driver || {});
      return jsonOut({ok:true});
    }

    if (action === 'deleteDriver') {
      deleteDriver_(String(body.driver_id || ''));
      return jsonOut({ok:true});
    }

    if (action === 'updateField') {
      updateField_(
        String(body.driver_id || ''),
        String(body.key || ''),
        body.value
      );
      return jsonOut({ok:true});
    }

    if (action === 'appendHistory') {
      appendHistory_(body.history || {});
      return jsonOut({ok:true});
    }

    if (action === 'getShifts') {
      return jsonOut({
        ok:true,
        shifts:getShifts_(
          String(body.date || ''),
          String(body.tp_spreadsheet_id || '')
        )
      });
    }

    if (action === 'addShift') {
      addShift_(
        String(body.date || ''),
        String(body.name || ''),
        String(body.shift_text || ''),
        String(body.driver_id || ''),
        String(body.phone || ''),
        String(body.email || ''),
        String(body.tp_spreadsheet_id || '')
      );
      return jsonOut({ok:true});
    }

    if (action === 'editShift') {
      editShift_(
        String(body.date || ''),
        Number(body.row_number || 0),
        String(body.name || ''),
        String(body.shift_text || ''),
        String(body.driver_id || ''),
        String(body.phone || ''),
        String(body.email || ''),
        String(body.tp_spreadsheet_id || '')
      );
      return jsonOut({ok:true});
    }

    if (action === 'deleteShift') {
      deleteShift_(
        String(body.date || ''),
        Number(body.row_number || 0),
        String(body.tp_spreadsheet_id || '')
      );
      return jsonOut({ok:true});
    }

    return jsonOut({ok:false,error:'Unknown action: ' + action});
  } catch (err) {
    return jsonOut({ok:false,error:String(err && err.message ? err.message : err)});
  }
}

function jsonOut(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

function sheet_(name) {
  const ss = SpreadsheetApp.getActive();
  const sh = ss.getSheetByName(name);
  if (!sh) throw new Error('Missing sheet: ' + name);
  return sh;
}

function headerMap_(sh) {
  const lastCol=Math.max(sh.getLastColumn(),1);
  const headers=sh.getRange(1,1,1,lastCol).getDisplayValues()[0];
  const map={};
  headers.forEach((h,i)=>{
    const key=String(h || '').trim();
    if (key) map[key]=i+1;
  });
  return map;
}

function normalizeContactLayout_() {
  const sh=sheet_(CONTACTS_SHEET);
  const lastRow=Math.max(sh.getLastRow(),1);
  const lastCol=Math.max(sh.getLastColumn(),1);
  const values=sh.getRange(1,1,lastRow,lastCol).getDisplayValues();
  const oldHeaders=values[0] || [];
  const oldMap={};
  oldHeaders.forEach((h,i)=>{
    const key=String(h || '').trim();
    if (key) oldMap[key]=i;
  });

  const rows=[];
  for (let r=1;r<values.length;r++) {
    const source=values[r];
    const out=CONTACT_HEADERS.map(h => {
      const idx=oldMap[h];
      return idx === undefined ? '' : (source[idx] || '');
    });
    if (String(out[0] || '').trim() || String(out[1] || '').trim()) rows.push(out);
  }

  sh.clearContents();
  sh.getRange(1,1,1,CONTACT_HEADERS.length).setValues([CONTACT_HEADERS]);
  if (rows.length) {
    sh.getRange(2,1,rows.length,CONTACT_HEADERS.length).setValues(rows);
  }

  // Remove unused legacy columns such as Preferred, Group, Language,
  // personal-file references, etc. The final Contacts sheet is intentionally simple.
  if (sh.getMaxColumns() > CONTACT_HEADERS.length) {
    sh.deleteColumns(CONTACT_HEADERS.length+1, sh.getMaxColumns()-CONTACT_HEADERS.length);
  }
  if (sh.getMaxColumns() < CONTACT_HEADERS.length) {
    sh.insertColumnsAfter(sh.getMaxColumns(), CONTACT_HEADERS.length-sh.getMaxColumns());
  }

  SpreadsheetApp.flush();
  return {sh:sh,map:headerMap_(sh)};
}

function ensureContactHeaders_() {
  const sh=sheet_(CONTACTS_SHEET);
  const map=headerMap_(sh);
  const exact=
    Object.keys(map).length===CONTACT_HEADERS.length &&
    CONTACT_HEADERS.every((h,i)=>map[h]===i+1);
  return exact ? {sh:sh,map:map} : normalizeContactLayout_();
}

function getContacts_() {
  const sh=sheet_(CONTACTS_SHEET);
  const values=sh.getDataRange().getDisplayValues();
  if (values.length < 2) return [];

  const headers=values[0];
  const out=[];
  for (let r=1;r<values.length;r++) {
    const row=values[r];
    const obj={};
    headers.forEach((h,i) => {
      if (h) obj[h]=row[i] || '';
    });
    if (String(obj['Driver ID'] || '').trim() || String(obj['Name'] || '').trim()) {
      out.push(obj);
    }
  }
  return out;
}

function findDriverRow_(sh,idCol,driverId) {
  if (!driverId) throw new Error('Driver ID is required.');
  const last=sh.getLastRow();
  if (last < 2) return -1;
  const ids=sh.getRange(2,idCol,last-1,1).getDisplayValues();
  for (let i=0;i<ids.length;i++) {
    if (String(ids[i][0] || '').trim() === driverId) return i+2;
  }
  return -1;
}

function driverValue_(driver,key) {
  const v=driver[key];
  return v === undefined || v === null ? '' : String(v);
}

function addDriver_(driver) {
  const x=ensureContactHeaders_();
  const sh=x.sh, map=x.map;
  const id=driverValue_(driver,'id').trim();
  const name=driverValue_(driver,'name').trim();
  if (!id || !name) throw new Error('Driver ID and Name are required.');

  if (findDriverRow_(sh,map['Driver ID'],id) !== -1) {
    throw new Error('Driver ID already exists: ' + id);
  }

  const row=Math.max(sh.getLastRow()+1,2);
  Object.keys(FIELD_TO_HEADER).forEach(key => {
    const header=FIELD_TO_HEADER[key];
    sh.getRange(row,map[header]).setValue(driverValue_(driver,key));
  });
}

function editDriver_(originalId,driver) {
  const x=ensureContactHeaders_();
  const sh=x.sh, map=x.map;
  const row=findDriverRow_(sh,map['Driver ID'],originalId);
  if (row === -1) throw new Error('Driver ID not found: ' + originalId);

  const newId=driverValue_(driver,'id').trim();
  const name=driverValue_(driver,'name').trim();
  if (!newId || !name) throw new Error('Driver ID and Name are required.');

  if (newId !== originalId) {
    const duplicate=findDriverRow_(sh,map['Driver ID'],newId);
    if (duplicate !== -1) throw new Error('Driver ID already exists: ' + newId);
  }

  Object.keys(FIELD_TO_HEADER).forEach(key => {
    const header=FIELD_TO_HEADER[key];
    sh.getRange(row,map[header]).setValue(driverValue_(driver,key));
  });
}

function deleteDriver_(driverId) {
  const x=ensureContactHeaders_();
  const sh=x.sh, map=x.map;
  const row=findDriverRow_(sh,map['Driver ID'],driverId);
  if (row === -1) throw new Error('Driver ID not found: ' + driverId);
  sh.deleteRow(row);
}

function updateField_(driverId,key,value) {
  const header=FIELD_TO_HEADER[key];
  if (!header) throw new Error('Unsupported field: ' + key);

  const x=ensureContactHeaders_();
  const sh=x.sh, map=x.map;
  const row=findDriverRow_(sh,map['Driver ID'],driverId);
  if (row === -1) throw new Error('Driver ID not found: ' + driverId);

  sh.getRange(row,map[header]).setValue(value === undefined || value === null ? '' : value);
}

function appendHistory_(h) {
  const sh=sheet_(HISTORY_SHEET);
  const headers=['Timestamp','Driver ID','Name','Channel','Action','Result','Detail','Follow-up'];

  if (sh.getLastRow() === 0) {
    sh.getRange(1,1,1,headers.length).setValues([headers]);
  }

  const map={};
  headers.forEach(k => map[k] = h[k] === undefined || h[k] === null ? '' : h[k]);

  sh.appendRow(headers.map(k => map[k]));
}


/* TP LISTE DAILY SHEETS
   Sheet: DD.MM.YYYY
   B = SCHICHT
   C = NAME
   Data starts row 4
*/

function tpSheetName_(isoDate) {
  const m=String(isoDate || '').match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!m) throw new Error('Invalid date. Expected YYYY-MM-DD.');
  return m[3] + '.' + m[2] + '.' + m[1];
}

function tpSpreadsheet_(spreadsheetId) {
  const id=String(spreadsheetId || '').trim();
  if (id) {
    return SpreadsheetApp.openById(id);
  }
  return SpreadsheetApp.getActive();
}

function tpSheet_(isoDate, spreadsheetId) {
  const name=tpSheetName_(isoDate);
  const ss=tpSpreadsheet_(spreadsheetId);
  const sh=ss.getSheetByName(name);
  if (!sh) {
    throw new Error(
      'No daily TP sheet "' + name + '" exists in spreadsheet "' + ss.getName() + '".'
    );
  }
  return sh;
}

function shiftStartMinutes_(shiftText) {
  const m=String(shiftText || '').match(/([01]?\d|2[0-3]):([0-5]\d)/);
  if (!m) return 999999;
  return Number(m[1])*60 + Number(m[2]);
}

function ensureTpIdentityColumns_(sh) {
  // X/Y/Z are hidden helper columns used only by LTS Dispatcher.
  // Visible TP layout (including B=SCHICHT and C=NAME) stays unchanged.
  const needed=26;
  if (sh.getMaxColumns() < needed) {
    sh.insertColumnsAfter(sh.getMaxColumns(), needed-sh.getMaxColumns());
  }

  sh.getRange(1,24).setValue('LTS Driver ID');
  sh.getRange(1,25).setValue('LTS Phone');
  sh.getRange(1,26).setValue('LTS Email');

  try {
    sh.hideColumns(24,3);
  } catch (e) {}
}

function getShifts_(isoDate, spreadsheetId) {
  const sh=tpSheet_(isoDate, spreadsheetId);
  const last=Math.max(sh.getLastRow(),3);
  if (last < 4) return [];
  ensureTpIdentityColumns_(sh);
  const values=sh.getRange(4,2,last-3,25).getDisplayValues();
  const out=[];
  values.forEach((row,i)=>{
    const shiftText=String(row[0] || '').trim();   // B
    const name=String(row[1] || '').trim();        // C
    const driverId=String(row[22] || '').trim();   // X
    const phone=String(row[23] || '').trim();      // Y
    const email=String(row[24] || '').trim();      // Z
    if (name) out.push({
      row_number:i+4,
      shift_text:shiftText,
      name:name,
      driver_id:driverId,
      phone:phone,
      email:email
    });
  });
  out.sort((a,b)=>{
    const d=shiftStartMinutes_(a.shift_text)-shiftStartMinutes_(b.shift_text);
    return d !== 0 ? d : a.name.localeCompare(b.name);
  });
  return out;
}

function findShiftInsertRow_(sh,shiftText) {
  const mins=shiftStartMinutes_(shiftText);
  const last=Math.max(sh.getLastRow(),3);
  for (let row=4;row<=last;row++) {
    const existing=String(sh.getRange(row,2).getDisplayValue() || '').trim();
    const name=String(sh.getRange(row,3).getDisplayValue() || '').trim();
    if (!existing && !name) continue;
    if (mins < shiftStartMinutes_(existing)) return row;
  }
  return Math.max(last+1,4);
}

function addShift_(isoDate,name,shiftText,driverId,phone,email,spreadsheetId) {
  if (!name || !shiftText) throw new Error('Driver and shift are required.');
  const sh=tpSheet_(isoDate, spreadsheetId);
  ensureTpIdentityColumns_(sh);
  const row=findShiftInsertRow_(sh,shiftText);
  sh.insertRowBefore(row);
  sh.getRange(row,2).setValue(shiftText);
  sh.getRange(row,3).setValue(name);
  sh.getRange(row,24).setValue(driverId);
  sh.getRange(row,25).setValue(phone);
  sh.getRange(row,26).setValue(email);
}

function editShift_(isoDate,rowNumber,name,shiftText,driverId,phone,email,spreadsheetId) {
  if (rowNumber < 4) throw new Error('Invalid TP-list row.');
  const sh=tpSheet_(isoDate, spreadsheetId);
  ensureTpIdentityColumns_(sh);
  if (rowNumber > sh.getLastRow()) throw new Error('TP-list row does not exist.');

  const lastCol=Math.max(sh.getLastColumn(),26);
  const values=sh.getRange(rowNumber,1,1,lastCol).getValues()[0];
  values[1]=shiftText;
  values[2]=name;
  values[23]=driverId;
  values[24]=phone;
  values[25]=email;

  sh.deleteRow(rowNumber);
  const target=findShiftInsertRow_(sh,shiftText);
  sh.insertRowBefore(target);
  sh.getRange(target,1,1,lastCol).setValues([values]);
}

function deleteShift_(isoDate,rowNumber,spreadsheetId) {
  if (rowNumber < 4) throw new Error('Invalid TP-list row.');
  const sh=tpSheet_(isoDate, spreadsheetId);
  if (rowNumber > sh.getLastRow()) throw new Error('TP-list row does not exist.');
  sh.deleteRow(rowNumber);
}
