@echo off
title LTS Dispatcher
cd /d "%~dp0"
where py >nul 2>&1
if %errorlevel%==0 (
    py -3 LTS_Dispatcher.py
) else (
    python LTS_Dispatcher.py
)
if errorlevel 1 (
    echo.
    echo LTS Dispatcher stopped with an error.
    echo Run INSTALL_WINDOWS.bat first if needed.
    pause
)
