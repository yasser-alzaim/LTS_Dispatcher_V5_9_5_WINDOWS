@echo off
title LTS Dispatcher - Install
cd /d "%~dp0"
echo Installing LTS Dispatcher for Windows...
echo.
where py >nul 2>&1
if %errorlevel%==0 (
    py -3 -m pip install --upgrade pip
    py -3 -m pip install -r requirements.txt
) else (
    python -m pip install --upgrade pip
    python -m pip install -r requirements.txt
)
echo.
echo Installation finished.
echo.
echo WhatsApp Desktop must be installed and logged in.
echo Outlook must be installed and signed in for email.
echo.
pause
