@echo off
setlocal
cd /d "%~dp0"
echo.
echo ==========================================
echo   LTS Dispatcher - Windows installation
echo ==========================================
echo.
where py >nul 2>nul
if %errorlevel%==0 (
  set "PY=py -3"
) else (
  where python >nul 2>nul
  if errorlevel 1 (
    echo Python 3 was not found.
    echo Install Python 3.11 or newer from https://www.python.org/downloads/windows/
    echo IMPORTANT: tick "Add python.exe to PATH" during installation.
    pause
    exit /b 1
  )
  set "PY=python"
)
%PY% -m pip install --upgrade pip
if errorlevel 1 goto :fail
%PY% -m pip install -r requirements_windows.txt
if errorlevel 1 goto :fail

echo.
echo Installation complete.
echo.
echo Before starting:
echo  1. Install WhatsApp Desktop from Microsoft Store and sign in.
echo  2. If you use email, install/sign in to classic Microsoft Outlook.
echo  3. Run START_WINDOWS.bat.
echo.
pause
exit /b 0
:fail
echo.
echo Installation failed. Check the error above.
pause
exit /b 1
