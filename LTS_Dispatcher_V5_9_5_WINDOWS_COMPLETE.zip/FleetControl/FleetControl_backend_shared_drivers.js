// FleetControl master status display: V5.9.4

const APP = {
  // Sessions stay active until explicit logout, deactivation or admin password reset.
  DATE_FORMAT: 'dd.MM.yyyy',
  TIME_FORMAT: 'HH:mm',
  DAILY_HEADER_ROW: 4,
  DAILY_DATA_START: 5,
  ROLES: { ADMIN: 'ADMIN', USER: 'USER' }
};

/* ---------- PERFORMANCE CACHE ---------- */

// SpreadsheetApp.openById() is expensive. Reuse the same workbook object
// during one Apps Script execution.
let _BOOK_CACHE = null;
let _MASTER_INDEX_MEMORY = null;

const PERF = {
  MASTER_CACHE_KEY: 'FLEET_STATIC_MASTER_INDEX_V2',
  OPEN_CACHE_KEY: 'FLEET_OPEN_ASSIGNMENTS_V1',
  MASTER_CACHE_SECONDS: 300,
  OPEN_CACHE_SECONDS: 120,
  REPLACEMENT_TXN_CACHE_SECONDS: 21600
};

function clearFleetPerformanceCache() {
  _MASTER_INDEX_MEMORY = null;
  const cache = CacheService.getScriptCache();
  cache.remove(PERF.MASTER_CACHE_KEY);
  cache.remove(PERF.OPEN_CACHE_KEY);
  return {ok:true};
}

function clearMasterCache_() {
  _MASTER_INDEX_MEMORY = null;
  try {
    CacheService.getScriptCache().remove(PERF.MASTER_CACHE_KEY);
  } catch (e) {}
}

function clearOpenAssignmentsCache_() {
  try {
    CacheService.getScriptCache().remove(PERF.OPEN_CACHE_KEY);
  } catch (e) {}
}

function getMasterIndex_() {
  if (_MASTER_INDEX_MEMORY) return _MASTER_INDEX_MEMORY;

  const cache = CacheService.getScriptCache();
  const index = {
    Drivers: {},
    Cars: {},
    Scanners: {}
  };

  // Drivers are intentionally read fresh on every web request. Dispatcher can
  // update the shared Drivers sheet from a different Apps Script project, and
  // that external write cannot clear this project's CacheService. Keeping
  // Drivers out of the cross-request cache makes those changes visible
  // immediately to FleetControl while Cars/Scanners stay cached for speed.
  readMaster_('Drivers').forEach(r => {
    const key = String(r[0] || '').trim().toUpperCase();
    if (key) index.Drivers[key] = [r[0], r[1], r[2]];
  });

  let staticLoaded = false;
  try {
    const raw = cache.get(PERF.MASTER_CACHE_KEY);
    if (raw) {
      const saved = JSON.parse(raw);
      index.Cars = saved.Cars || {};
      index.Scanners = saved.Scanners || {};
      staticLoaded = true;
    }
  } catch (e) {}

  if (!staticLoaded) {
    readMaster_('Cars').forEach(r => {
      const key = String(r[0] || '').trim().toUpperCase();
      if (key) index.Cars[key] = [r[0], r[1], r[2]];
    });

    readMaster_('Scanners').forEach(r => {
      const key = String(r[0] || '').trim().toUpperCase();
      if (key) index.Scanners[key] = [r[0], r[1]];
    });

    try {
      cache.put(
        PERF.MASTER_CACHE_KEY,
        JSON.stringify({Cars:index.Cars, Scanners:index.Scanners}),
        PERF.MASTER_CACHE_SECONDS
      );
    } catch (e) {}
  }

  _MASTER_INDEX_MEMORY = index;
  return index;
}

function readOpenAssignmentsCache_() {
  try {
    const raw = CacheService.getScriptCache().get(PERF.OPEN_CACHE_KEY);
    if (!raw) return null;

    const saved = JSON.parse(raw);
    const book = getBook_();
    const out = [];

    saved.forEach(item => {
      const sheet = book.getSheetByName(item.sheetName);
      if (!sheet) return;

      out.push({
        sheet: sheet,
        row: Number(item.row),
        values: item.values
      });
    });

    return out;
  } catch (e) {
    return null;
  }
}

function writeOpenAssignmentsCache_(open) {
  const cache = CacheService.getScriptCache();

  try {
    const saved = open.map(x => ({
      sheetName: x.sheet.getName(),
      row: x.row,
      values: x.values
    }));

    cache.put(
      PERF.OPEN_CACHE_KEY,
      JSON.stringify(saved),
      PERF.OPEN_CACHE_SECONDS
    );
  } catch (e) {
    // Never leave an older cached assignment list active after a failed write.
    // The next read will rebuild the list directly from the daily sheets.
    try { cache.remove(PERF.OPEN_CACHE_KEY); } catch (_) {}
  }
}


function doGet() {
  return HtmlService.createHtmlOutput(
    '<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"></head>' +
    '<body style="font-family:Arial,sans-serif;padding:24px"><h2>Fleet QR API</h2>' +
    '<p>Backend is online. Open the GitHub Pages Fleet QR site to use the scanner.</p></body></html>'
  ).setTitle('Fleet QR API');
}

/**
 * Cross-origin bridge for the GitHub Pages frontend.
 * The browser submits a normal HTML form into a hidden iframe.
 * The response posts JSON back to the parent page with postMessage(),
 * avoiding fetch/XHR CORS limitations of Apps Script web apps.
 */
function doPost(e) {
  let requestId = '';
  let response;

  try {
    const raw = e && e.parameter ? String(e.parameter.payload || '') : '';
    if (!raw) throw new Error('Missing request payload.');

    const req = JSON.parse(raw);
    requestId = String(req.id || '');
    const action = String(req.action || '');
    const args = Array.isArray(req.args) ? req.args : [];

    const result = apiDispatch_(action, args);
    response = { fleetQrApi:true, id:requestId, ok:true, result:result };
  } catch (err) {
    response = {
      fleetQrApi:true,
      id:requestId,
      ok:false,
      error:err && err.message ? err.message : String(err)
    };
  }

  // Escape '<' so user-provided values can never terminate the script tag.
  const safeJson = JSON.stringify(response)
    .replace(/</g, '\\u003c')
    .replace(/\u2028/g, '\\u2028')
    .replace(/\u2029/g, '\\u2029');

  const html = '<!doctype html><html><body><script>' +
    'window.top.postMessage(' + safeJson + ', "*");' +
    '<\/script></body></html>';

  return HtmlService.createHtmlOutput(html)
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function apiDispatch_(action, args) {
  const allowed = {
    testConnection: testConnection,
    login: login,
    resumeSession: resumeSession,
    logout: logout,
    dashboard: dashboard,
    startShift: startShift,
    returnShift: returnShift,
    replaceScanner: replaceScanner,
    replaceScannerAuto: replaceScannerAuto,
    replaceCar: replaceCar,
    replaceCarAuto: replaceCarAuto,
    lookupActiveAssignment: lookupActiveAssignment,
    replacementHistory: replacementHistory,
    stillOut: stillOut,
    recentHistory: recentHistory,
    listUsers: listUsers,
    createUser: createUser,
    resetUserPassword: resetUserPassword,
    setUserActive: setUserActive,
    getMasterData: getMasterData,
    upsertDriver: upsertDriver,
    upsertCar: upsertCar,
    upsertScanner: upsertScanner,
    changeMyPassword: changeMyPassword
  };

  const fn = allowed[action];
  if (!fn) throw new Error('Unknown API action.');
  return fn.apply(null, args);
}

/* ---------- CONFIGURATION ---------- */

function configure() {
  const active = SpreadsheetApp.getActiveSpreadsheet();
  if (!active) throw new Error('Open Apps Script from the target Google Sheet, then run configure() again.');
  PropertiesService.getScriptProperties().setProperty('SPREADSHEET_ID', active.getId());
  setupWorkbook_();
  clearFleetPerformanceCache();
  return {
    ok: true,
    spreadsheet: active.getName(),
    message: 'Configured successfully'
  };
}

function testConnection() {
  const book = getBook_();
  return { ok: true, spreadsheet: book.getName(), message: 'Server connected' };
}

function getBook_() {
  if (_BOOK_CACHE) return _BOOK_CACHE;

  const id = PropertiesService.getScriptProperties().getProperty('SPREADSHEET_ID');
  if (!id) throw new Error('App is not configured. Run configure() once from Apps Script.');

  _BOOK_CACHE = SpreadsheetApp.openById(id);
  return _BOOK_CACHE;
}

function getSheet_(name) {
  const s = getBook_().getSheetByName(name);
  if (!s) throw new Error('Missing sheet: ' + name);
  return s;
}

function tz_() {
  return getBook_().getSpreadsheetTimeZone() || Session.getScriptTimeZone() || 'Europe/Vienna';
}

/* ---------- WORKBOOK SETUP ---------- */

function setupWorkbook_() {
  const book = getBook_();

  const specs = {
    Users: ['Username','Display Name','Password Hash','Salt','Role','Active','Created At','Created By','Last Login'],
    Drivers: ['Driver ID','Name','Active','QR Code'],
    Cars: ['Plate','Active','Type','QR Code'],
    Scanners: ['Scanner ID','Active','QR Code'],
    Changes: ['Timestamp','Assignment ID','Day','Driver','Driver ID','Type','Old Item','New Item','Reason','Changed By','Username'],
    Audit: ['Timestamp','Username','Display Name','Role','Action','Assignment ID','Day','Details'],
    DAY_TEMPLATE: [
      'Assignment ID','Driver','Driver ID','Car','Car Type','Scanner','Start Time','Started By','Start Method',
      'Return Time','Returned By','Return Method','Status','Last Modified By','Last Modified Time'
    ]
  };

  Object.keys(specs).forEach(name => {
    let s = book.getSheetByName(name);
    if (!s) s = book.insertSheet(name);

    if (name === 'DAY_TEMPLATE') {
      setupDayTemplate_(s, specs[name]);
    } else {
      setupSimpleSheet_(s, specs[name]);
      formatSimpleSheet_(s, name);
    }
  });


  const audit = book.getSheetByName('Audit');
  const tmpl = book.getSheetByName('DAY_TEMPLATE');
  try { audit.hideSheet(); } catch (e) {}
  try { tmpl.hideSheet(); } catch (e) {}
}

function setupSimpleSheet_(s, headers) {
  if (s.getLastRow() === 0) {
    s.getRange(1,1,1,headers.length).setValues([headers]);
  } else {
    s.getRange(1,1,1,headers.length).setValues([headers]);
  }
  styleHeader_(s.getRange(1,1,1,headers.length));
  s.setFrozenRows(1);
}

function formatSimpleSheet_(s, name) {
  const lastRow = Math.max(s.getLastRow(), 1);
  const lastCol = Math.max(s.getLastColumn(), 1);
  const range = s.getRange(1, 1, lastRow, lastCol);
  range.setVerticalAlignment('middle').setWrap(true);

  if (lastRow > 1) {
    s.getRange(2, 1, lastRow - 1, lastCol).setHorizontalAlignment('center');
  }

  if (name === 'Drivers') {
    [110, 220, 110, 180].forEach((w,i) => s.setColumnWidth(i+1,w));
    configureDriverStatusColumn_(s);
  } else if (name === 'Cars') {
    [160, 110, 110, 180].forEach((w,i) => s.setColumnWidth(i+1,w));
    configureMasterStatusColumn_(s, 2);
  } else if (name === 'Scanners') {
    [160, 110, 180].forEach((w,i) => s.setColumnWidth(i+1,w));
    configureMasterStatusColumn_(s, 2);
  } else if (name === 'Changes') {
    [150,230,100,180,100,100,150,150,140,160,140].forEach((w,i) => s.setColumnWidth(i+1,w));
    if (lastRow > 1) {
      s.getRange(2,1,lastRow-1,lastCol).setBackground('#fff8e1');
      s.getRange(2,1,lastRow-1,1).setNumberFormat('dd.MM.yyyy HH:mm');
    }
  } else if (name === 'Audit') {
    s.autoResizeColumns(1, Math.min(lastCol, 8));
  }
}

function configureDriverStatusColumn_(s) {
  configureMasterStatusColumn_(s, 3);
}

function configureMasterStatusColumn_(s, column) {
  if (!s) return;

  const col = Number(column || 0);
  if (col < 1) return;

  try {
    // Old Fleet sheets may still use checkbox validation (TRUE/FALSE).
    // Remove it before converting to text so Google Sheets does not reject
    // Active / Not Active.
    if (s.getMaxRows() > 1) {
      s.getRange(2, col, s.getMaxRows() - 1, 1).clearDataValidations();
    }

    const lastRow = s.getLastRow();
    if (lastRow >= 2) {
      const range = s.getRange(2, col, lastRow - 1, 1);
      const values = range.getValues().map(r => {
        const v = r[0];
        if (v === '' || v === null) return [''];
        return [toBool_(v) ? 'Active' : 'Not Active'];
      });
      range.setValues(values);
    }

    const validation = SpreadsheetApp.newDataValidation()
      .requireValueInList(['Active','Not Active'], true)
      .setAllowInvalid(false)
      .build();

    if (s.getMaxRows() > 1) {
      s.getRange(2, col, s.getMaxRows() - 1, 1).setDataValidation(validation);
    }

    s.setColumnWidth(col, 110);
    applyMasterStatusColors_(s, col);
  } catch (e) {}
}

function applyDriverStatusColors_(s) {
  applyMasterStatusColors_(s, 3);
}

function applyMasterStatusColors_(s, column) {
  if (!s || s.getMaxRows() < 2) return;

  const col = Number(column || 0);
  if (col < 1) return;
  const statusRange = s.getRange(2, col, s.getMaxRows() - 1, 1);

  try {
    const kept = (s.getConditionalFormatRules() || []).filter(rule => {
      try {
        const condition = rule.getBooleanCondition();
        if (!condition) return true;

        const values = condition.getCriteriaValues() || [];
        const target = values.length ? String(values[0] || '').trim().toLowerCase() : '';
        if (target !== 'active' && target !== 'not active') return true;

        const touchesStatus = (rule.getRanges() || []).some(r =>
          r.getColumn() <= col && r.getLastColumn() >= col && r.getLastRow() >= 2
        );
        return !touchesStatus;
      } catch (e) {
        return true;
      }
    });

    const activeRule = SpreadsheetApp.newConditionalFormatRule()
      .whenTextEqualTo('Active')
      .setBackground('#d9ead3')
      .setFontColor('#137333')
      .setBold(true)
      .setRanges([statusRange])
      .build();

    const inactiveRule = SpreadsheetApp.newConditionalFormatRule()
      .whenTextEqualTo('Not Active')
      .setBackground('#f4cccc')
      .setFontColor('#b31412')
      .setBold(true)
      .setRanges([statusRange])
      .build();

    s.setConditionalFormatRules(kept.concat([activeRule, inactiveRule]));
  } catch (e) {
    try {
      const values = statusRange.getDisplayValues();
      const backgrounds = [];
      const fontColors = [];
      const fontWeights = [];

      values.forEach(r => {
        const v = String(r[0] || '').trim().toLowerCase();
        if (v === 'active') {
          backgrounds.push(['#d9ead3']);
          fontColors.push(['#137333']);
          fontWeights.push(['bold']);
        } else if (v === 'not active') {
          backgrounds.push(['#f4cccc']);
          fontColors.push(['#b31412']);
          fontWeights.push(['bold']);
        } else {
          backgrounds.push([null]);
          fontColors.push([null]);
          fontWeights.push(['normal']);
        }
      });

      statusRange.setBackgrounds(backgrounds);
      statusRange.setFontColors(fontColors);
      statusRange.setFontWeights(fontWeights);
    } catch (_) {}
  }
}

function setupDayTemplate_(s, headers) {
  s.clear();

  s.getRange('A1:O1').merge();
  s.getRange('A1').setValue('Fleet Assignments — DAILY_DATE');
  s.getRange('A1').setFontWeight('bold').setFontSize(16).setHorizontalAlignment('center');

  s.getRange('A2').setValue('Started');
  s.getRange('D2').setValue('Returned');
  s.getRange('G2').setValue('Still Out');
  setDailyStatsFormulas_(s, true);

  s.getRange(APP.DAILY_HEADER_ROW,1,1,headers.length).setValues([headers]);
  styleHeader_(s.getRange(APP.DAILY_HEADER_ROW,1,1,headers.length));
  s.setFrozenRows(APP.DAILY_HEADER_ROW);

  const widths = [250,170,100,110,95,100,105,130,100,105,130,100,95,140,140];
  widths.forEach((w,i) => s.setColumnWidth(i+1,w));

  s.getRange('G:G').setNumberFormat('dd.MM.yyyy HH:mm');
  s.getRange('J:J').setNumberFormat('dd.MM.yyyy HH:mm');
  s.getRange('O:O').setNumberFormat('dd.MM.yyyy HH:mm');
  s.getRange('A:O').setHorizontalAlignment('center').setVerticalAlignment('middle').setWrap(true);
  s.getRange('A1:O4').setHorizontalAlignment('center');
}


function ensureDailySheetSchema_(s) {
  if (!s) return;

  const currentE = String(
    s.getRange(APP.DAILY_HEADER_ROW, 5).getValue() || ''
  ).trim();

  // Upgrade old A:N daily sheets:
  // A Assignment ID, B Driver, C Driver ID, D Car, E Scanner ...
  // becomes A:O with E = Car Type.
  if (currentE !== 'Car Type') {
    s.insertColumnAfter(4);

    s.getRange(APP.DAILY_HEADER_ROW, 5).setValue('Car Type');
    styleHeader_(s.getRange(APP.DAILY_HEADER_ROW, 1, 1, 15));

    const lastRow = s.getLastRow();

    if (lastRow >= APP.DAILY_DATA_START) {
      const cars = s.getRange(
        APP.DAILY_DATA_START,
        4,
        lastRow - APP.DAILY_DATA_START + 1,
        1
      ).getValues();

      const types = cars.map(r => [
        r[0] ? getCarType_(r[0]) : ''
      ]);

      s.getRange(
        APP.DAILY_DATA_START,
        5,
        types.length,
        1
      ).setValues(types);
    }
  }

  // Keep the statistic labels in the correct cells.
  s.getRange('A2').setValue('Started');
  s.getRange('D2').setValue('Returned');
  s.getRange('G2').setValue('Still Out');

  // Repair statistics only if a formula is missing or currently shows an error.
  // Valid formulas are left alone, so the app does not keep overwriting them.
  setDailyStatsFormulas_(s, false);

  // Remove cells left behind when an old A:N sheet was migrated.
  s.getRange('F2').clearContent();
  s.getRange('I2').clearContent();

  const widths = [250,170,100,110,95,100,105,130,100,105,130,100,95,140,140];
  widths.forEach((w,i) => s.setColumnWidth(i+1,w));

  s.getRange('G:G').setNumberFormat('dd.MM.yyyy HH:mm');
  s.getRange('J:J').setNumberFormat('dd.MM.yyyy HH:mm');
  s.getRange('O:O').setNumberFormat('dd.MM.yyyy HH:mm');
  s.getRange('A:O')
    .setHorizontalAlignment('center')
    .setVerticalAlignment('middle')
    .setWrap(true);
  s.getRange('A1:O4').setHorizontalAlignment('center');
}

function upgradeExistingDailySheets() {
  // Repair the template as well so every NEW daily sheet starts correctly.
  const template = getSheet_('DAY_TEMPLATE');
  setDailyStatsFormulas_(template, true);

  getDailySheets_().forEach(s => {
    ensureDailySheetSchema_(s);
    setDailyStatsFormulas_(s, true);
  });

  return {
    ok:true,
    locale:getBook_().getSpreadsheetLocale(),
    separator:formulaSeparator_(),
    message:'All daily sheets upgraded and statistics formulas repaired for the spreadsheet locale.'
  };
}

function repairDailyStatsFormulas() {
  const template = getSheet_('DAY_TEMPLATE');
  setDailyStatsFormulas_(template, true);

  const sheets = getDailySheets_();
  sheets.forEach(s => setDailyStatsFormulas_(s, true));

  return {
    ok:true,
    locale:getBook_().getSpreadsheetLocale(),
    separator:formulaSeparator_(),
    repaired:sheets.length,
    message:'Started / Returned / Still Out formulas repaired.'
  };
}

function formulaSeparator_() {
  const locale = String(getBook_().getSpreadsheetLocale() || '').toLowerCase();

  // German/Austrian/Swiss German Google Sheets use semicolons as formula
  // argument separators when formulas are entered into the sheet.
  if (locale.indexOf('de') === 0) return ';';

  return ',';
}

function setDailyStatsFormulas_(s, force) {
  if (!s) return;

  const sep = formulaSeparator_();
  const formulas = [
    ['B2', '=COUNTA(A5:A)'],
    ['E2', '=COUNTIF(M5:M' + sep + '\"RETURNED\")'],
    ['H2', '=COUNTIF(M5:M' + sep + '\"OUT\")']
  ];

  formulas.forEach(item => {
    const cell = s.getRange(item[0]);
    const currentFormula = String(cell.getFormula() || '');
    const display = String(cell.getDisplayValue() || '');
    const hasError = display.charAt(0) === '#';

    if (force || !currentFormula || hasError) {
      cell.setFormula(item[1]);
    }
  });
}

function styleHeader_(range) {
  range.setFontWeight('bold')
    .setBackground('#1769aa')
    .setFontColor('#ffffff')
    .setHorizontalAlignment('center');
}

/* ---------- AUTHENTICATION ---------- */

function hashPassword_(password, salt) {
  const bytes = Utilities.computeDigest(
    Utilities.DigestAlgorithm.SHA_256,
    String(password) + String(salt),
    Utilities.Charset.UTF_8
  );
  return bytes.map(b => ('0' + ((b + 256) % 256).toString(16)).slice(-2)).join('');
}

function sessionKey_(token) {
  return 'SESSION_' + token;
}

function invalidateUserSessions_(username, exceptToken) {
  const target = String(username || '').trim().toLowerCase();
  const keep = String(exceptToken || '');
  const props = PropertiesService.getScriptProperties();
  const all = props.getProperties();

  Object.keys(all).forEach(key => {
    if (key.indexOf('SESSION_') !== 0) return;
    if (keep && key === sessionKey_(keep)) return;

    try {
      const s = JSON.parse(all[key]);
      if (String(s.username || '').trim().toLowerCase() === target) {
        props.deleteProperty(key);
      }
    } catch (e) {}
  });
}

function login(username, password) {
  const u = String(username || '').trim().toLowerCase();
  const p = String(password || '');

  if (!u || !p) return { ok:false, error:'Enter username and password.' };

  const s = getSheet_('Users');
  const rows = s.getDataRange().getValues();

  for (let i = 1; i < rows.length; i++) {
    const rowUser = String(rows[i][0] || '').trim().toLowerCase();
    const active = toBool_(rows[i][5]);

    if (rowUser === u && active) {
      const expected = String(rows[i][2] || '');
      const salt = String(rows[i][3] || '');
      if (hashPassword_(p, salt) !== expected) break;

      const token = Utilities.getUuid() + Utilities.getUuid();
      const session = {
        username: rows[i][0],
        name: rows[i][1],
        role: rows[i][4],
        issuedAt: Date.now()
      };

      PropertiesService.getScriptProperties().setProperty(sessionKey_(token), JSON.stringify(session));
      s.getRange(i+1, 9).setValue(new Date());
      audit_(session, 'LOGIN', '', '', 'Successful login');

      return {
        ok:true,
        token:token,
        user:{ username:session.username, name:session.name, role:session.role },
        persistent:true
      };
    }
  }

  return { ok:false, error:'Invalid username or password.' };
}

function resumeSession(token) {
  const session = requireAuth_(token, false);
  return {
    ok:true,
    user:{ username:session.username, name:session.name, role:session.role },
    persistent:true
  };
}

function logout(token) {
  try {
    const session = requireAuth_(token, false);
    audit_(session, 'LOGOUT', '', '', 'User logged out');
  } catch (e) {}
  PropertiesService.getScriptProperties().deleteProperty(sessionKey_(token));
  return { ok:true };
}

function requireAuth_(token, adminOnly) {
  const key = sessionKey_(String(token || ''));
  const raw = PropertiesService.getScriptProperties().getProperty(key);
  if (!raw) throw new Error('Login required. Sign in again.');

  const session = JSON.parse(raw);

  if (adminOnly && session.role !== APP.ROLES.ADMIN) {
    throw new Error('Admin permission required.');
  }

  return session;
}

function changeMyPassword(token, currentPassword, newPassword) {
  const session = requireAuth_(token, false);
  if (String(newPassword || '').length < 8) throw new Error('New password must be at least 8 characters.');

  const s = getSheet_('Users');
  const rows = s.getDataRange().getValues();

  for (let i = 1; i < rows.length; i++) {
    if (String(rows[i][0]) === String(session.username)) {
      const currentHash = String(rows[i][2]);
      const currentSalt = String(rows[i][3]);
      if (hashPassword_(currentPassword, currentSalt) !== currentHash) {
        throw new Error('Current password is incorrect.');
      }

      const newSalt = Utilities.getUuid();
      s.getRange(i+1, 3, 1, 2).setValues([[hashPassword_(newPassword, newSalt), newSalt]]);
      audit_(session, 'CHANGE_PASSWORD', '', '', 'Password changed');
      return { ok:true };
    }
  }

  throw new Error('User account not found.');
}

/* ---------- USER ADMIN ---------- */

function listUsers(token) {
  requireAuth_(token, true);
  const rows = getSheet_('Users').getDataRange().getValues().slice(1);

  return rows.map(r => ({
    username:r[0],
    name:r[1],
    role:r[4],
    active:toBool_(r[5]),
    createdAt:r[6],
    createdBy:r[7],
    lastLogin:r[8]
  }));
}

function createUser(token, username, displayName, password, role) {
  const admin = requireAuth_(token, true);
  const u = String(username || '').trim().toLowerCase();
  const n = String(displayName || '').trim();
  const p = String(password || '');
  const r = role === APP.ROLES.ADMIN ? APP.ROLES.ADMIN : APP.ROLES.USER;

  if (!/^[a-z0-9._-]{3,30}$/.test(u)) throw new Error('Username must be 3–30 characters: letters, numbers, dot, dash or underscore.');
  if (!n) throw new Error('Display name is required.');
  if (p.length < 8) throw new Error('Password must be at least 8 characters.');

  const s = getSheet_('Users');
  const rows = s.getDataRange().getValues();
  if (rows.slice(1).some(row => String(row[0] || '').trim().toLowerCase() === u)) {
    throw new Error('Username already exists.');
  }

  const salt = Utilities.getUuid();
  s.appendRow([u,n,hashPassword_(p,salt),salt,r,true,new Date(),admin.username,'']);
  audit_(admin, 'CREATE_USER', '', '', u + ' / ' + r);

  return { ok:true };
}

function resetUserPassword(token, username, newPassword) {
  const admin = requireAuth_(token, true);
  if (String(newPassword || '').length < 8) throw new Error('Password must be at least 8 characters.');

  const s = getSheet_('Users');
  const rows = s.getDataRange().getValues();

  for (let i = 1; i < rows.length; i++) {
    if (String(rows[i][0]).trim().toLowerCase() === String(username).trim().toLowerCase()) {
      const salt = Utilities.getUuid();
      s.getRange(i+1, 3, 1, 2).setValues([[hashPassword_(newPassword, salt), salt]]);
      invalidateUserSessions_(String(rows[i][0]));
      audit_(admin, 'RESET_PASSWORD', '', '', String(rows[i][0]));
      return { ok:true };
    }
  }

  throw new Error('User not found.');
}

function setUserActive(token, username, active) {
  const admin = requireAuth_(token, true);
  if (String(username).trim().toLowerCase() === String(admin.username).trim().toLowerCase() && !active) {
    throw new Error('You cannot deactivate your own account.');
  }

  const s = getSheet_('Users');
  const rows = s.getDataRange().getValues();

  for (let i = 1; i < rows.length; i++) {
    if (String(rows[i][0]).trim().toLowerCase() === String(username).trim().toLowerCase()) {
      s.getRange(i+1, 6).setValue(Boolean(active));
      if (!active) invalidateUserSessions_(String(rows[i][0]));
      audit_(admin, active ? 'ACTIVATE_USER' : 'DEACTIVATE_USER', '', '', String(rows[i][0]));
      return { ok:true };
    }
  }

  throw new Error('User not found.');
}

/* ---------- MASTER DATA ---------- */

function getMasterData(token) {
  requireAuth_(token, false);
  return {
    drivers: readMaster_('Drivers').map(r => ({id:r[0], name:r[1], active:toBool_(r[2])})),
    cars: readMaster_('Cars').map(r => ({plate:r[0], active:toBool_(r[1]), type:String(r[2] || '')})),
    scanners: readMaster_('Scanners').map(r => ({id:r[0], active:toBool_(r[1])}))
  };
}

function readMaster_(name) {
  const s = getSheet_(name);
  if (s.getLastRow() < 2) return [];
  return s.getRange(2,1,s.getLastRow()-1,s.getLastColumn()).getValues();
}

function upsertDriver(token, id, name, active) {
  const admin = requireAuth_(token, true);
  const key = String(id || '').trim();
  const nm = String(name || '').trim();
  if (!key || !nm) throw new Error('Driver ID and name are required.');
  upsertMaster_('Drivers', key, [key,nm,toBool_(active) ? 'Active' : 'Not Active']);
  audit_(admin, 'UPSERT_DRIVER', '', '', key + ' / ' + nm);
  return { ok:true };
}

function upsertCar(token, plate, active, type) {
  const admin = requireAuth_(token, true);
  const key = String(plate || '').trim().toUpperCase();
  if (!key) throw new Error('Car plate is required.');

  let carType = String(type || '').trim();
  if (!carType) {
    const rows = readMaster_('Cars');
    const existing = rows.find(r => String(r[0] || '').trim().toUpperCase() === key);
    if (existing) carType = String(existing[2] || '').trim();
  }
  if (carType && !/^(DIESEL|ELECTRO)$/i.test(carType)) throw new Error('Car type must be Diesel or Electro.');

  upsertMaster_('Cars', key, [key,toBool_(active) ? 'Active' : 'Not Active',carType]);
  audit_(admin, 'UPSERT_CAR', '', '', key + (carType ? ' / ' + carType : ''));
  return { ok:true };
}

function upsertScanner(token, id, active) {
  const admin = requireAuth_(token, true);
  const key = String(id || '').trim();
  if (!key) throw new Error('Scanner ID is required.');
  upsertMaster_('Scanners', key, [key,toBool_(active) ? 'Active' : 'Not Active']);
  audit_(admin, 'UPSERT_SCANNER', '', '', key);
  return { ok:true };
}

function upsertMaster_(sheetName, key, values) {
  const s = getSheet_(sheetName);
  const rows = s.getDataRange().getValues();

  for (let i = 1; i < rows.length; i++) {
    if (String(rows[i][0]).trim().toUpperCase() === String(key).trim().toUpperCase()) {
      s.getRange(i+1,1,1,values.length).setValues([values]);
      clearMasterCache_();
      return;
    }
  }

  s.appendRow(values);
  clearMasterCache_();
}

function getCarType_(plate) {
  const target = String(plate || '').trim().toUpperCase();
  const row = getMasterIndex_().Cars[target];
  return row ? String(row[2] || '').trim() : '';
}


/* ---------- TRANSACTION SAFETY ---------- */

function replacementTxnKey_(kind, id) {
  const clean = String(id || '').replace(/[^A-Za-z0-9_-]/g, '').slice(0,120);
  return clean ? 'REPTXN_' + kind + '_' + clean : '';
}

function getReplacementTxnResult_(kind, id) {
  const key = replacementTxnKey_(kind, id);
  if (!key) return null;

  try {
    const raw = CacheService.getScriptCache().get(key);
    return raw ? JSON.parse(raw) : null;
  } catch (e) {
    return null;
  }
}

function saveReplacementTxnResult_(kind, id, result) {
  const key = replacementTxnKey_(kind, id);
  if (!key) return;

  try {
    // Replacement transaction IDs are only needed long enough to make browser
    // retries idempotent. CacheService avoids permanently filling ScriptProperties.
    CacheService.getScriptCache().put(
      key,
      JSON.stringify(result),
      PERF.REPLACEMENT_TXN_CACHE_SECONDS
    );
  } catch (e) {}
}

function clearLegacyReplacementTxnProperties_() {
  // Older versions stored REPTXN_* values permanently in ScriptProperties.
  // Remove those legacy entries during the one-time upgrade step.
  try {
    const props = PropertiesService.getScriptProperties();
    const all = props.getProperties();
    Object.keys(all).forEach(key => {
      if (key.indexOf('REPTXN_') === 0) props.deleteProperty(key);
    });
  } catch (e) {}
}

function findAssignmentById_(assignmentId) {
  const target = String(assignmentId || '').trim();
  if (!target) return null;
  const sheets = getDailySheets_().slice().reverse();

  for (let sIndex = 0; sIndex < sheets.length; sIndex++) {
    const s = sheets[sIndex];
    const lastRow = s.getLastRow();
    if (lastRow < APP.DAILY_DATA_START) continue;
    const values = s.getRange(APP.DAILY_DATA_START,1,lastRow-APP.DAILY_DATA_START+1,15).getValues();
    for (let i = values.length-1; i >= 0; i--) {
      if (String(values[i][0]) === target) {
        return {sheet:s,row:APP.DAILY_DATA_START+i,values:values[i]};
      }
    }
  }
  return null;
}

function findMostRecentReturnedExact_(driverId, car, scanner) {
  const sheets = getDailySheets_().slice().reverse();
  for (let sIndex = 0; sIndex < sheets.length; sIndex++) {
    const s = sheets[sIndex];
    const lastRow = s.getLastRow();
    if (lastRow < APP.DAILY_DATA_START) continue;
    const values = s.getRange(APP.DAILY_DATA_START,1,lastRow-APP.DAILY_DATA_START+1,15).getValues();
    for (let i = values.length-1; i >= 0; i--) {
      const r = values[i];
      if (String(r[12]) === 'RETURNED' && String(r[2]) === driverId && String(r[3]).toUpperCase() === car && String(r[5]) === scanner) {
        const returnedAt = r[9] instanceof Date ? r[9].getTime() : new Date(r[9]).getTime();
        if (returnedAt && Date.now() - returnedAt <= 20 * 60 * 1000) {
          return {sheet:s,row:APP.DAILY_DATA_START+i,values:r};
        }
      }
    }
  }
  return null;
}

/* ---------- QR / ASSIGNMENTS ---------- */

function startShift(token, driverInput, carInput, scannerInput, methods, clientTxnId) {
  const user = requireAuth_(token, false);
  const methodObj = normalizeMethods_(methods);

  // The browser transaction ID doubles as the assignment ID. If the network
  // loses the response after Google Sheets already saved, the retry returns
  // the same assignment instead of creating a duplicate.
  const requestedId = String(clientTxnId || '').trim();

  const lock = LockService.getScriptLock();
  lock.waitLock(15000);

  try {
    const driverId = parseCode_(driverInput, 'D');
    const car = parseCode_(carInput, 'C').toUpperCase();
    const scanner = parseCode_(scannerInput, 'S');

    const driver = findActiveMaster_('Drivers', driverId);
    if (!driver) throw new Error('Driver is unknown or inactive: ' + driverId);

    const carRow = findActiveMaster_('Cars', car);
    if (!carRow) throw new Error('Car is unknown or inactive: ' + car);

    if (!findActiveMaster_('Scanners', scanner)) {
      throw new Error('Scanner is unknown or inactive: ' + scanner);
    }

    const open = getOpenAssignments_();

    if (requestedId) {
      const sameTxn = open.find(x => String(x.values[0]) === requestedId);
      if (sameTxn) {
        return {
          ok:true,
          alreadySaved:true,
          assignmentId:sameTxn.values[0],
          driver:sameTxn.values[1],
          driverId:sameTxn.values[2],
          car:sameTxn.values[3],
          carType:sameTxn.values[4],
          scanner:sameTxn.values[5],
          startedBy:sameTxn.values[7],
          day:sameTxn.sheet.getName(),
          time:formatDateTime_(sameTxn.values[6])
        };
      }
    }

    if (open.some(x => String(x.values[2]) === driverId)) {
      throw new Error('DRIVER ALREADY HAS AN ACTIVE ASSIGNMENT');
    }
    if (open.some(x => String(x.values[3]).toUpperCase() === car)) {
      throw new Error('CAR ' + car + ' IS ALREADY ASSIGNED');
    }
    if (open.some(x => String(x.values[5]) === scanner)) {
      throw new Error('SCANNER ' + scanner + ' IS ALREADY ASSIGNED');
    }

    const now = new Date();
    const id = requestedId || Utilities.getUuid();
    const day = getDailySheet_(now);
    const startMethod = [methodObj.driver, methodObj.car, methodObj.scanner].join('/');
    const carType = String(carRow[2] || '').trim();

    const rowValues = [
      id, driver[1], driverId, car, carType, scanner, now, user.name,
      startMethod, '', '', '', 'OUT', user.name, now
    ];

    const row = Math.max(day.getLastRow() + 1, APP.DAILY_DATA_START);
    day.getRange(row, 1, 1, 15).setValues([rowValues]);
    formatAssignmentRow_(day, row, 'OUT');

    open.push({sheet:day,row:row,values:rowValues});
    writeOpenAssignmentsCache_(open);

    audit_(user, 'START_SHIFT', id, day.getName(), driver[1] + ' / ' + car + ' / ' + scanner);

    return {
      ok:true,
      assignmentId:id,
      driver:driver[1],
      driverId:driverId,
      car:car,
      carType:carType,
      scanner:scanner,
      startedBy:user.name,
      day:day.getName(),
      time:Utilities.formatDate(now, tz_(), APP.TIME_FORMAT)
    };
  } finally {
    lock.releaseLock();
  }
}

function returnShift(token, scannerInput, carInput, driverInput, methods, clientTxnId) {
  const user = requireAuth_(token, false);
  const methodObj = normalizeMethods_(methods);

  const lock = LockService.getScriptLock();
  lock.waitLock(15000);

  try {
    const scanner = parseCode_(scannerInput, 'S');
    const car = parseCode_(carInput, 'C').toUpperCase();
    const driverId = parseCode_(driverInput, 'D');

    const open = getOpenAssignments_();

    const exact = open.find(x =>
      String(x.values[2]) === driverId &&
      String(x.values[3]).toUpperCase() === car &&
      String(x.values[5]) === scanner
    );

    if (!exact) {
      // A retry can arrive after the first request already marked the row RETURNED
      // but the browser never received the response. Treat the most recent exact
      // returned triplet as an idempotent success instead of forcing a rescan.
      const returned = findMostRecentReturnedExact_(driverId, car, scanner);
      if (returned) {
        return {
          ok:true,
          alreadySaved:true,
          assignmentId:returned.values[0],
          driver:returned.values[1],
          driverId:returned.values[2],
          car:returned.values[3],
          carType:returned.values[4],
          scanner:returned.values[5],
          returnedBy:returned.values[10],
          day:returned.sheet.getName(),
          time:formatDateTime_(returned.values[9])
        };
      }

      const driverMatch = open.find(x => String(x.values[2]) === driverId);
      const carMatch = open.find(x => String(x.values[3]).toUpperCase() === car);
      const scannerMatch = open.find(x => String(x.values[5]) === scanner);

      if (driverMatch || carMatch || scannerMatch) {
        throw new Error('RETURN MISMATCH — scanned Driver/Car/Scanner do not belong to the same active assignment.');
      }

      throw new Error('No active assignment found for these items.');
    }

    const now = new Date();
    const returnMethod = [methodObj.scanner, methodObj.car, methodObj.driver].join('/');

    exact.sheet.getRange(exact.row, 10, 1, 6).setValues([[
      now,
      user.name,
      returnMethod,
      'RETURNED',
      user.name,
      now
    ]]);

    formatAssignmentRow_(exact.sheet, exact.row, 'RETURNED');

    // Returned assignment is no longer active.
    writeOpenAssignmentsCache_(
      open.filter(x => String(x.values[0]) !== String(exact.values[0]))
    );

    audit_(
      user,
      'RETURN_SHIFT',
      exact.values[0],
      exact.sheet.getName(),
      exact.values[1] + ' / ' + car + ' / ' + scanner
    );

    return {
      ok:true,
      assignmentId:exact.values[0],
      driver:exact.values[1],
      driverId:driverId,
      car:car,
      carType:String(exact.values[4] || getCarType_(car)),
      scanner:scanner,
      returnedBy:user.name,
      day:exact.sheet.getName(),
      time:Utilities.formatDate(now, tz_(), APP.TIME_FORMAT)
    };
  } finally {
    lock.releaseLock();
  }
}

function lookupActiveAssignment(token, itemInput) {
  requireAuth_(token, false);
  const raw = String(itemInput || '').trim();
  if (!raw) throw new Error('Scan or enter an item.');

  let type = '';
  let value = raw;
  const pos = raw.indexOf(':');
  if (pos > -1) {
    type = raw.substring(0, pos).trim().toUpperCase();
    value = raw.substring(pos + 1).trim();
  }
  if (!value) throw new Error('Invalid item value.');

  const target = value.toUpperCase();
  const open = getOpenAssignments_();
  const match = open.find(x => {
    if (type === 'D') return String(x.values[2]).trim().toUpperCase() === target;
    if (type === 'C') return String(x.values[3]).trim().toUpperCase() === target;
    if (type === 'S') return String(x.values[5]).trim().toUpperCase() === target;
    return String(x.values[2]).trim().toUpperCase() === target ||
      String(x.values[3]).trim().toUpperCase() === target ||
      String(x.values[5]).trim().toUpperCase() === target;
  });

  if (!match) throw new Error('No active assignment found for this item.');
  return assignmentObject_(match);
}

function replaceScanner(token, oldScannerInput, newScannerInput, reason, method) {
  const user = requireAuth_(token, false);
  const oldScanner = parseCode_(oldScannerInput, 'S');
  const newScanner = parseCode_(newScannerInput, 'S');

  if (oldScanner.toUpperCase() === newScanner.toUpperCase()) {
    throw new Error('New scanner must be different from the current scanner.');
  }

  if (!findActiveMaster_('Scanners', newScanner)) {
    throw new Error('New scanner is unknown or inactive: ' + newScanner);
  }

  const lock = LockService.getScriptLock();
  lock.waitLock(15000);

  try {
    const open = getOpenAssignments_();

    const exact = open.find(
      x => String(x.values[5]).trim().toUpperCase() === oldScanner.toUpperCase()
    );

    if (!exact) throw new Error('Current scanner is not assigned: ' + oldScanner);

    if (open.some(
      x => String(x.values[5]).trim().toUpperCase() === newScanner.toUpperCase()
    )) {
      throw new Error('SCANNER ' + newScanner + ' IS ALREADY ASSIGNED');
    }

    const now = new Date();

    exact.sheet.getRange(exact.row, 6).setValue(newScanner);
    exact.sheet.getRange(exact.row, 14, 1, 2).setValues([[user.name, now]]);
    formatAssignmentRow_(exact.sheet, exact.row, 'OUT');

    exact.values[5] = newScanner;
    exact.values[13] = user.name;
    exact.values[14] = now;
    writeOpenAssignmentsCache_(open);

    recordChange_(exact, user, 'SCANNER', oldScanner, newScanner, reason, method, now);
    audit_(
      user,
      'REPLACE_SCANNER',
      exact.values[0],
      exact.sheet.getName(),
      oldScanner + ' -> ' + newScanner + ' / ' + String(reason || '')
    );

    return Object.assign(
      {
        ok:true,
        changedAt:formatDateTime_(now),
        reason:String(reason || ''),
        changedBy:user.name
      },
      assignmentObject_(exact)
    );
  } finally {
    lock.releaseLock();
  }
}

function replaceCar(token, oldCarInput, newCarInput, reason, method) {
  const user = requireAuth_(token, false);
  const oldCar = parseCode_(oldCarInput, 'C').toUpperCase();
  const newCar = parseCode_(newCarInput, 'C').toUpperCase();

  if (oldCar === newCar) {
    throw new Error('New car must be different from the current car.');
  }

  const newCarRow = findActiveMaster_('Cars', newCar);
  if (!newCarRow) {
    throw new Error('New car is unknown or inactive: ' + newCar);
  }

  const lock = LockService.getScriptLock();
  lock.waitLock(15000);

  try {
    const open = getOpenAssignments_();

    const exact = open.find(
      x => String(x.values[3]).trim().toUpperCase() === oldCar
    );

    if (!exact) throw new Error('Current car is not assigned: ' + oldCar);

    if (open.some(
      x => String(x.values[3]).trim().toUpperCase() === newCar
    )) {
      throw new Error('CAR ' + newCar + ' IS ALREADY ASSIGNED');
    }

    const now = new Date();
    const carType = String(newCarRow[2] || '').trim();

    exact.sheet.getRange(exact.row, 4, 1, 2).setValues([[newCar, carType]]);
    exact.sheet.getRange(exact.row, 14, 1, 2).setValues([[user.name, now]]);
    formatAssignmentRow_(exact.sheet, exact.row, 'OUT');

    exact.values[3] = newCar;
    exact.values[4] = carType;
    exact.values[13] = user.name;
    exact.values[14] = now;
    writeOpenAssignmentsCache_(open);

    recordChange_(exact, user, 'CAR', oldCar, newCar, reason, method, now);
    audit_(
      user,
      'REPLACE_CAR',
      exact.values[0],
      exact.sheet.getName(),
      oldCar + ' -> ' + newCar + ' / ' + String(reason || '')
    );

    return Object.assign(
      {
        ok:true,
        changedAt:formatDateTime_(now),
        reason:String(reason || ''),
        changedBy:user.name
      },
      assignmentObject_(exact)
    );
  } finally {
    lock.releaseLock();
  }
}

function replaceScannerAuto(token, firstScannerInput, secondScannerInput, reason, method, clientTxnId) {
  const user = requireAuth_(token, false);
  const cached = getReplacementTxnResult_('SCANNER', clientTxnId);
  if (cached) return Object.assign({alreadySaved:true}, cached);

  const first = parseCode_(firstScannerInput, 'S');
  const second = parseCode_(secondScannerInput, 'S');
  if (first.toUpperCase() === second.toUpperCase()) throw new Error('Scan two different scanners.');

  const lock = LockService.getScriptLock();
  lock.waitLock(15000);
  try {
    const open = getOpenAssignments_();
    const firstMatch = open.find(x => String(x.values[5]).trim().toUpperCase() === first.toUpperCase());
    const secondMatch = open.find(x => String(x.values[5]).trim().toUpperCase() === second.toUpperCase());

    if (!!firstMatch === !!secondMatch) {
      if (firstMatch && secondMatch) throw new Error('Both scanners are currently assigned. One must be the replacement scanner.');
      throw new Error('Neither scanner is currently assigned. Scan one current scanner and one replacement scanner.');
    }

    const exact = firstMatch || secondMatch;
    const oldScanner = firstMatch ? first : second;
    const newScanner = firstMatch ? second : first;

    if (!findActiveMaster_('Scanners', newScanner)) {
      throw new Error('New scanner is unknown or inactive: ' + newScanner);
    }
    if (open.some(x => String(x.values[5]).trim().toUpperCase() === newScanner.toUpperCase())) {
      throw new Error('SCANNER ' + newScanner + ' IS ALREADY ASSIGNED');
    }

    const now = new Date();
    exact.sheet.getRange(exact.row, 6).setValue(newScanner);
    exact.sheet.getRange(exact.row, 14, 1, 2).setValues([[user.name, now]]);
    formatAssignmentRow_(exact.sheet, exact.row, 'OUT');
    exact.values[5] = newScanner;
    exact.values[13] = user.name;
    exact.values[14] = now;
    writeOpenAssignmentsCache_(open);
    recordChange_(exact, user, 'SCANNER', oldScanner, newScanner, reason, method, now);
    audit_(user, 'REPLACE_SCANNER', exact.values[0], exact.sheet.getName(), oldScanner + ' -> ' + newScanner + ' / ' + String(reason || ''));

    const result = Object.assign({ok:true,oldItem:oldScanner,newItem:newScanner,changedAt:formatDateTime_(now),reason:String(reason||''),changedBy:user.name},assignmentObject_(exact));
    saveReplacementTxnResult_('SCANNER', clientTxnId, result);
    return result;
  } finally {
    lock.releaseLock();
  }
}

function replaceCarAuto(token, firstCarInput, secondCarInput, reason, method, clientTxnId) {
  const user = requireAuth_(token, false);
  const cached = getReplacementTxnResult_('CAR', clientTxnId);
  if (cached) return Object.assign({alreadySaved:true}, cached);

  const first = parseCode_(firstCarInput, 'C').toUpperCase();
  const second = parseCode_(secondCarInput, 'C').toUpperCase();
  if (first === second) throw new Error('Scan two different vehicles.');

  const lock = LockService.getScriptLock();
  lock.waitLock(15000);
  try {
    const open = getOpenAssignments_();
    const firstMatch = open.find(x => String(x.values[3]).trim().toUpperCase() === first);
    const secondMatch = open.find(x => String(x.values[3]).trim().toUpperCase() === second);

    if (!!firstMatch === !!secondMatch) {
      if (firstMatch && secondMatch) throw new Error('Both vehicles are currently assigned. One must be the replacement vehicle.');
      throw new Error('Neither vehicle is currently assigned. Scan one current vehicle and one replacement vehicle.');
    }

    const exact = firstMatch || secondMatch;
    const oldCar = firstMatch ? first : second;
    const newCar = firstMatch ? second : first;
    const newCarRow = findActiveMaster_('Cars', newCar);
    if (!newCarRow) throw new Error('New car is unknown or inactive: ' + newCar);
    if (open.some(x => String(x.values[3]).trim().toUpperCase() === newCar)) {
      throw new Error('CAR ' + newCar + ' IS ALREADY ASSIGNED');
    }

    const now = new Date();
    const carType = String(newCarRow[2] || '').trim();
    exact.sheet.getRange(exact.row, 4, 1, 2).setValues([[newCar, carType]]);
    exact.sheet.getRange(exact.row, 14, 1, 2).setValues([[user.name, now]]);
    formatAssignmentRow_(exact.sheet, exact.row, 'OUT');
    exact.values[3] = newCar;
    exact.values[4] = carType;
    exact.values[13] = user.name;
    exact.values[14] = now;
    writeOpenAssignmentsCache_(open);
    recordChange_(exact, user, 'CAR', oldCar, newCar, reason, method, now);
    audit_(user, 'REPLACE_CAR', exact.values[0], exact.sheet.getName(), oldCar + ' -> ' + newCar + ' / ' + String(reason || ''));

    const result = Object.assign({ok:true,oldItem:oldCar,newItem:newCar,changedAt:formatDateTime_(now),reason:String(reason||''),changedBy:user.name},assignmentObject_(exact));
    saveReplacementTxnResult_('CAR', clientTxnId, result);
    return result;
  } finally {
    lock.releaseLock();
  }
}

function replacementHistory(token, limit) {
  requireAuth_(token, false);

  const s = getSheet_('Changes');
  const lastRow = s.getLastRow();
  if (lastRow < 2) return [];

  const n = Math.max(1, Math.min(Number(limit || 100), 500));
  const count = Math.min(n, lastRow - 1);
  const startRow = lastRow - count + 1;

  const rows = s.getRange(startRow,1,count,11).getValues();

  return rows.reverse().map(r => ({
    timestamp:formatDateTime_(r[0]),
    assignmentId:r[1],
    day:r[2],
    driver:r[3],
    driverId:r[4],
    type:r[5],
    oldItem:r[6],
    newItem:r[7],
    reason:r[8],
    changedBy:r[9],
    username:r[10]
  }));
}

function recordChange_(assignment, user, type, oldItem, newItem, reason, method, now) {
  const s = getSheet_('Changes');
  s.appendRow([
    now,
    assignment.values[0],
    assignment.sheet.getName(),
    assignment.values[1],
    assignment.values[2],
    type,
    oldItem,
    newItem,
    String(reason || 'OTHER').toUpperCase(),
    user.name,
    user.username
  ]);
  const row = s.getLastRow();
  s.getRange(row,1,1,11).setHorizontalAlignment('center').setVerticalAlignment('middle').setWrap(true).setBackground('#fff8e1');
  s.getRange(row,1).setNumberFormat('dd.MM.yyyy HH:mm');
}

function assignmentObject_(x) {
  return {
    assignmentId:x.values[0],
    driver:x.values[1],
    driverId:x.values[2],
    car:x.values[3],
    carType:x.values[4],
    scanner:x.values[5],
    start:formatDateTime_(x.values[6]),
    startedBy:x.values[7],
    startMethod:x.values[8],
    day:x.sheet.getName(),
    status:x.values[12]
  };
}

function stillOut(token) {
  requireAuth_(token, false);
  return getOpenAssignments_().map(x => ({
    assignmentId:x.values[0],
    driver:x.values[1],
    driverId:x.values[2],
    car:x.values[3],
    carType:x.values[4],
    scanner:x.values[5],
    start:formatDateTime_(x.values[6]),
    startedBy:x.values[7],
    startMethod:x.values[8],
    day:x.sheet.getName()
  }));
}

function dashboard(token) {
  const user = requireAuth_(token, false);
  const today = getDailySheet_(new Date());
  const lastRow = today.getLastRow();

  let started = 0;
  let returned = 0;
  let out = 0;

  if (lastRow >= APP.DAILY_DATA_START) {
    const statuses = today.getRange(
      APP.DAILY_DATA_START,
      13,
      lastRow - APP.DAILY_DATA_START + 1,
      1
    ).getValues();

    statuses.forEach(r => {
      const status = String(r[0] || '');
      if (!status) return;

      started++;
      if (status === 'RETURNED') returned++;
      if (status === 'OUT') out++;
    });
  }

  return {
    user:{username:user.username,name:user.name,role:user.role},
    day:today.getName(),
    started:started,
    returned:returned,
    out:out
  };
}

function recentHistory(token, limit) {
  requireAuth_(token, false);

  const n = Math.max(1, Math.min(Number(limit || 50), 200));
  const result = [];
  const sheets = getDailySheets_().slice().reverse();

  for (let sIndex = 0; sIndex < sheets.length && result.length < n; sIndex++) {
    const s = sheets[sIndex];
    const lastRow = s.getLastRow();

    if (lastRow < APP.DAILY_DATA_START) continue;

    const rows = s.getRange(
      APP.DAILY_DATA_START,
      1,
      lastRow - APP.DAILY_DATA_START + 1,
      15
    ).getValues();

    for (let i = rows.length - 1; i >= 0 && result.length < n; i--) {
      const r = rows[i];
      if (!r[0]) continue;

      result.push({
        day:s.getName(),
        assignmentId:r[0],
        driver:r[1],
        driverId:r[2],
        car:r[3],
        carType:r[4],
        scanner:r[5],
        start:formatDateTime_(r[6]),
        startedBy:r[7],
        returnTime:formatDateTime_(r[9]),
        returnedBy:r[10],
        status:r[12]
      });
    }
  }

  return result;
}


/**
 * Run this ONCE after deploying this optimized backend.
 * It upgrades old daily sheets, repairs the formulas and clears caches.
 * Do not run it after every scan.
 */
function prepareFleetPerformanceUpgrade() {
  const result = upgradeExistingDailySheets();
  configureDriverStatusColumn_(getSheet_('Drivers'));
  configureMasterStatusColumn_(getSheet_('Cars'), 2);
  configureMasterStatusColumn_(getSheet_('Scanners'), 2);
  clearFleetPerformanceCache();
  clearLegacyReplacementTxnProperties_();

  return {
    ok:true,
    upgraded:result,
    message:'FleetControl performance upgrade prepared successfully.'
  };
}

/* ---------- DAILY SHEETS ---------- */

function getDailySheet_(dateObj) {
  const book = getBook_();
  const name = Utilities.formatDate(dateObj, tz_(), APP.DATE_FORMAT);
  let s = book.getSheetByName(name);

  if (!s) {
    const template = getSheet_('DAY_TEMPLATE');
    s = template.copyTo(book).setName(name).showSheet();
    s.getRange('A1').setValue('Fleet Assignments — ' + name);
  } else {
    // Very cheap schema check. The expensive repair/formatting function
    // runs only for an old A:N sheet.
    const currentE = String(
      s.getRange(APP.DAILY_HEADER_ROW, 5).getDisplayValue() || ''
    ).trim();

    if (currentE !== 'Car Type') {
      ensureDailySheetSchema_(s);
      clearOpenAssignmentsCache_();
    }
  }

  return s;
}

function getDailySheets_() {
  return getBook_().getSheets()
    .filter(s => /^\d{2}\.\d{2}\.\d{4}$/.test(s.getName()))
    .sort((a,b) => parseDay_(a.getName()) - parseDay_(b.getName()));
}

function parseDay_(name) {
  const p = name.split('.');
  return new Date(Number(p[2]), Number(p[1])-1, Number(p[0])).getTime();
}

function getDailyRows_(s) {
  if (s.getLastRow() < APP.DAILY_DATA_START) return [];

  return s.getRange(
    APP.DAILY_DATA_START,
    1,
    s.getLastRow() - APP.DAILY_DATA_START + 1,
    15
  ).getValues().filter(r => r[0]);
}

function getOpenAssignments_() {
  const cached = readOpenAssignmentsCache_();
  if (cached !== null) return cached;

  const out = [];

  getDailySheets_().forEach(s => {
    const lastRow = s.getLastRow();
    if (lastRow < APP.DAILY_DATA_START) return;

    const rows = s.getRange(
      APP.DAILY_DATA_START,
      1,
      lastRow - APP.DAILY_DATA_START + 1,
      15
    ).getValues();

    rows.forEach((r, idx) => {
      if (r[0] && String(r[12]) === 'OUT') {
        out.push({
          sheet: s,
          row: APP.DAILY_DATA_START + idx,
          values: r
        });
      }
    });
  });

  writeOpenAssignmentsCache_(out);
  return out;
}

function formatAssignmentRow_(sheet, row, status) {
  const range = sheet.getRange(row,1,1,15);

  range.setBackground(
    String(status).toUpperCase() === 'RETURNED'
      ? '#e8f5e9'
      : '#fff3e0'
  );

  sheet.setRowHeight(row, 34);
}

/* ---------- HELPERS ---------- */

function parseCode_(value, expectedPrefix) {
  let raw = String(value || '').trim();
  if (!raw) throw new Error('Missing ' + expectedPrefix + ' value.');

  const upper = raw.toUpperCase();
  if (upper.includes(':')) {
    const prefix = upper.split(':')[0];
    if (prefix !== expectedPrefix) {
      throw new Error('Wrong QR type. Expected ' + expectedPrefix + ':');
    }
    raw = raw.substring(raw.indexOf(':') + 1).trim();
  }

  if (!raw) throw new Error('Invalid QR value.');
  return raw;
}

function normalizeMethods_(methods) {
  const m = methods || {};
  return {
    driver:String(m.driver || 'SCAN').toUpperCase(),
    car:String(m.car || 'SCAN').toUpperCase(),
    scanner:String(m.scanner || 'SCAN').toUpperCase()
  };
}

function findActiveMaster_(sheetName, key) {
  const target = String(key || '').trim().toUpperCase();
  const index = getMasterIndex_();

  if (!index[sheetName]) {
    throw new Error('Unsupported master sheet: ' + sheetName);
  }

  const row = index[sheetName][target];
  if (!row) return null;

  let activeColumn;

  if (sheetName === 'Drivers') {
    activeColumn = 2;
  } else if (sheetName === 'Cars' || sheetName === 'Scanners') {
    activeColumn = 1;
  }

  return toBool_(row[activeColumn]) ? row : null;
}

function toBool_(v) {
  const s = String(v == null ? '' : v).trim().toUpperCase();
  return v === true || s === 'TRUE' || s === '1' || s === 'ACTIVE' || s === 'AKTIV' || s === 'YES' || s === 'JA';
}

function formatDateTime_(v) {
  if (!v) return '';
  const d = v instanceof Date ? v : new Date(v);
  if (isNaN(d.getTime())) return String(v);
  return Utilities.formatDate(d, tz_(), 'dd.MM.yyyy HH:mm');
}

/* ---------- AUDIT ---------- */

function audit_(session, action, assignmentId, day, details) {
  const s = getSheet_('Audit');
  s.appendRow([
    new Date(),
    session.username,
    session.name,
    session.role,
    action,
    assignmentId || '',
    day || '',
    details || ''
  ]);
}
