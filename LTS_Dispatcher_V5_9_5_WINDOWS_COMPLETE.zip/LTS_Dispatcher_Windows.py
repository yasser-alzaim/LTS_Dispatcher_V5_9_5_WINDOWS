#!/usr/bin/env python3
# LTS Dispatcher V5.9.5 WINDOWS — shared FleetControl Drivers + Windows WhatsApp/Outlook automation
import csv, json, re, time, threading, subprocess, urllib.request, urllib.parse, ssl, difflib, os, sys
from pathlib import Path
from datetime import datetime, timedelta, date
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog

try:
    from openpyxl import load_workbook
except Exception:
    load_workbook = None

APP_NAME = "LTS Dispatcher"
APP_HOME = Path.home() / ".lts_dispatcher"
LOG_DIR = APP_HOME / "logs"
HISTORY_FILE = APP_HOME / "history.csv"
TEMPLATES_FILE = APP_HOME / "templates.json"
SCHEDULE_FILE = APP_HOME / "scheduled_jobs.json"
GOOGLE_CONFIG_FILE = APP_HOME / "google_sheets.json"

DEFAULT_TEMPLATES = {
    "General": "Hallo {name},\n\nhier ist eine Nachricht von LTS Transport.\n\nFahrer-ID: {id}\n\nMit freundlichen Grüßen\nLTS Transport",
    "QR Code": "Hallo {name},\n\nhier ist dein persönlicher LTS Fahrer-QR-Code.\n\nFahrer-ID: {id}\n\nMit freundlichen Grüßen\nLTS Transport",
    "Please call dispatch": "Hallo {name},\n\nbitte melde dich bei der Disposition.\n\nFahrer-ID: {id}\n\nMit freundlichen Grüßen\nLTS Transport",
    "Shift information": "Hallo {name},\n\nbitte beachte die neue Information zu deinem Dienst.\n\nFahrer-ID: {id}\n\nMit freundlichen Grüßen\nLTS Transport",
    "Shift reminder": "Hey {name} 👋\n\nErinnerung: Bitte sei am {shift_date} um {report_time} im Büro.\n\nSei pünktlich und gute Fahrt",
}

ALIASES = {
    "id": ["driver id","driverid","id","fahrer id","fahrer-id"],
    "name": ["name","driver name","fahrer","fahrer name"],
    "email": ["email","e-mail","e-mail fahrer","fahrer email","email fahrer"],
    "phone": ["whatsapp phone","phone","mobile","handy","handy nummer","dienst nummer"],
    "status": ["status","active","aktiv"],
    "preferred": ["preferred channel","channel","preferred"],
    "group": ["group","gruppe","team","depot","location"],
    "notes": ["notes","note","notizen","bemerkung","bemerkungen"],
    "language": ["language","sprache"],
    "last_contacted": ["last contacted","letzter kontakt","last contact"],
}

def clean(v): return re.sub(r"\s+", " ", str(v or "").strip()).lower()

def normalize_name(v):
    """
    Strong driver-name normalization used only for matching.

    Ignores:
    - LTS prefix
    - accents/diacritics
    - punctuation/hyphens/apostrophes
    - duplicate spaces
    - trailing duplicate markers such as "1"
    """
    import unicodedata
    s=unicodedata.normalize("NFKC",str(v or "")).replace("\u00a0"," ").strip()
    s=re.sub(r"^\s*LTS(?:[\s._-]+|$)","",s,flags=re.I)
    s=re.sub(r"\s+\d+\s*$","",s)
    s=unicodedata.normalize("NFKD",s)
    s="".join(ch for ch in s if not unicodedata.combining(ch))
    s=s.casefold()
    s=re.sub(r"[^a-z0-9]+"," ",s)
    return re.sub(r"\s+"," ",s).strip()

def normalize_phone_key(v):
    digits=re.sub(r"\D","",str(v or ""))
    if digits.startswith("00"):
        digits=digits[2:]
    if digits.startswith("0") and not digits.startswith("00"):
        digits="43"+digits[1:]
    return digits

def normalize_email_key(v):
    return str(v or "").strip().casefold()

def display_phone(v):
    """Readable display format while keeping WhatsApp normalization separate."""
    raw=str(v or "").strip()
    digits=re.sub(r"\D","",raw)
    if not digits:
        return ""
    if digits.startswith("0043"):
        local=digits[4:]
    elif digits.startswith("43"):
        local=digits[2:]
    elif digits.startswith("0"):
        local=digits[1:]
    else:
        # Keep unknown international/local numbers readable without inventing country.
        return raw
    if len(local)<=3:
        return "+43 " + local
    return "+43 " + local[:3] + " " + local[3:]


def normalize_status_label(v):
    """Normalize Fleet boolean Active values and Dispatcher text status values."""
    raw=str(v if v is not None else "").strip()
    key=clean(raw)
    if key in ("true","1","yes","ja","active","aktiv"):
        return "Active"
    if key in ("false","0","no","nein","inactive","inaktiv","not active"):
        return "Not Active"
    return raw

def driver_is_inactive(r):
    return normalize_status_label((r or {}).get("status","")) == "Not Active"

def token_sorted_name(v):
    parts=normalize_name(v).split()
    return " ".join(sorted(parts))

def safe_fuzzy_contact(tp_name, contacts):
    """
    Returns one contact only when the fuzzy result is strong and unambiguous.
    This prevents a spelling correction from silently choosing the wrong driver.
    """
    target=token_sorted_name(tp_name)
    if not target:
        return None

    scored=[]
    for r in contacts:
        candidate=token_sorted_name(r.get("name",""))
        if not candidate:
            continue
        score=difflib.SequenceMatcher(None,target,candidate).ratio()
        scored.append((score,r))

    if not scored:
        return None

    scored.sort(key=lambda x:x[0],reverse=True)
    best_score,best=scored[0]
    second_score=scored[1][0] if len(scored)>1 else 0.0

    # High threshold + clear gap = safe auto-match.
    if best_score>=0.90 and (best_score-second_score)>=0.05:
        return best
    return None

GERMAN_DAYS=["Montag","Dienstag","Mittwoch","Donnerstag","Freitag","Samstag","Sonntag"]

def first_shift_time(shift_text):
    if not shift_text:
        return None
    m=re.search(r"(?<!\d)([01]?\d|2[0-3]):([0-5]\d)(?!\d)",str(shift_text))
    if not m:
        return None
    return f"{int(m.group(1)):02d}:{m.group(2)}"

def time_minus_minutes(hhmm, minutes=30):
    if not hhmm:
        return ""
    try:
        t=datetime.strptime(hhmm,"%H:%M")
        return (t-timedelta(minutes=minutes)).strftime("%H:%M")
    except Exception:
        return ""


def shift_time_options():
    # Full 24-hour clock in 15-minute steps.
    times=[]
    t=datetime(2000,1,1,0,0)
    end=datetime(2000,1,1,23,45)
    while t<=end:
        times.append(t.strftime("%H:%M"))
        t+=timedelta(minutes=15)
    return times

def parse_shift_range(shift_text):
    found=re.findall(r"(?<!\d)([01]?\d|2[0-3]):([0-5]\d)(?!\d)",str(shift_text or ""))
    vals=[f"{int(h):02d}:{m}" for h,m in found]
    if len(vals)>=2:
        return vals[0],vals[1]
    if len(vals)==1:
        return vals[0],""
    return "",""

def build_tp_shift(start_time,end_time):
    return f"VIE{start_time}-{end_time}"

def normalize_phone(v, cc="43"):
    d = re.sub(r"\D", "", str(v or ""))
    if d.startswith("00"): d = d[2:]
    cc = re.sub(r"\D", "", cc or "43")
    if d.startswith("0") and cc: d = cc + d.lstrip("0")
    return d

def osa(script, timeout=60):
    p = subprocess.run(["osascript","-e",script], capture_output=True, text=True, timeout=timeout)
    if p.returncode != 0:
        raise RuntimeError(p.stderr.strip() or "AppleScript failed.")
    return p.stdout.strip()

def osa_escape(s):
    return str(s).replace("\\","\\\\").replace('"','\\"')

class WhatsAppRecipientError(RuntimeError):
    """Raised when WhatsApp rejects the destination number/chat."""

def history_result_for_exception(exc):
    return "NO WHATSAPP" if isinstance(exc, WhatsAppRecipientError) else "FAILED"

def format_duration(seconds):
    try:
        seconds=max(0,int(round(float(seconds))))
    except Exception:
        return "--"
    mins,secs=divmod(seconds,60)
    hours,mins=divmod(mins,60)
    if hours:
        return f"{hours}h {mins:02d}m"
    if mins:
        return f"{mins}m {secs:02d}s"
    return f"{secs}s"

def ensure_dirs():
    APP_HOME.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    if not HISTORY_FILE.exists():
        with HISTORY_FILE.open("w", newline="", encoding="utf-8-sig") as f:
            csv.writer(f).writerow(["Timestamp","Driver ID","Name","Channel","Action","Result","Detail","Follow-up"])

def history_add(r, channel, action, result, detail="", follow=""):
    ensure_dirs()
    with HISTORY_FILE.open("a", newline="", encoding="utf-8-sig") as f:
        csv.writer(f).writerow([datetime.now().isoformat(timespec="seconds"),r.get("id",""),r.get("name",""),channel,action,result,detail,follow])

    # When Google Sheets is connected, also write Send History online.
    client=globals().get("_GOOGLE_HISTORY_CLIENT")
    if client is not None:
        try:
            client.append_history({
                "Timestamp": datetime.now().isoformat(timespec="seconds"),
                "Driver ID": r.get("id",""),
                "Name": r.get("name",""),
                "Channel": channel,
                "Action": action,
                "Result": result,
                "Detail": detail,
                "Follow-up": follow,
            })
        except Exception:
            # Local history must never fail just because the network is unavailable.
            pass


class GoogleSheetsClient:
    def __init__(self,url="",token="",tp_spreadsheet_id="",driver_spreadsheet_id="",driver_sheet_name="Drivers"):
        self.url=str(url or "").strip()
        self.token=str(token or "").strip()
        self.tp_spreadsheet_id=str(tp_spreadsheet_id or "").strip()
        self.driver_spreadsheet_id=str(driver_spreadsheet_id or "").strip()
        self.driver_sheet_name=str(driver_sheet_name or "Drivers").strip() or "Drivers"

    def configured(self):
        return self.url.startswith("http") and bool(self.token)

    def _call(self,action,payload=None,timeout=45):
        if not self.configured():
            raise RuntimeError("Google Sheets is not configured.")

        body={
            "action":action,
            "token":self.token,
        }
        if payload:
            body.update(payload)

        data=json.dumps(body,ensure_ascii=False).encode("utf-8")
        req=urllib.request.Request(
            self.url,
            data=data,
            headers={"Content-Type":"application/json; charset=utf-8"},
            method="POST"
        )

        try:
            # macOS Monterey / older Python installations can have an incomplete
            # local certificate store. Use certifi's maintained CA bundle for
            # Google HTTPS verification.
            try:
                import certifi
                context=ssl.create_default_context(cafile=certifi.where())
            except Exception:
                context=ssl.create_default_context()

            with urllib.request.urlopen(req,timeout=timeout,context=context) as resp:
                raw=resp.read().decode("utf-8")
        except Exception as e:
            msg=str(e)
            extra=""
            if "CERTIFICATE_VERIFY_FAILED" in msg:
                extra=(
                    "\n\nSSL certificate verification failed on this computer. "
                    "Run INSTALL.command again so the certifi certificate bundle is installed."
                )
            raise RuntimeError(
                "Could not connect to the Google Sheets backend.\n\n"
                "Check the Apps Script Web App URL, API token and internet connection."
                + extra +
                "\n\nDetails: " + msg
            )

        try:
            obj=json.loads(raw)
        except Exception:
            raise RuntimeError("Google Sheets backend returned an invalid response.")

        if not obj.get("ok"):
            raise RuntimeError(str(obj.get("error") or "Google Sheets request failed."))
        return obj

    def ping(self):
        return self._call("ping")

    def _driver_source(self):
        return {
            "driver_spreadsheet_id":self.driver_spreadsheet_id,
            "driver_sheet_name":self.driver_sheet_name,
        }

    def contacts(self):
        return self._call("getContacts",self._driver_source()).get("contacts",[])

    def sync_contact_layout(self):
        return self._call("syncContactLayout",self._driver_source())

    def migrate_contacts_to_fleet(self,source_sheet_name="Contacts"):
        payload=self._driver_source()
        payload["source_sheet_name"]=str(source_sheet_name or "Contacts").strip() or "Contacts"
        return self._call("migrateContactsToFleet",payload,timeout=120)

    def add_driver(self,data):
        payload=self._driver_source()
        payload["driver"]=data
        return self._call("addDriver",payload)

    def edit_driver(self,original_id,data):
        payload=self._driver_source()
        payload.update({"original_id":str(original_id),"driver":data})
        return self._call("editDriver",payload)

    def delete_driver(self,driver_id):
        payload=self._driver_source()
        payload["driver_id"]=str(driver_id)
        return self._call("deleteDriver",payload)

    def update_field(self,driver_id,key,value):
        payload=self._driver_source()
        payload.update({
            "driver_id":str(driver_id),
            "key":str(key),
            "value":value
        })
        return self._call("updateField",payload)

    def append_history(self,data):
        return self._call("appendHistory",{"history":data},timeout=20)

    def get_shifts(self,date_text):
        return self._call("getShifts",{
            "date":str(date_text),
            "tp_spreadsheet_id":self.tp_spreadsheet_id
        }).get("shifts",[])

    def add_shift(self,date_text,name,shift_text,driver=None):
        driver=driver or {}
        return self._call("addShift",{
            "date":str(date_text),
            "name":str(name),
            "shift_text":str(shift_text),
            "driver_id":str(driver.get("id","")),
            "phone":str(driver.get("phone","")),
            "email":str(driver.get("email","")),
            "tp_spreadsheet_id":self.tp_spreadsheet_id
        })

    def edit_shift(self,date_text,row_number,name,shift_text,driver=None):
        driver=driver or {}
        return self._call("editShift",{
            "date":str(date_text),
            "row_number":int(row_number),
            "name":str(name),
            "shift_text":str(shift_text),
            "driver_id":str(driver.get("id","")),
            "phone":str(driver.get("phone","")),
            "email":str(driver.get("email","")),
            "tp_spreadsheet_id":self.tp_spreadsheet_id
        })

    def delete_shift(self,date_text,row_number):
        return self._call("deleteShift",{
            "date":str(date_text),
            "row_number":int(row_number),
            "tp_spreadsheet_id":self.tp_spreadsheet_id
        })


class GoogleSetupDialog(tk.Toplevel):
    def __init__(self,parent,current,on_save):
        super().__init__(parent)
        self.title("Google Sheets Setup")
        self.transient(parent)
        self.grab_set()
        self.geometry("820x470")
        self.resizable(True,False)
        self.on_save=on_save

        self.url=tk.StringVar(value=current.get("url",""))
        self.token=tk.StringVar(value=current.get("token",""))
        self.tp_spreadsheet_id=tk.StringVar(value=current.get("tp_spreadsheet_id",""))
        self.driver_spreadsheet_id=tk.StringVar(value=current.get("driver_spreadsheet_id",""))
        self.driver_sheet_name=tk.StringVar(value=current.get("driver_sheet_name","Drivers") or "Drivers")

        frm=ttk.Frame(self,padding=14)
        frm.pack(fill="both",expand=True)

        ttk.Label(frm,text="Apps Script Web App URL").grid(row=0,column=0,sticky="w",pady=5)
        ttk.Entry(frm,textvariable=self.url,width=72).grid(row=0,column=1,sticky="ew",padx=6,pady=5)

        ttk.Label(frm,text="API Token").grid(row=1,column=0,sticky="w",pady=5)
        ttk.Entry(frm,textvariable=self.token,width=72,show="•").grid(row=1,column=1,sticky="ew",padx=6,pady=5)

        ttk.Label(frm,text="TP Spreadsheet ID").grid(row=2,column=0,sticky="w",pady=5)
        ttk.Entry(frm,textvariable=self.tp_spreadsheet_id,width=72).grid(row=2,column=1,sticky="ew",padx=6,pady=5)

        ttk.Label(frm,text="Fleet / Driver Spreadsheet ID").grid(row=3,column=0,sticky="w",pady=5)
        ttk.Entry(frm,textvariable=self.driver_spreadsheet_id,width=72).grid(row=3,column=1,sticky="ew",padx=6,pady=5)

        ttk.Label(frm,text="Driver sheet tab name").grid(row=4,column=0,sticky="w",pady=5)
        ttk.Entry(frm,textvariable=self.driver_sheet_name,width=28).grid(row=4,column=1,sticky="w",padx=6,pady=5)

        ttk.Label(
            frm,
            text=(
                "Set Fleet / Driver Spreadsheet ID to the LTS_FleetControl spreadsheet. "
                "Dispatcher will touch ONLY the selected Drivers tab; Cars, Scanners, Changes, Audit, "
                "DAY_TEMPLATE and daily Fleet tabs are left alone."
            ),
            wraplength=620,
            justify="left"
        ).grid(row=5,column=0,columnspan=2,sticky="w",pady=(3,8))

        buttons=ttk.Frame(frm)
        buttons.grid(row=6,column=0,columnspan=2,sticky="e",pady=(14,0))
        ttk.Button(buttons,text="Cancel",command=self.destroy).pack(side="right",padx=4)
        ttk.Button(buttons,text="SAVE & CONNECT",command=self.save).pack(side="right",padx=4)
        frm.columnconfigure(1,weight=1)

    def save(self):
        url=self.url.get().strip()
        token=self.token.get().strip()
        if not url or not token:
            return messagebox.showwarning(APP_NAME,"Web App URL and API Token are required.",parent=self)
        self.on_save({
            "url":url,
            "token":token,
            "tp_spreadsheet_id":self.tp_spreadsheet_id.get().strip(),
            "driver_spreadsheet_id":self.driver_spreadsheet_id.get().strip(),
            "driver_sheet_name":self.driver_sheet_name.get().strip() or "Drivers",
        })
        self.destroy()

class Store:
    def __init__(self):
        self.rows=[]; self.path=None
        self.mode="local"
        self.google=None

    def ready(self):
        return bool(self.rows) or self.path is not None or (self.mode=="google" and self.google is not None)

    def configure_google(self,url,token,tp_spreadsheet_id="",driver_spreadsheet_id="",driver_sheet_name="Drivers"):
        self.google=GoogleSheetsClient(
            url,token,tp_spreadsheet_id,driver_spreadsheet_id,driver_sheet_name
        )
        self.google.ping()
        # When Fleet is the driver source, make sure the Dispatcher contact columns
        # exist without deleting/reordering FleetControl columns or touching QR cells.
        if str(driver_spreadsheet_id or "").strip():
            self.google.sync_contact_layout()
        self.mode="google"
        self.path=None
        globals()["_GOOGLE_HISTORY_CLIENT"]=self.google
        self.refresh_google()

    def parse_google_contacts(self,raw):
        out=[]
        for rn,item in enumerate(raw,start=2):
            normalized={clean(k):v for k,v in dict(item or {}).items()}
            def val(key):
                for alias in ALIASES.get(key,[]):
                    if alias in normalized and normalized[alias] is not None:
                        return str(normalized[alias]).strip()
                return ""
            did=val("id")
            name=val("name")
            if not did and not name:
                continue
            out.append({
                "id":did,
                "name":name,
                "email":val("email"),
                "phone":display_phone(val("phone")),
                "status":normalize_status_label(val("status")),
                "notes":val("notes"),
                "last_contacted":val("last_contacted"),
                "preferred":val("preferred"),
                "group":val("group"),
                "language":val("language"),
                "row":rn,
            })
        return out

    def refresh_google(self):
        if not self.google:
            raise RuntimeError("Google Sheets is not configured.")
        self.rows=self.parse_google_contacts(self.google.contacts())
        self.mode="google"

    def source_name(self):
        if self.mode=="google":
            if self.google and self.google.driver_spreadsheet_id:
                return f"FleetControl / {self.google.driver_sheet_name}"
            return "Google Sheets"
        return self.path.name if self.path else "database"

    def _find(self, headers, key, required=False):
        h=[clean(x) for x in headers]
        for a in ALIASES[key]:
            if a in h: return h.index(a)
        if required: raise ValueError(f'Missing required column: {key}')
        return None

    def load(self, path):
        self.mode="local"
        globals()["_GOOGLE_HISTORY_CLIENT"]=None
        self.path=Path(path)
        if self.path.suffix.lower()==".csv":
            with self.path.open("r",encoding="utf-8-sig",newline="") as f: matrix=list(csv.reader(f))
        elif self.path.suffix.lower() in (".xlsx",".xlsm"):
            if load_workbook is None: raise RuntimeError("Run INSTALL.command first.")
            wb=load_workbook(self.path,read_only=True,data_only=True)
            ws=wb["Contacts"] if "Contacts" in wb.sheetnames else wb[wb.sheetnames[0]]
            matrix=[list(r) for r in ws.iter_rows(values_only=True)]; wb.close()
        else: raise ValueError("Use .xlsx, .xlsm or .csv")
        if not matrix: self.rows=[]; return
        headers=matrix[0]
        cols={k:self._find(headers,k,k in ("id","name")) for k in ALIASES}
        out=[]
        for rn,row in enumerate(matrix[1:],start=2):
            row=list(row)
            c=cols["id"]
            if c is None or c>=len(row): continue
            did=str(row[c] or "").strip()
            if not did: continue
            def get(k):
                c=cols[k]
                return str(row[c] or "").strip() if c is not None and c<len(row) else ""
            item={k:get(k) for k in ALIASES} | {"row":rn}
            item["phone"]=display_phone(item.get("phone",""))
            item["status"]=normalize_status_label(item.get("status",""))
            item["preferred"]=""
            item["group"]=""
            self._unused=item.get("language","")
            out.append(item)
        self.rows=out

    def refresh(self):
        if self.mode=="google":
            return self.refresh_google()
        self.load(self.path)

    def groups(self): return sorted({r["group"] for r in self.rows if r.get("group")})

    def _ensure_col(self, ws, key, header):
        headers=[c.value for c in ws[1]]
        idx=self._find(headers,key,False)
        if idx is not None: return idx+1
        c=ws.max_column+1; ws.cell(1,c,header); return c

    def add_driver(self, d):
        if not d.get("id") or not d.get("name"):
            raise ValueError("Driver ID and Name are required.")
        duplicate_id=next((x for x in self.rows if x.get("id","").lower()==d["id"].lower()),None)
        if duplicate_id:
            raise ValueError(
                f"Driver ID {d['id']} already exists: {duplicate_id.get('name','')}"
            )

        new_phone=normalize_phone_key(d.get("phone",""))
        if new_phone:
            duplicate_phone=next(
                (x for x in self.rows if normalize_phone_key(x.get("phone",""))==new_phone),
                None
            )
            if duplicate_phone:
                raise ValueError(
                    "This WhatsApp phone is already assigned to "
                    f"{duplicate_phone.get('name','')} (Driver ID {duplicate_phone.get('id','')})."
                )

        if self.mode=="google":
            self.google.add_driver(d)
            self.refresh_google()
            return

        if not self.path or self.path.suffix.lower() not in (".xlsx",".xlsm"):
            raise ValueError("Adding drivers requires an Excel file or Google Sheets.")
        wb=load_workbook(self.path); ws=wb["Contacts"] if "Contacts" in wb.sheetnames else wb[wb.sheetnames[0]]
        labels={"id":"Driver ID","name":"Name","phone":"WhatsApp Phone","email":"Email","status":"Status","last_contacted":"Last Contacted","notes":"Notes"}
        r=ws.max_row+1
        for k,h in labels.items(): ws.cell(r,self._ensure_col(ws,k,h),d.get(k,""))
        wb.save(self.path); wb.close(); self.refresh()

    def update(self, did, key, value):
        if self.mode=="google":
            self.google.update_field(did,key,value)
            wanted=str(did).strip().casefold()
            for r in self.rows:
                if str(r.get("id","")).strip().casefold()==wanted:
                    r[key]=value
                    break
            return
        if not self.path or self.path.suffix.lower() not in (".xlsx",".xlsm"):
            return
        wb=load_workbook(self.path); ws=wb["Contacts"] if "Contacts" in wb.sheetnames else wb[wb.sheetnames[0]]
        headers=[c.value for c in ws[1]]; idc=self._find(headers,"id",True)+1
        label={"notes":"Notes","last_contacted":"Last Contacted","status":"Status"}.get(key,key.title())
        tc=self._ensure_col(ws,key,label)
        for r in range(2,ws.max_row+1):
            if str(ws.cell(r,idc).value or "").strip()==str(did):
                ws.cell(r,tc,value); break
        wb.save(self.path); wb.close(); self.refresh()

    def _backup_file(self):
        if not self.path or not self.path.exists():
            return None
        stamp=datetime.now().strftime("%Y%m%d_%H%M%S")
        backup=self.path.with_name(f"{self.path.stem}_backup_{stamp}{self.path.suffix}")
        import shutil
        shutil.copy2(self.path, backup)
        return backup

    def edit_driver(self, original_id, data):
        new_id=str(data.get("id","")).strip()
        name=str(data.get("name","")).strip()
        if not new_id or not name:
            raise ValueError("Driver ID and Name are required.")

        for r in self.rows:
            if r["id"].lower()==new_id.lower() and r["id"].lower()!=str(original_id).lower():
                raise ValueError(f"Driver ID {new_id} already exists.")

        new_phone=normalize_phone_key(data.get("phone",""))
        if new_phone:
            for r in self.rows:
                if str(r.get("id","")).casefold()==str(original_id).casefold():
                    continue
                if normalize_phone_key(r.get("phone",""))==new_phone:
                    raise ValueError(
                        "This WhatsApp phone is already assigned to "
                        f"{r.get('name','')} (Driver ID {r.get('id','')})."
                    )

        if self.mode=="google":
            self.google.edit_driver(original_id,data)
            self.refresh_google()
            return

        if not self.path or self.path.suffix.lower() not in (".xlsx",".xlsm"):
            raise ValueError("Editing drivers requires an Excel file or Google Sheets.")

        # Edit the currently loaded Excel file directly.
        # No extra backup/copy is created when editing a driver.
        wb=load_workbook(self.path)
        ws=wb["Contacts"] if "Contacts" in wb.sheetnames else wb[wb.sheetnames[0]]
        headers=[c.value for c in ws[1]]
        idc=self._find(headers,"id",True)+1

        labels={
            "id":"Driver ID","name":"Name","phone":"WhatsApp Phone","email":"Email",
            "status":"Status","last_contacted":"Last Contacted","notes":"Notes"
        }
        cols={k:self._ensure_col(ws,k,h) for k,h in labels.items()}

        target=None
        for rr in range(2,ws.max_row+1):
            if str(ws.cell(rr,idc).value or "").strip()==str(original_id):
                target=rr
                break

        if target is None:
            wb.close()
            raise ValueError(f"Driver ID {original_id} not found.")

        for k,c in cols.items():
            ws.cell(target,c,data.get(k,""))

        wb.save(self.path)
        wb.close()
        self.refresh()

    def delete_driver(self, driver_id):
        if self.mode=="google":
            self.google.delete_driver(driver_id)
            self.refresh_google()
            return

        if not self.path or self.path.suffix.lower() not in (".xlsx",".xlsm"):
            raise ValueError("Deleting drivers requires an Excel file or Google Sheets.")

        self._backup_file()

        wb=load_workbook(self.path)
        ws=wb["Contacts"] if "Contacts" in wb.sheetnames else wb[wb.sheetnames[0]]
        headers=[c.value for c in ws[1]]
        idc=self._find(headers,"id",True)+1

        target=None
        for rr in range(2,ws.max_row+1):
            if str(ws.cell(rr,idc).value or "").strip()==str(driver_id):
                target=rr
                break

        if target is None:
            wb.close()
            raise ValueError(f"Driver ID {driver_id} not found.")

        ws.delete_rows(target,1)
        wb.save(self.path)
        wb.close()
        self.refresh()


class DienstplanReader:
    """
    TP list reader/editor.

    Google mode uses the SAME spreadsheet as Contacts.
    Daily sheet: DD.MM.YYYY
    B = SCHICHT
    C = NAME
    Data starts row 4.
    """
    def __init__(self):
        self.path=None
        self._wb=None
        self.google=None
        self.mode="local"

    def use_google(self,client):
        self.close()
        self.google=client
        self.mode="google"
        self.path=None

    def close(self):
        if self._wb is not None:
            try:self._wb.close()
            except Exception:pass
        self._wb=None

    def load(self,path):
        p=Path(path)
        if not p.exists(): raise FileNotFoundError(str(p))
        if p.suffix.lower() not in (".xlsx",".xlsm"):
            raise ValueError("TP list must be an Excel .xlsx/.xlsm file.")
        if load_workbook is None: raise RuntimeError("Run INSTALL.command first.")
        if self.path is not None and Path(self.path)==p and self.mode=="local":
            return
        self.close()
        wb=load_workbook(p,read_only=True,data_only=True)
        try:
            daily=[s for s in wb.sheetnames if re.fullmatch(r"\d{2}\.\d{2}\.\d{4}",s)]
            if not daily: raise ValueError("No daily sheets named DD.MM.YYYY were found.")
        finally:
            wb.close()
        self.path=p
        self.mode="local"

    def _sheet_name(self,target_date):
        if isinstance(target_date,str):
            target_date=datetime.strptime(target_date,"%Y-%m-%d").date()
        return target_date.strftime("%d.%m.%Y")

    def _date_iso(self,target_date):
        if isinstance(target_date,str):
            target_date=datetime.strptime(target_date,"%Y-%m-%d").date()
        return target_date.strftime("%Y-%m-%d")

    def _start_minutes(self,shift_text):
        t=first_shift_time(shift_text)
        if not t:return 999999
        h,m=map(int,t.split(":"))
        return h*60+m

    def shifts_for_date(self,target_date):
        if isinstance(target_date,str):
            d=datetime.strptime(target_date,"%Y-%m-%d").date()
        else:
            d=target_date

        if self.mode=="google":
            if not self.google: raise ValueError("Google Sheets is not connected.")
            raw=self.google.get_shifts(self._date_iso(d))
            out=[]
            for item in raw:
                shift_text=str(item.get("shift_text","") or "").strip()
                name=str(item.get("name","") or "").replace("\u00a0"," ").strip()
                if name:
                    out.append({
                        "name":name,
                        "name_key":normalize_name(name),
                        "shift_date":d.strftime("%Y-%m-%d"),
                        "shift_date_de":d.strftime("%d.%m.%Y"),
                        "shift_day":GERMAN_DAYS[d.weekday()],
                        "shift_text":shift_text,
                        "shift_start":first_shift_time(shift_text) or "",
                        "tp_row":int(item.get("row_number",0) or 0),
                    })
            return out

        if not self.path: raise ValueError("Choose the TP list file first.")
        sheet_name=self._sheet_name(d)

        if self._wb is None:
            self._wb=load_workbook(self.path)

        if sheet_name not in self._wb.sheetnames:
            raise ValueError(f'No sheet "{sheet_name}" exists in the TP list.')

        ws=self._wb[sheet_name]
        out=[]
        for row_number in range(4,max(ws.max_row or 4,4)+1):
            shift_text=str(ws.cell(row_number,2).value or "").strip()
            name=str(ws.cell(row_number,3).value or "").replace("\u00a0"," ").strip()
            if name:
                out.append({
                    "name":name,
                    "name_key":normalize_name(name),
                    "shift_date":d.strftime("%Y-%m-%d"),
                    "shift_date_de":d.strftime("%d.%m.%Y"),
                    "shift_day":GERMAN_DAYS[d.weekday()],
                    "shift_text":shift_text,
                    "shift_start":first_shift_time(shift_text) or "",
                    "tp_row":row_number,
                })
        return out

    def _get_local_sheet(self,target_date):
        if not self.path: raise ValueError("Choose the TP list file first.")
        if self._wb is None:self._wb=load_workbook(self.path)
        name=self._sheet_name(target_date)
        if name not in self._wb.sheetnames:
            raise ValueError(f'No sheet "{name}" exists in the TP list.')
        return self._wb,self._wb[name]

    def _find_insert_row(self,ws,shift_text):
        new_minutes=self._start_minutes(shift_text)
        last=max(ws.max_row or 4,4)
        for row in range(4,last+1):
            existing=str(ws.cell(row,2).value or "").strip()
            name=str(ws.cell(row,3).value or "").strip()
            if not existing and not name:continue
            if new_minutes < self._start_minutes(existing):return row
        return last+1

    def add_shift(self,target_date,name,shift_text,driver=None):
        driver=driver or {}
        if self.mode=="google":
            return self.google.add_shift(self._date_iso(target_date),name,shift_text,driver)

        wb,ws=self._get_local_sheet(target_date)
        row=self._find_insert_row(ws,shift_text)
        ws.insert_rows(row,1)
        ws.cell(row,2,shift_text)
        ws.cell(row,3,name)
        ws.cell(row,24,str(driver.get("id","")))
        ws.cell(row,25,str(driver.get("phone","")))
        ws.cell(row,26,str(driver.get("email","")))
        wb.save(self.path)
        return row

    def edit_shift(self,target_date,tp_row,name,shift_text,driver=None):
        driver=driver or {}
        if self.mode=="google":
            return self.google.edit_shift(self._date_iso(target_date),tp_row,name,shift_text,driver)

        wb,ws=self._get_local_sheet(target_date)
        if not tp_row or int(tp_row)<4:raise ValueError("Invalid TP-list row.")
        row=int(tp_row)
        values=[ws.cell(row,c).value for c in range(1,max(ws.max_column or 3,3)+1)]
        values[1]=shift_text
        values[2]=name
        while len(values)<26:
            values.append(None)
        values[23]=str(driver.get("id",""))
        values[24]=str(driver.get("phone",""))
        values[25]=str(driver.get("email",""))
        ws.delete_rows(row,1)
        target=self._find_insert_row(ws,shift_text)
        ws.insert_rows(target,1)
        for c,v in enumerate(values,start=1):
            ws.cell(target,c,v)
        wb.save(self.path)
        return target

    def delete_shift(self,target_date,tp_row):
        if self.mode=="google":
            return self.google.delete_shift(self._date_iso(target_date),tp_row)

        wb,ws=self._get_local_sheet(target_date)
        if not tp_row or int(tp_row)<4:raise ValueError("Invalid TP-list row.")
        ws.delete_rows(int(tp_row),1)
        wb.save(self.path)

class WhatsApp:
    """WhatsApp Desktop automation.

    Windows uses WhatsApp Desktop + Windows UI Automation. The macOS implementation
    is intentionally not used in this Windows build.
    """
    def __init__(self,status):
        self.status=status

    def _tools(self):
        if os.name!="nt":
            raise RuntimeError("This package is the Windows build of LTS Dispatcher.")
        try:
            import pyperclip
            from pywinauto import Desktop
            from pywinauto.keyboard import send_keys
            return pyperclip, Desktop, send_keys
        except Exception as e:
            raise RuntimeError(
                "Windows automation components are missing. Run INSTALL_WINDOWS.bat first.\n\n" + str(e)
            )

    def accessibility(self):
        # Windows does not use the macOS Accessibility permission. This checks that
        # the automation libraries are installed and WhatsApp can be launched.
        self._tools()
        self.activate()
        return "Windows automation ready"

    def _open_uri(self,uri):
        try:
            os.startfile(uri)
        except Exception as e:
            raise RuntimeError(
                "Windows could not open WhatsApp. Install WhatsApp Desktop from the Microsoft Store "
                "and sign in first.\n\n" + str(e)
            )

    def _wa_window(self, timeout=15):
        _, Desktop, _ = self._tools()
        deadline=time.time()+timeout
        last=None
        while time.time()<deadline:
            try:
                wins=Desktop(backend="uia").windows()
                # Prefer the visible WhatsApp application window, not notifications.
                for w in wins:
                    try:
                        title=(w.window_text() or "").strip()
                        if "whatsapp" in title.casefold() and w.is_visible():
                            return w
                    except Exception as e:
                        last=e
            except Exception as e:
                last=e
            time.sleep(.35)
        raise RuntimeError(
            "WhatsApp Desktop window was not found. Open WhatsApp Desktop, sign in, and try again."
            + (f"\n\n{last}" if last else "")
        )

    def activate(self):
        self._open_uri("whatsapp://")
        time.sleep(1.0)
        w=self._wa_window(12)
        try:
            w.restore()
        except Exception:
            pass
        try:
            w.set_focus()
        except Exception:
            pass
        return True

    def _front_window_text(self):
        try:
            w=self._wa_window(4)
        except Exception:
            return ""
        parts=[]
        try:
            title=w.window_text()
            if title: parts.append(title)
        except Exception:
            pass
        try:
            for c in w.descendants():
                try:
                    s=(c.window_text() or "").strip()
                    if s: parts.append(s)
                except Exception:
                    pass
        except Exception:
            pass
        return " ".join(parts)

    def _dismiss_recipient_error(self):
        try:
            _, Desktop, send_keys = self._tools()
            labels={"ok","okay","done","close","schließen","schliessen","fertig"}
            desktop=Desktop(backend="uia")
            for top in desktop.windows():
                try:
                    if not top.is_visible():
                        continue
                    for c in top.descendants(control_type="Button"):
                        try:
                            name=(c.window_text() or "").strip().casefold()
                            if name in labels:
                                c.click_input()
                                return
                        except Exception:
                            pass
                except Exception:
                    pass
            try:
                self._wa_window(3).set_focus()
                send_keys("{ESC}")
            except Exception:
                pass
        except Exception:
            pass

    def _recipient_error_text(self):
        text=self._front_window_text().strip()
        low=text.casefold()
        markers=(
            "phone number shared via url is invalid",
            "phone number isn't on whatsapp",
            "phone number is not on whatsapp",
            "not on whatsapp",
            "isn't on whatsapp",
            "invalid phone number",
            "invalid number",
            "ungültige telefonnummer",
            "ungueltige telefonnummer",
            "telefonnummer ist nicht bei whatsapp",
            "telefonnummer ist nicht auf whatsapp",
            "nicht auf whatsapp",
        )
        if any(m in low for m in markers):
            self._dismiss_recipient_error()
            return text or "WhatsApp rejected this phone number."
        return ""

    def open_chat(self,phone):
        self._tools()
        self._open_uri(f"whatsapp://send?phone={phone}")
        self.status(f"Opening WhatsApp +{phone}...")
        time.sleep(2.6)
        try:
            self._wa_window(10).set_focus()
        except Exception:
            pass
        time.sleep(.4)
        err=self._recipient_error_text()
        if err:
            raise WhatsAppRecipientError(
                f"Number +{phone} is invalid or not available on WhatsApp. {err}"
            )

    def paste_text(self,text):
        pyperclip, _, send_keys = self._tools()
        w=self._wa_window(6)
        try: w.set_focus()
        except Exception: pass
        pyperclip.copy(str(text or ""))
        time.sleep(.15)
        send_keys("^v", pause=.05)
        time.sleep(.45)

    def _desktop_controls(self):
        _, Desktop, _ = self._tools()
        controls=[]
        try:
            for top in Desktop(backend="uia").windows():
                try:
                    if not top.is_visible():
                        continue
                    controls.append(top)
                    controls.extend(top.descendants())
                except Exception:
                    pass
        except Exception:
            pass
        return controls

    def _click_attachment_menu_item(self, image_file):
        _, _, send_keys = self._tools()
        labels=(
            ("photos & videos","photos and videos","photos","fotos & videos","fotos und videos","bilder & videos","bilder und videos")
            if image_file else
            ("document","documents","file","files","dokument","dokumente","datei","dateien")
        )
        # Official WhatsApp Windows shortcut opens the attachment dropdown.
        send_keys("%a")
        time.sleep(.65)
        for c in self._desktop_controls():
            try:
                name=(c.window_text() or "").strip().casefold()
                if not name:
                    continue
                if any(label==name or label in name for label in labels):
                    try:
                        c.click_input()
                    except Exception:
                        c.invoke()
                    return True
            except Exception:
                pass
        # Fallback to menu position: photos/videos is normally first, document third.
        if image_file:
            send_keys("{HOME}{ENTER}")
        else:
            send_keys("{HOME}{DOWN 2}{ENTER}")
        return True

    def _choose_file_dialog(self,path, timeout=12):
        _, Desktop, send_keys = self._tools()
        p=str(Path(path).resolve())
        deadline=time.time()+timeout
        dlg=None
        while time.time()<deadline:
            for w in Desktop(backend="uia").windows():
                try:
                    if not w.is_visible():
                        continue
                    # Standard Windows Open dialog normally has one or more Edit controls.
                    edits=w.descendants(control_type="Edit")
                    buttons=w.descendants(control_type="Button")
                    bnames=" ".join((b.window_text() or "") for b in buttons).casefold()
                    title=(w.window_text() or "").casefold()
                    if edits and ("open" in bnames or "öffnen" in bnames or "oeffnen" in bnames or "open" in title or "öffnen" in title):
                        dlg=w
                        break
                except Exception:
                    pass
            if dlg is not None:
                break
            time.sleep(.25)
        if dlg is None:
            raise RuntimeError("Windows file picker did not open in WhatsApp.")
        try: dlg.set_focus()
        except Exception: pass

        edit=None
        try:
            edit=dlg.child_window(auto_id="1148", control_type="Edit")
            if not edit.exists(timeout=.5): edit=None
        except Exception:
            edit=None
        if edit is None:
            edits=dlg.descendants(control_type="Edit")
            if edits:
                # File name field is usually the last editable text field.
                edit=edits[-1]
        if edit is None:
            raise RuntimeError("Could not find the File name field in the Windows file picker.")
        try:
            edit.set_focus()
            edit.set_edit_text(p)
        except Exception:
            edit.click_input()
            send_keys("^a")
            send_keys(p, with_spaces=True)
        time.sleep(.2)
        send_keys("{ENTER}")
        time.sleep(1.2)

    def paste_file(self,path):
        p=Path(path).expanduser().resolve()
        if not p.exists():
            raise RuntimeError(f"Attachment not found: {p}")
        image_file=p.suffix.casefold() in {".png",".jpg",".jpeg",".gif",".webp",".bmp",".heic"}
        w=self._wa_window(6)
        try: w.set_focus()
        except Exception: pass
        self._click_attachment_menu_item(image_file)
        self._choose_file_dialog(p)

    def _press_send(self):
        _, _, send_keys = self._tools()
        w=self._wa_window(5)
        try: w.set_focus()
        except Exception: pass
        send_keys("{ENTER}")
        time.sleep(1.0)

    def send(self,phone,text,attachments):
        self.open_chat(phone)
        err=self._recipient_error_text()
        if err:
            raise WhatsAppRecipientError(
                f"Number +{phone} is invalid or not available on WhatsApp. {err}"
            )

        attachments=[p for p in (attachments or []) if p]
        if attachments:
            # First attachment carries the text as its caption; additional files are
            # sent as separate WhatsApp messages. This is more reliable on Windows.
            for i,p in enumerate(attachments):
                self.paste_file(p)
                if i==0 and text:
                    self.paste_text(text)
                err=self._recipient_error_text()
                if err:
                    raise WhatsAppRecipientError(
                        f"Number +{phone} is invalid or not available on WhatsApp. {err}"
                    )
                self.status("Sending WhatsApp...")
                self._press_send()
            return

        if text:
            self.paste_text(text)
        err=self._recipient_error_text()
        if err:
            raise WhatsAppRecipientError(
                f"Number +{phone} is invalid or not available on WhatsApp. {err}"
            )
        self.status("Sending WhatsApp...")
        self._press_send()

    def call(self,phone):
        self.open_chat(phone)
        labels=("voice call","audio call","call","sprachanruf","anruf","audioanruf")
        w=self._wa_window(8)
        try:
            buttons=w.descendants(control_type="Button")
        except Exception:
            buttons=[]
        for b in buttons:
            try:
                name=(b.window_text() or "").strip().casefold()
                if not name:
                    # Some UIA buttons expose a help/description instead of text.
                    try:
                        name=str(b.element_info.name or "").strip().casefold()
                    except Exception:
                        name=""
                if any(x in name for x in labels) and "video" not in name:
                    b.click_input()
                    return True
            except Exception:
                pass
        raise RuntimeError(
            "The WhatsApp chat opened, but the voice-call button was not found automatically. "
            "Messaging still works."
        )

class Mailer:
    """Windows email through classic Microsoft Outlook desktop (MAPI/COM)."""
    def _outlook(self):
        if os.name!="nt":
            raise RuntimeError("This package is the Windows build of LTS Dispatcher.")
        try:
            import win32com.client
            app=win32com.client.Dispatch("Outlook.Application")
            return app
        except Exception as e:
            raise RuntimeError(
                "Microsoft Outlook desktop could not be opened.\n\n"
                "Install/sign in to classic Outlook for Windows, then run INSTALL_WINDOWS.bat.\n\n"
                + str(e)
            )

    def test_setup(self):
        app=self._outlook()
        try:
            ns=app.GetNamespace("MAPI")
            # Accessing Stores forces MAPI initialization and catches most setup issues.
            count=ns.Stores.Count
            return f"OK|Outlook|Stores:{count}"
        except Exception as e:
            raise RuntimeError(
                "Outlook is installed but no usable mail profile was found. Open Outlook and sign in first.\n\n"
                + str(e)
            )

    def send(self,to,subject,body,attachments):
        email=str(to or "").strip()
        if not email:
            raise RuntimeError("Missing email address.")
        app=self._outlook()
        try:
            mail=app.CreateItem(0)
            mail.To=email
            mail.Subject=str(subject or "")
            mail.Body=str(body or "")
            for p in attachments or []:
                rp=Path(p).expanduser().resolve()
                if rp.exists():
                    mail.Attachments.Add(str(rp))
            mail.Send()
            return True
        except Exception as e:
            raise RuntimeError(
                "Email was not sent through Outlook.\n\n"
                + str(e)
                + "\n\nCheck that classic Microsoft Outlook is installed, signed in, and is allowed to send mail."
            )

class AddDriver(tk.Toplevel):
    def __init__(self,parent,save):
        super().__init__(parent)
        self.title("Add Driver")
        self.grab_set()
        self.save_cb=save
        self.v={k:tk.StringVar() for k in ("id","name","phone","email","notes")}
        self.v["status"]=tk.StringVar(value="Active")
        self.v["last_contacted"]=tk.StringVar(value="")

        f=ttk.Frame(self,padding=15); f.pack()
        rows=[
            ("Driver ID","id"),
            ("Name","name"),
            ("WhatsApp Phone","phone"),
            ("Email","email"),
            ("Status","status"),
            ("Last Contacted","last_contacted"),
            ("Notes","notes"),
        ]
        for i,(lab,k) in enumerate(rows):
            ttk.Label(f,text=lab).grid(row=i,column=0,sticky="w",pady=3)
            if k=="status":
                ttk.Combobox(
                    f,textvariable=self.v[k],
                    values=["Active","Not Active"],state="readonly",width=39
                ).grid(row=i,column=1,padx=6,pady=3)
            else:
                ttk.Entry(f,textvariable=self.v[k],width=42).grid(row=i,column=1,padx=6,pady=3)

        ttk.Button(f,text="ADD DRIVER",command=self.done).grid(
            row=len(rows),column=1,sticky="e",pady=(10,0)
        )

    def done(self):
        d={k:v.get().strip() for k,v in self.v.items()}
        d["preferred"]=""
        d["group"]=""
        d["language"]=""
        try:
            result=self.save_cb(d)
            if result is False:
                return
        except Exception as e:
            messagebox.showerror(APP_NAME,str(e),parent=self)
            return
        self.destroy()


class EditDriver(tk.Toplevel):
    def __init__(self,parent,driver,save):
        super().__init__(parent)
        self.title(f"Edit Driver - {driver.get('id','')}")
        self.grab_set()
        self.resizable(False,False)
        self.original_id=driver.get("id","")
        self.save_cb=save

        self.v={}
        for k in ("id","name","phone","email","status","last_contacted","notes"):
            default="Active" if k=="status" else ""
            self.v[k]=tk.StringVar(value=driver.get(k,"") or default)

        f=ttk.Frame(self,padding=15); f.pack()
        rows=[
            ("Driver ID","id"),
            ("Name","name"),
            ("WhatsApp Phone","phone"),
            ("Email","email"),
            ("Status","status"),
            ("Last Contacted","last_contacted"),
            ("Notes","notes"),
        ]
        for i,(lab,k) in enumerate(rows):
            ttk.Label(f,text=lab).grid(row=i,column=0,sticky="w",pady=3)
            if k=="status":
                ttk.Combobox(
                    f,textvariable=self.v[k],
                    values=["Active","Not Active"],state="readonly",width=39
                ).grid(row=i,column=1,padx=6,pady=3)
            else:
                ttk.Entry(f,textvariable=self.v[k],width=42).grid(row=i,column=1,padx=6,pady=3)

        b=ttk.Frame(f); b.grid(row=len(rows),column=0,columnspan=2,sticky="e",pady=(10,0))
        ttk.Button(b,text="Cancel",command=self.destroy).pack(side="right",padx=4)
        ttk.Button(b,text="SAVE CHANGES",command=self.done).pack(side="right",padx=4)

    def done(self):
        d={k:v.get().strip() for k,v in self.v.items()}
        d["preferred"]=""
        d["group"]=""
        d["language"]=""
        try:
            result=self.save_cb(self.original_id,d)
            if result is False:
                return
        except Exception as e:
            messagebox.showerror(APP_NAME,str(e),parent=self)
            return
        self.destroy()



class ShiftEditor(tk.Toplevel):
    def __init__(
        self,
        parent,
        title,
        driver_options,
        driver_map,
        selected_driver="",
        shift_value="",
        on_save=None
    ):
        super().__init__(parent)
        self.title(title)
        self.transient(parent)
        self.grab_set()
        self.resizable(False,False)
        self.on_save=on_save
        self.driver_map=driver_map

        start_time,end_time=parse_shift_range(shift_value)
        times=shift_time_options()

        # Match existing TP name to a driver from the main contacts file.
        selected_display=""
        selected_key=normalize_name(selected_driver)
        for display,contact in driver_map.items():
            if normalize_name(contact.get("name",""))==selected_key:
                selected_display=display
                break

        self.driver_var=tk.StringVar(value=selected_display)
        # Keep the exact existing TP time when editing, even if it is not one
        # of the suggested 15-minute values. New shifts start blank.
        self.start_var=tk.StringVar(value=start_time or "")
        self.end_var=tk.StringVar(value=end_time or "")

        frm=ttk.Frame(self,padding=14)
        frm.pack(fill="both",expand=True)

        ttk.Label(frm,text="Driver").grid(row=0,column=0,sticky="w",pady=5)
        self.driver_options=list(driver_options)

        driver_box=ttk.Frame(frm)
        driver_box.grid(row=0,column=1,columnspan=3,padx=6,pady=5,sticky="ew")
        driver_box.columnconfigure(0,weight=1)

        self.driver_entry=ttk.Entry(
            driver_box,
            textvariable=self.driver_var,
            width=42
        )
        self.driver_entry.grid(row=0,column=0,sticky="ew")
        self.driver_entry.bind("<KeyRelease>",self.filter_driver_options)
        self.driver_entry.bind("<Down>",self.driver_result_down)
        self.driver_entry.bind("<Return>",self.driver_result_enter)
        self.driver_entry.bind("<Escape>",lambda e:self.hide_driver_results())

        self.driver_results=tk.Listbox(
            driver_box,
            height=6,
            exportselection=False
        )
        self.driver_results.grid(row=1,column=0,sticky="ew",pady=(2,0))
        self.driver_results.bind("<ButtonRelease-1>",self.choose_driver_result)
        self.driver_results.bind("<Double-1>",self.choose_driver_result)
        self.driver_results.bind("<Return>",self.choose_driver_result)
        self.driver_results.grid_remove()

        ttk.Label(frm,text="Start").grid(row=1,column=0,sticky="w",pady=5)
        ttk.Combobox(
            frm,
            textvariable=self.start_var,
            values=times,
            state="normal",
            width=10
        ).grid(row=1,column=1,padx=6,pady=5,sticky="w")

        ttk.Label(frm,text="End").grid(row=1,column=2,sticky="e",pady=5)
        ttk.Combobox(
            frm,
            textvariable=self.end_var,
            values=times,
            state="normal",
            width=10
        ).grid(row=1,column=3,padx=6,pady=5,sticky="w")

        buttons=ttk.Frame(frm)
        buttons.grid(row=2,column=0,columnspan=4,sticky="e",pady=(8,0))
        ttk.Button(buttons,text="Cancel",command=self.destroy).pack(side="right",padx=4)
        ttk.Button(buttons,text="SAVE",command=self.save).pack(side="right",padx=4)

    def filter_driver_options(self,event=None):
        # Auto-show matching results WITHOUT taking keyboard focus away
        # from the typing field.
        typed=self.driver_var.get().strip().casefold()

        if typed:
            values=[
                option for option in self.driver_options
                if typed in option.casefold()
            ]
        else:
            values=[]

        self.driver_results.delete(0,"end")
        for option in values[:12]:
            self.driver_results.insert("end",option)

        if values:
            self.driver_results.configure(height=min(6,len(values)))
            self.driver_results.grid()
        else:
            self.driver_results.grid_remove()

        # Keep caret in the entry after every key press.
        self.after_idle(lambda:self.driver_entry.focus_set())

    def hide_driver_results(self):
        self.driver_results.grid_remove()

    def choose_driver_result(self,event=None):
        sel=self.driver_results.curselection()
        if not sel:
            return "break"
        value=self.driver_results.get(sel[0])
        self.driver_var.set(value)
        self.hide_driver_results()
        self.driver_entry.icursor("end")
        self.driver_entry.focus_set()
        return "break"

    def driver_result_down(self,event=None):
        if self.driver_results.winfo_ismapped() and self.driver_results.size()>0:
            self.driver_results.focus_set()
            self.driver_results.selection_clear(0,"end")
            self.driver_results.selection_set(0)
            self.driver_results.activate(0)
        return "break"

    def driver_result_enter(self,event=None):
        typed=self.driver_var.get().strip()
        resolved=self.resolve_driver_display(typed)
        if resolved:
            self.driver_var.set(resolved)
            self.hide_driver_results()
        return "break"

    def resolve_driver_display(self,typed):
        typed=str(typed or "").strip()
        if typed in self.driver_map:
            return typed

        q=typed.casefold()
        if not q:
            return ""

        matches=[]
        for display,contact in self.driver_map.items():
            did=str(contact.get("id","")).strip().casefold()
            name=str(contact.get("name","")).strip().casefold()
            if q in display.casefold() or q in name or q==did:
                matches.append(display)

        return matches[0] if len(matches)==1 else ""

    def save(self):
        display=self.resolve_driver_display(self.driver_var.get())
        if not display or display not in self.driver_map:
            return messagebox.showwarning(
                APP_NAME,
                "Search by driver name or Driver ID, then choose one matching driver.",
                parent=self
            )

        start_time=self.start_var.get().strip()
        end_time=self.end_var.get().strip()

        if not start_time or not end_time:
            return messagebox.showwarning(APP_NAME,"Enter start and end time in HH:MM format.",parent=self)

        try:
            s=datetime.strptime(start_time,"%H:%M")
            e=datetime.strptime(end_time,"%H:%M")
            if e<=s:
                return messagebox.showwarning(APP_NAME,"End time must be after start time.",parent=self)
        except Exception:
            return messagebox.showwarning(APP_NAME,"Invalid shift time. Use HH:MM, for example 05:10 or 13:45.",parent=self)

        contact=self.driver_map[display]
        name=str(contact.get("name","")).strip()
        tp_name=name if name.upper().startswith("LTS ") else "LTS "+name
        shift_text=build_tp_shift(start_time,end_time)

        if self.on_save:
            self.on_save(tp_name,shift_text,contact)
        self.destroy()

class TemplateEditor(tk.Toplevel):
    def __init__(self,parent,template_name,template_text,on_save,on_delete):
        super().__init__(parent)
        self.title("Edit Message Template")
        self.transient(parent)
        self.grab_set()
        self.geometry("620x430")
        self.minsize(520,360)

        self.original_name=template_name
        self.on_save=on_save
        self.on_delete=on_delete

        frm=ttk.Frame(self,padding=12)
        frm.pack(fill="both",expand=True)

        ttk.Label(frm,text="Template name").pack(anchor="w")
        self.name_var=tk.StringVar(value=template_name)
        ttk.Entry(frm,textvariable=self.name_var).pack(fill="x",pady=(3,10))

        ttk.Label(frm,text="Message").pack(anchor="w")
        self.body=tk.Text(frm,wrap="word",height=14)
        self.body.pack(fill="both",expand=True,pady=(3,10))
        self.body.insert("1.0",template_text or "")

        ttk.Label(
            frm,
            text="Placeholders you can use: {name} {id} {phone} {email} {notes} "
                 "{shift_date} {shift_day} {shift_start} {report_time}"
        ).pack(anchor="w",pady=(0,10))

        buttons=ttk.Frame(frm)
        buttons.pack(fill="x")

        ttk.Button(buttons,text="DELETE TEMPLATE",command=self.delete).pack(side="left")
        ttk.Button(buttons,text="Cancel",command=self.destroy).pack(side="right",padx=4)
        ttk.Button(buttons,text="SAVE CHANGES",command=self.save).pack(side="right",padx=4)

    def save(self):
        new_name=self.name_var.get().strip()
        body=self.body.get("1.0","end").rstrip()
        if not new_name:
            return messagebox.showwarning(APP_NAME,"Template name is required.",parent=self)
        self.on_save(self.original_name,new_name,body)
        self.destroy()

    def delete(self):
        if messagebox.askyesno(APP_NAME,f'Delete template "{self.original_name}"?',parent=self):
            self.on_delete(self.original_name)
            self.destroy()

class App(tk.Tk):
    def __init__(self):
        super().__init__(); ensure_dirs()
        self.title(APP_NAME); self.geometry("1380x900"); self.minsize(1100,700)
        self.store=Store(); self.wa=WhatsApp(self.set_status); self.mail=Mailer()
        self.google_config=self.load_google_config()
        self.contacts=tk.StringVar(); self.search=tk.StringVar()
        self.history_search=tk.StringVar()
        self.active=tk.BooleanVar(value=True)
        self.cc=tk.StringVar(value="43"); self.delay=tk.StringVar(value="7")
        self.subject=tk.StringVar(value="LTS Transport"); self.follow=tk.StringVar(value="Done")
        self.send_mode=tk.StringVar(value="WhatsApp")
        self.send_timing=tk.StringVar(value="Now")
        self.schedule_date=tk.StringVar(value=datetime.now().strftime("%Y-%m-%d"))
        self.schedule_time=tk.StringVar(value=(datetime.now().replace(second=0,microsecond=0)).strftime("%H:%M"))
        self.use_common_files=tk.BooleanVar(value=False)
        self.attach_driver_qr=tk.BooleanVar(value=False)
        self.template=tk.StringVar(value="General"); self.status=tk.StringVar(value="Ready.")
        self.dashboard=tk.StringVar(value="No contacts loaded.")
        self.send_progress_text=tk.StringVar(value="")
        self.send_progress_value=tk.DoubleVar(value=0)
        self.attachments=[]; self.current=[]; self.stop=False; self.sending=False; self.call_queue=[]; self.call_i=0
        self._last_driver_checkbox_click=("",0.0)
        self._last_shift_checkbox_click=("",0.0)
        self._last_schedule_checkbox_click=("",0.0)
        self.scheduled_checked=set()
        self._google_sync_running=False
        self._google_snapshot=""
        self._google_contact_signatures={}
        self.dienstplan=DienstplanReader()
        self.dienstplan_path=tk.StringVar()
        self.shift_date=tk.StringVar(value=(datetime.now()+timedelta(days=1)).strftime("%Y-%m-%d"))
        self.shift_before=tk.StringVar(value="1")
        self.shift_before_unit=tk.StringVar(value="Hour(s)")
        self.shift_channel=tk.StringVar(value="WhatsApp")
        self.shift_search=tk.StringVar()
        self.shift_checked=set()
        self.shift_preview=[]
        self.checked_ids=set()
        self.templates=self.load_templates()
        self.build()
        if self.google_config.get("url") and self.google_config.get("token"):
            self.after(500,lambda:self.worker(self.connect_google))
        self.after(3000,self.check_scheduled_jobs)
        self.after(60000,self.auto_google_refresh)

    def load_google_config(self):
        if GOOGLE_CONFIG_FILE.exists():
            try:
                data=json.loads(GOOGLE_CONFIG_FILE.read_text(encoding="utf-8"))
                return {
                    "url":str(data.get("url","")).strip(),
                    "token":str(data.get("token","")).strip(),
                    "tp_spreadsheet_id":str(data.get("tp_spreadsheet_id","")).strip(),
                    "driver_spreadsheet_id":str(data.get("driver_spreadsheet_id","")).strip(),
                    "driver_sheet_name":str(data.get("driver_sheet_name","Drivers")).strip() or "Drivers",
                }
            except Exception:
                pass
        return {
            "url":"","token":"","tp_spreadsheet_id":"",
            "driver_spreadsheet_id":"","driver_sheet_name":"Drivers"
        }

    def save_google_config(self,data):
        GOOGLE_CONFIG_FILE.write_text(
            json.dumps(data,ensure_ascii=False,indent=2),
            encoding="utf-8"
        )
        self.google_config=dict(data)

    def google_setup(self):
        GoogleSetupDialog(self,self.google_config,self.connect_google)

    def connect_google(self,data=None):
        if data is not None:
            self.save_google_config(data)
        cfg=self.google_config
        if not cfg.get("url") or not cfg.get("token"):
            return self.google_setup()

        self.set_status("Connecting to Google Sheets...")
        try:
            self.store.configure_google(
                cfg["url"],
                cfg["token"],
                cfg.get("tp_spreadsheet_id",""),
                cfg.get("driver_spreadsheet_id",""),
                cfg.get("driver_sheet_name","Drivers"),
            )
            self.dienstplan.use_google(self.store.google)
            self.dienstplan_path.set("GOOGLE SHEETS (VIE-LTS-TP Liste)")
            self.contacts.set(f"FLEETCONTROL → {self.store.google.driver_sheet_name}" if self.store.google.driver_spreadsheet_id else "GOOGLE SHEETS")
            self.render()
            self.set_status(f"Google Sheets connected — {len(self.store.rows)} drivers from {self.store.source_name()}.")
        except Exception as e:
            messagebox.showerror(APP_NAME,str(e))

    def refresh_google(self):
        if self.store.mode!="google":
            return self.connect_google()
        try:
            self.set_status("Refreshing Google Sheets...")
            self.store.refresh_google()
            self.render()
            self.set_status(f"Google Sheets refreshed — {len(self.store.rows)} contacts.")
        except Exception as e:
            messagebox.showerror(APP_NAME,str(e))

    def migrate_contacts_to_fleet(self):
        if self.store.mode!="google" or not self.store.google:
            return messagebox.showwarning(APP_NAME,"Connect Google Sheets first.")
        g=self.store.google
        if not str(g.driver_spreadsheet_id or "").strip():
            return messagebox.showwarning(
                APP_NAME,
                "Set the Fleet / Driver Spreadsheet ID first. Migration needs a separate Fleet spreadsheet target."
            )
        if clean(g.driver_sheet_name)!="drivers":
            if not messagebox.askyesno(
                APP_NAME,
                f'The configured driver tab is "{g.driver_sheet_name}", not "Drivers".\n\nContinue anyway?'
            ):
                return
        if not messagebox.askyesno(
            APP_NAME,
            "ONE-TIME MIGRATION\n\n"
            "Source: this Dispatcher spreadsheet → Contacts\n"
            f"Target: Fleet spreadsheet → {g.driver_sheet_name}\n\n"
            "Drivers are matched ONLY by Driver ID. Existing QR Code cells are never changed. "
            "Missing Fleet IDs are reported and not created automatically.\n\nContinue?"
        ):
            return

        self.set_status("Migrating Contacts → Fleet Drivers...")

        def run():
            try:
                result=g.migrate_contacts_to_fleet("Contacts")
                self.store.refresh_google()
                self.after(0,self.render)
                missing=result.get("missing_ids",[]) or []
                duplicate=result.get("duplicate_source_ids",[]) or []
                phone_conflicts=result.get("phone_conflicts",[]) or []
                details=[
                    f"Source contacts: {result.get('source_count',0)}",
                    f"Matched Fleet drivers: {result.get('matched',0)}",
                    f"Fleet rows updated: {result.get('updated',0)}",
                    f"Missing in Fleet: {result.get('missing_count',0)}",
                    f"Duplicate source IDs: {result.get('duplicate_source_count',0)}",
                    f"Phone conflicts: {result.get('phone_conflict_count',0)}",
                    "QR Code cells changed: 0",
                ]
                if missing:
                    details.append("Missing IDs: "+", ".join(map(str,missing[:20])))
                if duplicate:
                    details.append("Duplicate IDs: "+", ".join(map(str,duplicate[:20])))
                if phone_conflicts:
                    details.append("Phone conflicts: "+"; ".join(map(str,phone_conflicts[:10])))
                msg="\n".join(details)
                self.set_status(
                    f"Migration finished — {result.get('updated',0)} updated, "
                    f"{result.get('missing_count',0)} missing."
                )
                self.after(0,lambda m=msg:messagebox.showinfo(APP_NAME,m))
            except Exception as e:
                self.set_status("Migration failed.")
                self.error(str(e))

        threading.Thread(target=run,daemon=True).start()

    def _contact_snapshot(self,rows):
        simple=[]
        for r in rows:
            simple.append({
                "id":r.get("id",""),
                "name":r.get("name",""),
                "phone":r.get("phone",""),
                "email":r.get("email",""),
                "status":r.get("status",""),
                "last_contacted":r.get("last_contacted",""),
                "notes":r.get("notes",""),
            })
        return json.dumps(simple,ensure_ascii=False,sort_keys=True)

    def _contact_signature_map(self,rows):
        out={}
        for r in rows:
            did=str(r.get("id","")).strip()
            if not did:
                continue
            out[did]=(
                str(r.get("name","")).strip(),
                str(r.get("phone","")).strip(),
                str(r.get("email","")).strip(),
                str(r.get("status","")).strip(),
                str(r.get("notes","")).strip(),
            )
        return out

    def _apply_background_google_rows(self,rows,snapshot):
        try:
            if snapshot!=self._google_snapshot:
                old_signatures=dict(self._google_contact_signatures)
                new_signatures=self._contact_signature_map(rows)

                self.store.rows=rows
                self.store.mode="google"
                self._google_snapshot=snapshot
                self._google_contact_signatures=new_signatures
                self.render()

                # Only cache QR for genuinely new/changed driver identities.
                # Do not generate QR cards for the whole database on refresh.
                changed=[]
                for r in rows:
                    did=str(r.get("id","")).strip()
                    if not did:
                        continue
                    old=old_signatures.get(did)
                    new=new_signatures.get(did)
                    if old is not None and old!=new:
                        changed.append(r)

                if changed:
                    self.queue_qr_cache_refresh(changed)

                self.set_status(f"Google Sheets synced — {len(rows)} contacts.")
        finally:
            self._google_sync_running=False

    def _google_sync_failed(self,msg):
        self._google_sync_running=False
        self.set_status("Google auto-sync paused: " + str(msg))

    def auto_google_refresh(self):
        # Network work runs outside the Tkinter UI thread so the app does not freeze.
        if self.store.mode=="google" and self.store.google and not self._google_sync_running:
            self._google_sync_running=True
            def run():
                try:
                    raw=self.store.google.contacts()
                    rows=self.store.parse_google_contacts(raw)
                    snapshot=self._contact_snapshot(rows)
                    self.after(0,lambda:self._apply_background_google_rows(rows,snapshot))
                except Exception as e:
                    self.after(0,lambda:self._google_sync_failed(str(e)))
            threading.Thread(target=run,daemon=True).start()

        self.after(60000,self.auto_google_refresh)

    def load_templates(self):
        if TEMPLATES_FILE.exists():
            try: return json.loads(TEMPLATES_FILE.read_text(encoding="utf-8"))
            except: pass
        TEMPLATES_FILE.write_text(json.dumps(DEFAULT_TEMPLATES,ensure_ascii=False,indent=2),encoding="utf-8")
        return dict(DEFAULT_TEMPLATES)

    def build(self):
        ttk.Label(self,textvariable=self.status,relief="sunken",anchor="w",padding=5).pack(side="bottom",fill="x")
        bar=ttk.Frame(self,padding=6); bar.pack(side="bottom",fill="x")
        self.send_bar=bar

        ttk.Label(bar,text="Channel").pack(side="left",padx=(0,4))
        ttk.Combobox(
            bar,
            textvariable=self.send_mode,
            values=["WhatsApp","Email"],
            state="readonly",
            width=10
        ).pack(side="left",padx=(0,6))

        ttk.Label(bar,text="When").pack(side="left",padx=(6,4))
        ttk.Combobox(
            bar,
            textvariable=self.send_timing,
            values=["Now","At time"],
            state="readonly",
            width=8
        ).pack(side="left",padx=(0,5))

        ttk.Entry(bar,textvariable=self.schedule_date,width=10).pack(side="left",padx=(0,3))
        ttk.Entry(bar,textvariable=self.schedule_time,width=5).pack(side="left",padx=(0,6))

        self.send_button=ttk.Button(
            bar,
            text="SEND",
            command=self.send_selected_simple
        )
        self.send_button.pack(side="left",padx=3)

        ttk.Label(bar,text="Delay").pack(side="left",padx=(10,4))
        ttk.Entry(bar,textvariable=self.delay,width=4).pack(side="left",padx=(0,2))
        ttk.Label(bar,text="sec").pack(side="left",padx=(0,8))

        ttk.Button(
            bar,
            text="WHATSAPP CALL",
            command=self.call_selected
        ).pack(side="left",padx=(6,3))

        ttk.Button(
            bar,
            text="STOP",
            command=self.stop_send
        ).pack(side="left",padx=3)

        progress_box=ttk.Frame(bar)
        progress_box.pack(side="right",padx=(8,0))
        ttk.Label(progress_box,textvariable=self.send_progress_text,anchor="e").pack(side="top",fill="x")
        self.send_progress_bar=ttk.Progressbar(
            progress_box,variable=self.send_progress_value,maximum=100,length=210
        )
        self.send_progress_bar.pack(side="top",fill="x")
        ttk.Label(bar,textvariable=self.dashboard).pack(side="right",padx=(8,8))

        nb=ttk.Notebook(self); nb.pack(fill="both",expand=True,padx=8,pady=8)
        self.nb=nb
        d=ttk.Frame(nb); h=ttk.Frame(nb); s=ttk.Frame(nb); sr=ttk.Frame(nb)
        nb.add(d,text="Dispatcher"); nb.add(sr,text="Shift Reminders"); nb.add(s,text="Scheduled"); nb.add(h,text="History")
        self.dispatch_tab=d; self.history_tab=h; self.scheduled_tab=s; self.shift_tab=sr
        nb.bind("<<NotebookTabChanged>>",self.on_main_tab_changed)

        top=ttk.Frame(d,padding=8); top.pack(fill="x")
        ttk.Label(top,text="LTS Dispatcher",font=("Arial",21,"bold")).pack(side="left")
        ttk.Button(top,text="TEST WHATSAPP APP",command=lambda:self.worker(self.wa.activate)).pack(side="right",padx=3)
        ttk.Button(top,text="TEST EMAIL",command=self.test_email).pack(side="right",padx=3)
        ttk.Button(top,text="CHECK WINDOWS AUTOMATION",command=lambda:self.worker(self.wa.accessibility)).pack(side="right",padx=3)

        db=ttk.LabelFrame(d,text="1. Driver Database",padding=8); db.pack(fill="x",padx=8,pady=4)
        ttk.Label(db,text="Database").grid(row=0,column=0,sticky="w")
        ttk.Entry(db,textvariable=self.contacts).grid(row=0,column=1,sticky="ew",padx=5)
        ttk.Button(db,text="GOOGLE SHEETS SETUP",command=self.google_setup).grid(row=0,column=2,padx=2)
        ttk.Button(db,text="REFRESH GOOGLE",command=self.refresh_google).grid(row=0,column=3,padx=2)
        ttk.Button(db,text="Local Excel...",command=self.choose_contacts).grid(row=0,column=4,padx=2)
        ttk.Button(db,text="Load Local",command=self.load).grid(row=0,column=5,padx=2)
        ttk.Button(db,text="+ ADD DRIVER",command=self.add_driver_dialog).grid(row=0,column=6,padx=2)
        ttk.Button(db,text="EDIT DRIVER",command=self.edit_driver_dialog).grid(row=0,column=7,padx=2)
        ttk.Button(db,text="DELETE DRIVER",command=self.delete_driver).grid(row=0,column=8,padx=2)
        ttk.Label(
            db,
            text="Shared mode: Dispatcher reads/writes only FleetControl → Drivers; all other Fleet tabs stay untouched.",
            foreground="#555"
        ).grid(row=1,column=0,columnspan=5,sticky="w",pady=(7,0))
        ttk.Button(
            db,text="MIGRATE OLD CONTACTS → FLEET",command=self.migrate_contacts_to_fleet
        ).grid(row=1,column=5,columnspan=4,sticky="e",padx=2,pady=(7,0))
        db.columnconfigure(1,weight=1)

        comp=ttk.LabelFrame(d,text="2. Message / Attachments",padding=8); comp.pack(fill="x",padx=8,pady=4)
        ttk.Label(comp,text="Template").grid(row=0,column=0)
        self.tc=ttk.Combobox(comp,textvariable=self.template,values=sorted(self.templates),state="readonly",width=25)
        self.tc.grid(row=0,column=1,padx=4); self.tc.bind("<<ComboboxSelected>>",lambda e:self.apply_template())
        ttk.Button(comp,text="SAVE AS NEW",command=self.save_template).grid(row=0,column=2,padx=2)
        ttk.Button(comp,text="EDIT TEMPLATE",command=self.edit_template).grid(row=0,column=3,padx=2)
        ttk.Label(comp,text="Email Subject").grid(row=0,column=4,padx=(15,4))
        ttk.Entry(comp,textvariable=self.subject,width=35).grid(row=0,column=5,sticky="ew")
        ttk.Label(comp,text="Follow-up").grid(row=0,column=6,padx=(15,4))
        ttk.Combobox(comp,textvariable=self.follow,values=["Done","No answer","Call back","Reached","Pending"],state="readonly",width=12).grid(row=0,column=7)
        self.msg=tk.Text(comp,height=6,wrap="word"); self.msg.grid(row=1,column=0,columnspan=8,sticky="ew",pady=5)
        self.msg.insert("1.0",self.templates["General"])
        af=ttk.Frame(comp); af.grid(row=2,column=0,columnspan=8,sticky="w")
        ttk.Checkbutton(af,text="Attach common files",variable=self.use_common_files).pack(side="left",padx=2)
        ttk.Button(af,text="+ ADD COMMON FILES",command=self.add_files).pack(side="left",padx=2)
        ttk.Button(af,text="CLEAR FILES",command=self.clear_files).pack(side="left",padx=2)
        ttk.Checkbutton(af,text="Attach driver QR",variable=self.attach_driver_qr).pack(side="left",padx=(12,2))
        self.attach_label=ttk.Label(af,text="No common attachments"); self.attach_label.pack(side="left",padx=8)
        comp.columnconfigure(4,weight=1)

        lf=ttk.LabelFrame(d,text="3. Drivers",padding=7); lf.pack(fill="both",expand=True,padx=8,pady=4)
        tb=ttk.Frame(lf); tb.pack(fill="x",pady=(0,5))
        ttk.Label(tb,text="Search").pack(side="left"); ttk.Entry(tb,textvariable=self.search,width=26).pack(side="left",padx=4)
        self.search.trace_add("write",lambda *a:self.render())
        ttk.Checkbutton(tb,text="Active only",variable=self.active,command=self.render).pack(side="left",padx=8)
        ttk.Button(tb,text="EDIT NOTES",command=self.edit_notes).pack(side="left",padx=(10,2))
        ttk.Button(tb,text="VIEW QR",command=self.view_qr).pack(side="left",padx=2)
        ttk.Button(tb,text="SEND QR",command=self.send_qr_selected).pack(side="left",padx=2)
        ttk.Button(tb,text="GENERATE QR CODE",command=self.generate_selected_qr).pack(side="left",padx=2)
        ttk.Button(tb,text="OPEN QR FOLDER",command=self.open_qr_folder).pack(side="left",padx=2)
        ttk.Button(tb,text="CALL NEXT",command=self.call_next).pack(side="left",padx=2)

        style=ttk.Style()
        style.configure("LTS.Treeview",rowheight=31,font=("Arial",12))
        style.configure("LTS.Treeview.Heading",font=("Arial",11,"bold"))

        cols=("pick","id","name","phone","email","status","last","notes")
        self.tree=ttk.Treeview(lf,columns=cols,show="headings",selectmode="extended",style="LTS.Treeview")
        names={"pick":"☐","id":"Driver ID","name":"Name","phone":"WhatsApp","email":"Email","status":"Status","last":"Last Contacted","notes":"Notes"}
        widths={"pick":52,"id":82,"name":190,"phone":145,"email":205,"status":90,"last":135,"notes":250}
        for c in cols:
            if c=="pick":
                self.tree.heading(c,text="☐",command=self.toggle_select_all_header)
                self.tree.column(c,width=52,anchor="center",stretch=False)
            else:
                self.tree.heading(c,text=names[c])
                self.tree.column(c,width=widths[c],anchor="w")
        vs=ttk.Scrollbar(lf,orient="vertical",command=self.tree.yview); hs=ttk.Scrollbar(lf,orient="horizontal",command=self.tree.xview)
        self.tree.configure(yscrollcommand=vs.set,xscrollcommand=hs.set)
        self.tree.pack(side="left",fill="both",expand=True); vs.pack(side="right",fill="y"); hs.pack(side="bottom",fill="x")
        self.tree.bind("<Button-1>",self.tree_click)
        self.tree.bind("<space>",self.driver_space_toggle)
        self.tree.bind("<Command-a>",self.driver_select_all_shortcut)
        self.tree.bind("<Control-a>",self.driver_select_all_shortcut)
        self.tree.bind("<Command-Shift-A>",self.driver_clear_shortcut)
        self.tree.bind("<Control-Shift-A>",self.driver_clear_shortcut)

        hh=ttk.Frame(h,padding=8); hh.pack(fill="x")
        ttk.Label(hh,text="Communication History",font=("Arial",18,"bold")).pack(side="left")

        ttk.Label(hh,text="Search").pack(side="left",padx=(24,4))
        ttk.Entry(hh,textvariable=self.history_search,width=28).pack(side="left")
        self.history_search.trace_add("write",lambda *a:self.history_refresh())

        ttk.Button(hh,text="Refresh",command=self.history_refresh).pack(side="right")
        hc=("time","id","name","channel","action","result","detail","follow")
        self.ht=ttk.Treeview(h,columns=hc,show="headings")
        for c,w,n in [("time",150,"Time"),("id",80,"Driver ID"),("name",170,"Name"),("channel",90,"Channel"),("action",100,"Action"),("result",105,"Result"),("detail",300,"Detail"),("follow",90,"Follow-up")]:
            self.ht.heading(c,text=n); self.ht.column(c,width=w,anchor="w")
        self.ht.pack(fill="both",expand=True,padx=8,pady=(0,8))
        self.history_refresh()

        sh=ttk.Frame(s,padding=8); sh.pack(fill="x")
        ttk.Label(sh,text="Scheduled Sends",font=("Arial",18,"bold")).pack(side="left")
        ttk.Button(sh,text="Refresh",command=self.refresh_scheduled_tab).pack(side="right")
        ttk.Button(sh,text="DELETE CHECKED",command=self.delete_scheduled_job).pack(side="right",padx=5)
        ttk.Button(sh,text="CLEAR",command=self.clear_scheduled_checks).pack(side="right",padx=3)
        ttk.Button(sh,text="SELECT ALL",command=self.select_all_scheduled).pack(side="right",padx=3)

        scols=("pick","when","channel","drivers","status","created")
        self.st=ttk.Treeview(s,columns=scols,show="headings",selectmode="extended",style="LTS.Treeview")
        for c,w,n in [
            ("pick",52,"☐"),("when",150,"Send At"),("channel",90,"Channel"),("drivers",420,"Drivers"),
            ("status",100,"Status"),("created",150,"Created")
        ]:
            self.st.heading(c,text=n)
            self.st.column(c,width=w,anchor="center" if c=="pick" else "w",stretch=(c!="pick"))
        self.st.heading("pick",command=self.toggle_all_scheduled_header)
        self.st.bind("<Button-1>",self.scheduled_tree_click)
        self.st.bind("<space>",self.scheduled_space_toggle)
        self.st.bind("<Delete>",lambda e:self.delete_scheduled_job())
        self.st.bind("<BackSpace>",lambda e:self.delete_scheduled_job())
        self.st.bind("<Command-a>",self.scheduled_select_all_shortcut)
        self.st.bind("<Control-a>",self.scheduled_select_all_shortcut)
        self.st.bind("<Command-Shift-A>",self.scheduled_clear_shortcut)
        self.st.bind("<Control-Shift-A>",self.scheduled_clear_shortcut)
        self.st.pack(fill="both",expand=True,padx=8,pady=(0,8))
        self.refresh_scheduled_tab()

        sf=ttk.Frame(sr,padding=10); sf.pack(fill="x")
        ttk.Label(sf,text="Automatic Shift Reminders from TP Liste",font=("Arial",18,"bold")).grid(row=0,column=0,columnspan=6,sticky="w",pady=(0,8))

        ttk.Label(sf,text="TP Liste Source").grid(row=1,column=0,sticky="w")
        ttk.Entry(sf,textvariable=self.dienstplan_path).grid(row=1,column=1,columnspan=2,sticky="ew",padx=5)
        ttk.Button(sf,text="USE GOOGLE SHEETS",command=self.use_google_tp).grid(row=1,column=3,padx=2)
        ttk.Button(sf,text="Local Excel...",command=self.choose_dienstplan).grid(row=1,column=4,padx=2)
        ttk.Button(sf,text="LOAD SHIFTS",command=self.load_shift_preview).grid(row=1,column=5,padx=2)

        ttk.Label(sf,text="Shift date").grid(row=2,column=0,sticky="w",pady=(7,0))
        ttk.Entry(sf,textvariable=self.shift_date,width=12).grid(row=2,column=1,sticky="w",pady=(7,0))
        ttk.Label(sf,text="Reminder before").grid(row=2,column=2,sticky="e",padx=(15,4),pady=(7,0))
        ttk.Entry(sf,textvariable=self.shift_before,width=5).grid(row=2,column=3,sticky="w",pady=(7,0))
        ttk.Combobox(
            sf,
            textvariable=self.shift_before_unit,
            values=["Day(s)","Hour(s)","Minute(s)"],
            state="readonly",
            width=10
        ).grid(row=2,column=4,sticky="w",pady=(7,0))

        ttk.Label(sf,text="Channel").grid(row=3,column=0,sticky="w",pady=(7,0))
        ttk.Combobox(sf,textvariable=self.shift_channel,values=["WhatsApp","Email"],state="readonly",width=12).grid(row=3,column=1,sticky="w",pady=(7,0))

        shift_actions=ttk.Frame(sf)
        shift_actions.grid(row=3,column=2,columnspan=4,sticky="e",pady=(7,0))
        ttk.Button(shift_actions,text="+ ADD SHIFT",command=self.add_shift_dialog).pack(side="left",padx=2)
        ttk.Button(shift_actions,text="EDIT SHIFT",command=self.edit_shift_dialog).pack(side="left",padx=2)
        ttk.Button(shift_actions,text="DELETE SHIFT",command=self.delete_shift).pack(side="left",padx=2)
        ttk.Button(shift_actions,text="SCHEDULE REMINDERS",command=self.schedule_shift_reminders).pack(side="left",padx=(10,2))
        ttk.Button(shift_actions,text="SEND NOW",command=self.send_shift_reminders_now).pack(side="left",padx=2)

        sf.columnconfigure(1,weight=1)
        sf.columnconfigure(3,weight=1)

        tf=ttk.LabelFrame(sr,text="Reminder Message",padding=8); tf.pack(fill="x",padx=10,pady=(0,6))
        self.shift_msg=tk.Text(tf,height=6,wrap="word")
        self.shift_msg.pack(fill="x")
        self.shift_msg.insert("1.0",DEFAULT_TEMPLATES["Shift reminder"])
        ttk.Label(tf,text="Placeholders: {name} {shift_date} {shift_day} {shift_start}/{report_time}=30 min earlier").pack(anchor="w",pady=(4,0))

        shift_search_bar=ttk.Frame(sr,padding=(10,0,10,5))
        shift_search_bar.pack(fill="x")
        ttk.Label(shift_search_bar,text="Search").pack(side="left")
        ttk.Entry(shift_search_bar,textvariable=self.shift_search,width=30).pack(side="left",padx=5)
        self.shift_search.trace_add("write",lambda *a:self.render_shift_preview())

        tframe=ttk.Frame(sr,padding=(10,0,10,10)); tframe.pack(fill="both",expand=True)
        scols=("pick","name","start","report","shift","reminder","contact","status")
        self.shift_tree=ttk.Treeview(tframe,columns=scols,show="headings",selectmode="browse",style="LTS.Treeview")
        swidths={"pick":52,"name":210,"start":75,"report":85,"shift":320,"reminder":145,"contact":210,"status":170}
        snames={"pick":"☐","name":"Driver","start":"TP Start","report":"Message Time","shift":"Shift","reminder":"Reminder At","contact":"Contact","status":"Status"}
        for c in scols:
            if c=="pick":
                self.shift_tree.heading(c,text="☐",command=self.toggle_all_shift_rows)
                self.shift_tree.column(c,width=52,anchor="center",stretch=False)
            else:
                self.shift_tree.heading(c,text=snames[c])
                self.shift_tree.column(c,width=swidths[c],anchor="w")
        self.shift_tree.bind("<Button-1>",self.shift_tree_click)
        self.shift_tree.bind("<Double-1>",self.shift_tree_double_click)
        self.shift_tree.bind("<space>",self.shift_space_toggle)
        self.shift_tree.bind("<Command-a>",self.shift_select_all_shortcut)
        self.shift_tree.bind("<Control-a>",self.shift_select_all_shortcut)
        self.shift_tree.bind("<Command-Shift-A>",self.shift_clear_shortcut)
        self.shift_tree.bind("<Control-Shift-A>",self.shift_clear_shortcut)
        sv=ttk.Scrollbar(tframe,orient="vertical",command=self.shift_tree.yview)
        self.shift_tree.configure(yscrollcommand=sv.set)
        self.shift_tree.pack(side="left",fill="both",expand=True)
        sv.pack(side="right",fill="y")

    def test_email(self):
        address=simpledialog.askstring(APP_NAME,"Send a test email to:")
        if not address:
            return

        def run():
            try:
                setup=self.mail.test_setup()
                self.set_status("Outlook connection OK. Sending test email...")

                self.mail.send(
                    address.strip(),
                    "LTS Dispatcher Test",
                    "This is a test email from LTS Dispatcher.",
                    []
                )

                self.set_status(f"Test email sent to {address.strip()}.")
                self.after(
                    0,
                    lambda:messagebox.showinfo(
                        APP_NAME,
                        "Test email sent successfully.\n\n"
                        "Outlook connection: OK"
                    )
                )
            except Exception as e:
                self.error(str(e))

        threading.Thread(target=run,daemon=True).start()

    def match_shift_contact(self,shift):
        """
        Matching priority:
        1. Driver ID
        2. Phone
        3. Email
        4. Exact normalized name
        5. Token-normalized name
        6. Safe fuzzy name match
        """
        rows=self.store.rows

        by_id={
            str(r.get("id","")).strip().casefold():r
            for r in rows if str(r.get("id","")).strip()
        }
        by_phone={
            normalize_phone_key(r.get("phone","")):r
            for r in rows if normalize_phone_key(r.get("phone",""))
        }
        by_email={
            normalize_email_key(r.get("email","")):r
            for r in rows if normalize_email_key(r.get("email",""))
        }
        by_name={
            normalize_name(r.get("name","")):r
            for r in rows if normalize_name(r.get("name",""))
        }

        did=str(shift.get("driver_id","") or "").strip().casefold()
        if did and did in by_id:
            return by_id[did],"Driver ID"

        phone=normalize_phone_key(shift.get("tp_phone",""))
        if phone and phone in by_phone:
            return by_phone[phone],"Phone"

        email=normalize_email_key(shift.get("tp_email",""))
        if email and email in by_email:
            return by_email[email],"Email"

        name_key=normalize_name(shift.get("name",""))
        if name_key and name_key in by_name:
            return by_name[name_key],"Name"

        target_tokens=token_sorted_name(shift.get("name",""))
        token_matches=[
            r for r in rows
            if token_sorted_name(r.get("name",""))==target_tokens and target_tokens
        ]
        if len(token_matches)==1:
            return token_matches[0],"Normalized name"

        fuzzy=safe_fuzzy_contact(shift.get("name",""),rows)
        if fuzzy:
            return fuzzy,"Fuzzy name"

        return None,""

    def shift_driver_options(self):
        rows=[
            r for r in self.store.rows
            if clean(r.get("status")) not in ("not active","inactive","false","0","no","nein")
        ]
        rows=sorted(rows,key=lambda r:normalize_name(r.get("name","")))
        options=[]
        mapping={}
        for r in rows:
            display=f"{r.get('name','')}  [{r.get('id','')}]"
            options.append(display)
            mapping[display]=r
        return options,mapping

    def selected_shift_preview_row(self):
        if not hasattr(self,"shift_tree"):
            return None

        # First use the highlighted row, when exactly one is highlighted.
        sel=self.shift_tree.selection()
        if len(sel)==1:
            item=sel[0]
            try:
                idx=int(item.split("_",1)[1])
                return self.shift_preview[idx]
            except Exception:
                pass

        # If the user checked exactly one shift, treat that checked shift as
        # the edit target too. This matches the checkbox-based workflow.
        checked=[]
        for x in self.shift_preview:
            key=f"{x['name_key']}|{x['shift_date']}"
            if key in self.shift_checked:
                checked.append(x)
        if len(checked)==1:
            return checked[0]

        return None

    def add_shift_dialog(self):
        path=self.dienstplan_path.get().strip()
        if self.dienstplan.mode!="google" and not path:
            return messagebox.showwarning(APP_NAME,"Choose the TP Liste source first.")
        try:
            target=datetime.strptime(self.shift_date.get().strip(),"%Y-%m-%d").date()
            if self.dienstplan.mode!="google":
                self.dienstplan.load(path)
        except Exception as e:
            return messagebox.showerror(APP_NAME,str(e))

        def save(name,shift_text,contact):
            try:
                self.dienstplan.add_shift(target,name,shift_text,contact)
                self.set_status("Shift added directly to Google Sheets." if self.dienstplan.mode=="google" else f"Shift added directly to {Path(path).name}.")
                self.load_shift_preview()
            except Exception as e:
                messagebox.showerror(APP_NAME,str(e))

        options,mapping=self.shift_driver_options()
        if not options:
            return messagebox.showwarning(APP_NAME,"No active drivers found in the loaded contacts file.")

        ShiftEditor(
            self,
            "Add Shift",
            driver_options=options,
            driver_map=mapping,
            on_save=save
        )

    def edit_shift_dialog(self):
        row=self.selected_shift_preview_row()
        if not row:
            return messagebox.showwarning(APP_NAME,"Select one shift row first.")

        path=self.dienstplan_path.get().strip()
        if self.dienstplan.mode!="google" and not path:
            return messagebox.showwarning(APP_NAME,"Choose the TP Liste source first.")

        try:
            target=datetime.strptime(self.shift_date.get().strip(),"%Y-%m-%d").date()
            if self.dienstplan.mode!="google":
                self.dienstplan.load(path)
        except Exception as e:
            return messagebox.showerror(APP_NAME,str(e))

        def save(name,shift_text,contact):
            try:
                self.dienstplan.edit_shift(target,row.get("tp_row"),name,shift_text,contact)
                self.set_status("Shift updated directly in Google Sheets." if self.dienstplan.mode=="google" else f"Shift updated directly in {Path(path).name}.")
                self.load_shift_preview()
            except Exception as e:
                messagebox.showerror(APP_NAME,str(e))

        options,mapping=self.shift_driver_options()
        if not options:
            return messagebox.showwarning(APP_NAME,"No active drivers found in the loaded contacts file.")

        ShiftEditor(
            self,
            "Edit Shift",
            driver_options=options,
            driver_map=mapping,
            selected_driver=row.get("name",""),
            shift_value=row.get("shift_text",""),
            on_save=save
        )

    def delete_shift(self):
        row=self.selected_shift_preview_row()
        if not row:
            return messagebox.showwarning(APP_NAME,"Select one shift row first.")

        path=self.dienstplan_path.get().strip()
        if self.dienstplan.mode!="google" and not path:
            return messagebox.showwarning(APP_NAME,"Choose the TP Liste source first.")

        source_text = "Google Sheets" if self.dienstplan.mode=="google" else "the same Excel file"

        if not messagebox.askyesno(
            APP_NAME,
            f"Delete this shift from the TP Liste?\n\n"
            f"{row.get('name','')}\n{row.get('shift_text','')}\n\n"
            f"This writes directly to {source_text}."
        ):
            return

        try:
            target=datetime.strptime(self.shift_date.get().strip(),"%Y-%m-%d").date()
            if self.dienstplan.mode!="google":
                self.dienstplan.load(path)
            self.dienstplan.delete_shift(target,row.get("tp_row"))
            self.set_status("Shift deleted directly from Google Sheets." if self.dienstplan.mode=="google" else f"Shift deleted directly from {Path(path).name}.")
            self.load_shift_preview()
        except Exception as e:
            messagebox.showerror(APP_NAME,str(e))

    def use_google_tp(self):
        if self.store.mode!="google" or not self.store.google:
            return messagebox.showwarning(APP_NAME,"Connect the main Google Sheet first.")
        self.dienstplan.use_google(self.store.google)
        self.dienstplan_path.set("GOOGLE SHEETS (VIE-LTS-TP Liste)")
        self.set_status("TP Liste source: Google Sheets — click LOAD SHIFTS.")

    def choose_dienstplan(self):
        p=filedialog.askopenfilename(
            title="Choose VIE-LTS-TP Liste Excel file",
            filetypes=[("Excel","*.xlsx *.xlsm")]
        )
        if p:
            self.dienstplan_path.set(p)
            try:
                self.dienstplan.load(p)
                self.set_status("TP Liste source: local Excel")
            except Exception as e:
                messagebox.showerror(APP_NAME,str(e))

    def reminder_before_minutes(self):
        raw=self.shift_before.get().strip()
        try:
            amount=int(raw)
        except Exception:
            raise ValueError("Reminder amount must be a whole number.")

        if amount<0:
            raise ValueError("Reminder amount cannot be negative.")

        unit=self.shift_before_unit.get().strip()
        if unit=="Day(s)":
            return amount*24*60
        if unit=="Hour(s)":
            return amount*60
        if unit=="Minute(s)":
            return amount

        raise ValueError("Choose Day(s), Hour(s), or Minute(s).")

    def reminder_before_label(self):
        amount=self.shift_before.get().strip()
        unit=self.shift_before_unit.get().strip()
        return f"{amount} {unit}"

    def load_shift_preview(self):
        path=self.dienstplan_path.get().strip()

        if self.dienstplan.mode!="google" and not path:
            return messagebox.showwarning(APP_NAME,"Choose the TP Liste source first.")

        if not self.store.rows:
            return messagebox.showwarning(APP_NAME,"Load the driver/contact database first.")

        try:
            target=datetime.strptime(self.shift_date.get().strip(),"%Y-%m-%d").date()
            before=self.reminder_before_minutes()
        except Exception as e:
            return messagebox.showerror(
                APP_NAME,
                "Use date YYYY-MM-DD and choose the reminder amount/unit.\n\n"
                "Examples:\n"
                "1 Day(s)\n"
                "1 Hour(s)\n"
                "30 Minute(s)\n\n"
                + str(e)
            )

        try:
            if self.dienstplan.mode!="google":
                self.dienstplan.load(path)
            shifts=self.dienstplan.shifts_for_date(target)
            shifts=sorted(
                shifts,
                key=lambda x:(
                    self.dienstplan._start_minutes(x.get("shift_text","")),
                    normalize_name(x.get("name",""))
                )
            )
        except Exception as e:
            msg=str(e)
            if self.dienstplan.mode=="google" and "No daily TP sheet" in msg:
                msg += (
                    "\n\nThe selected date must have a daily tab named DD.MM.YYYY inside the configured "
                    "VIE-LTS-TP Liste spreadsheet. For example, 2026-09-23 requires a tab named 23.09.2026."
                )
            return messagebox.showerror(APP_NAME,msg)

        channel=self.shift_channel.get()
        preview=[]

        for sh in shifts:
            if not sh.get("shift_start"):
                continue

            contact,match_method=self.match_shift_contact(sh)
            start_dt=datetime.strptime(sh["shift_date"]+" "+sh["shift_start"],"%Y-%m-%d %H:%M")
            remind_dt=start_dt-timedelta(minutes=before)

            status="Ready"
            contact_text=""
            driver_id=""

            if not contact:
                status="Not found in contacts"
            else:
                driver_id=contact.get("id","")
                if channel=="WhatsApp":
                    contact_text=contact.get("phone","")
                    if not normalize_phone(contact_text,self.cc.get()):
                        status="Missing WhatsApp phone"
                else:
                    contact_text=contact.get("email","")
                    if not contact_text:
                        status="Missing email"

                if clean(contact.get("status")) in ("not active","inactive","false","0","no","nein"):
                    status="Not Active"

            if remind_dt<=datetime.now():
                status="Reminder time passed"

            preview.append({
                **sh,
                "driver_id":driver_id,
                "match_method":match_method,
                "contact":contact_text,
                "status":status,
                "reminder_at":remind_dt.strftime("%Y-%m-%d %H:%M"),
                "report_time":time_minus_minutes(sh["shift_start"],30),
            })

        self.shift_preview=preview
        self.shift_checked=set()
        self.render_shift_preview()
        ready=sum(1 for x in preview if x["status"]=="Ready")
        self.set_status(f"Loaded {len(preview)} working shifts. {ready} ready for reminders.")

    def visible_shift_preview_rows(self):
        query=self.shift_search.get().strip().casefold() if hasattr(self,"shift_search") else ""
        visible=[]
        for i,x in enumerate(self.shift_preview):
            if query:
                haystack=" ".join([
                    str(x.get("name","")),
                    str(x.get("driver_id","")),
                ]).casefold()
                if query not in haystack:
                    continue
            visible.append((i,x))
        return visible

    def render_shift_preview(self):
        if not hasattr(self,"shift_tree"):
            return
        self.shift_tree.delete(*self.shift_tree.get_children())

        visible=self.visible_shift_preview_rows()
        ready_keys={
            f"{x['name_key']}|{x['shift_date']}"
            for _,x in visible if x["status"]=="Ready"
        }
        checked_ready=ready_keys.intersection(self.shift_checked)
        if not checked_ready:
            master="☐"
        elif checked_ready==ready_keys and ready_keys:
            master="☑"
        else:
            master="◩"
        self.shift_tree.heading("pick",text=master,command=self.toggle_all_shift_rows)

        for i,x in visible:
            key=f"{x['name_key']}|{x['shift_date']}"
            mark="☑" if key in self.shift_checked else "☐"
            self.shift_tree.insert(
                "","end",iid=f"shift_{i}",
                values=(mark,x["name"],x["shift_start"],x.get("report_time",""),x["shift_text"],x["reminder_at"],x["contact"],x["status"])
            )

    def shift_tree_click(self,event):
        if self.shift_tree.identify("region",event.x,event.y)!="cell":
            return
        if self.shift_tree.identify_column(event.x)!="#1":
            return
        item=self.shift_tree.identify_row(event.y)
        if not item:
            return
        try:
            idx=int(item.split("_",1)[1])
            x=self.shift_preview[idx]
        except Exception:
            return "break"

        if x["status"]!="Ready":
            return "break"

        key=f"{x['name_key']}|{x['shift_date']}"
        if key in self.shift_checked:
            self.shift_checked.remove(key)
        else:
            self.shift_checked.add(key)
        self.render_shift_preview()
        try:
            self.shift_tree.selection_set(item)
            self.shift_tree.focus(item)
        except Exception:
            pass
        return "break"

    def shift_select_all_shortcut(self,event=None):
        self.shift_checked.update(
            f"{x['name_key']}|{x['shift_date']}"
            for _,x in self.visible_shift_preview_rows() if x.get("status")=="Ready"
        )
        self.render_shift_preview()
        return "break"

    def shift_clear_shortcut(self,event=None):
        self.shift_checked.clear()
        self.render_shift_preview()
        return "break"

    def shift_space_toggle(self,event=None):
        sel=self.shift_tree.selection() if hasattr(self,"shift_tree") else ()
        if not sel:
            return "break"
        for item in sel:
            try:
                idx=int(str(item).split("_",1)[1])
                x=self.shift_preview[idx]
            except Exception:
                continue
            if x.get("status")!="Ready":
                continue
            key=f"{x['name_key']}|{x['shift_date']}"
            if key in self.shift_checked:
                self.shift_checked.remove(key)
            else:
                self.shift_checked.add(key)
        self.render_shift_preview()
        return "break"

    def shift_tree_double_click(self,event):
        # Double-clicking the checkbox must never open Edit Shift.
        if self.shift_tree.identify("region",event.x,event.y)=="cell" and self.shift_tree.identify_column(event.x)=="#1":
            return "break"
        item=self.shift_tree.identify_row(event.y)
        if item:
            self.shift_tree.selection_set(item)
            self.edit_shift_dialog()
        return "break"

    def toggle_all_shift_rows(self):
        ready={
            f"{x['name_key']}|{x['shift_date']}"
            for _,x in self.visible_shift_preview_rows() if x["status"]=="Ready"
        }
        if not ready:
            return
        if ready.issubset(self.shift_checked):
            self.shift_checked.difference_update(ready)
        else:
            self.shift_checked.update(ready)
        self.render_shift_preview()

    def render_shift_message(self,template,contact,sh):
        out=template
        values={
            "name":contact.get("name",sh.get("name","")),
            "id":contact.get("id",""),
            "shift_date":sh.get("shift_date_de",""),
            "shift_day":sh.get("shift_day",""),
            # The driver-facing time is always 30 minutes before the TP-list start.
            "shift_start":sh.get("report_time") or time_minus_minutes(sh.get("shift_start",""),30),
            "report_time":sh.get("report_time") or time_minus_minutes(sh.get("shift_start",""),30),
            "shift_text":sh.get("shift_text",""),
        }
        for k,v in values.items():
            out=out.replace("{"+k+"}",str(v or ""))
        return out

    def send_shift_reminders_now(self):
        chosen=[
            x for x in self.shift_preview
            if f"{x['name_key']}|{x['shift_date']}" in self.shift_checked and x["status"]=="Ready"
        ]
        if not chosen:
            return messagebox.showwarning(APP_NAME,"Tick at least one Ready shift reminder.")

        contacts_by_id={
            str(r.get("id","")).strip().casefold():r
            for r in self.store.rows if str(r.get("id","")).strip()
        }
        channel=self.shift_channel.get()
        template=self.shift_msg.get("1.0","end").rstrip()

        if not messagebox.askyesno(
            APP_NAME,
            f"Send {len(chosen)} shift reminder(s) now?\n\nChannel: {channel}"
        ):
            return

        try:
            delay=max(3,float(self.delay.get()))
        except Exception:
            delay=7

        def run():
            sent=failed=skipped=0

            for i,sh in enumerate(chosen):
                contact=contacts_by_id.get(str(sh.get("driver_id","")).strip().casefold())
                if not contact:
                    contact,_=self.match_shift_contact(sh)

                if not contact:
                    skipped+=1
                    continue

                rendered=self.render_shift_message(template,contact,sh)
                subject=f"Dienst-Erinnerung {sh['shift_date_de']} {sh['shift_start']}"

                try:
                    if channel=="WhatsApp":
                        if driver_is_inactive(contact):
                            raise RuntimeError("Driver is Not Active.")
                        phone=normalize_phone(contact.get("phone",""),self.cc.get())
                        if not phone:
                            raise RuntimeError("Missing WhatsApp phone.")
                        self.wa.send(phone,rendered,[])
                        history_add(
                            contact,"WhatsApp","Shift Reminder","SENT",
                            sh.get("shift_text",""),"Done"
                        )
                        self.mark(contact)
                    else:
                        if driver_is_inactive(contact):
                            raise RuntimeError("Driver is Not Active.")
                        email=str(contact.get("email","") or "").strip()
                        if not email:
                            raise RuntimeError("Missing email.")
                        self.mail.send(email,subject,rendered,[])
                        history_add(
                            contact,"Email","Shift Reminder","SENT",
                            sh.get("shift_text",""),"Done"
                        )
                        self.mark(contact)

                    sent+=1
                except Exception as e:
                    failed+=1
                    history_add(
                        contact,channel,"Shift Reminder",history_result_for_exception(e),
                        str(e),"Done"
                    )

                if i<len(chosen)-1:
                    time.sleep(delay)

            self.set_status(
                f"Shift reminders sent now. Sent {sent}, failed {failed}, skipped {skipped}."
            )
            self.after(0,self.history_refresh)
            self.after(0,self.render)

        threading.Thread(target=run,daemon=True).start()

    def schedule_shift_reminders(self):
        chosen=[
            x for x in self.shift_preview
            if f"{x['name_key']}|{x['shift_date']}" in self.shift_checked and x["status"]=="Ready"
        ]
        if not chosen:
            return messagebox.showwarning(APP_NAME,"Tick at least one Ready shift reminder.")

        contacts_by_id={
            str(r.get("id","")).strip().casefold():r
            for r in self.store.rows if str(r.get("id","")).strip()
        }
        channel=self.shift_channel.get()
        template=self.shift_msg.get("1.0","end").rstrip()

        if not messagebox.askyesno(
            APP_NAME,
            f"Schedule {len(chosen)} shift reminder(s)?\n\n"
            f"Channel: {channel}\nBefore shift: {self.reminder_before_label()}"
        ):
            return

        jobs=self.load_scheduled_jobs()
        created=0

        for sh in chosen:
            contact=contacts_by_id.get(str(sh.get("driver_id","")).strip().casefold())
            if not contact:
                contact,_=self.match_shift_contact(sh)
            if not contact:
                continue

            rendered=self.render_shift_message(template,contact,sh)
            subject=f"Dienst-Erinnerung {sh['shift_date_de']} {sh['shift_start']}"

            jobs.append({
                "id":datetime.now().strftime("%Y%m%d%H%M%S%f")+str(created),
                "send_at":sh["reminder_at"],
                "channel":channel,
                "driver_ids":[contact["id"]],
                "message":rendered,
                "subject":subject,
                "delay":3,
                "common_attachments":[],
                "attach_driver_qr":False,
                "followup":"Done",
                "status":"Scheduled",
                "created":datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "kind":"Shift Reminder",
                "shift_date":sh["shift_date"],
                "shift_start":sh["shift_start"],
                "shift_text":sh["shift_text"],
            })
            created+=1

        self.save_scheduled_jobs(jobs)
        self.refresh_scheduled_tab()
        self.set_status(f"Scheduled {created} shift reminders.")
        messagebox.showinfo(APP_NAME,f"Scheduled {created} shift reminder(s).")

    def choose_contacts(self):
        p=filedialog.askopenfilename(filetypes=[("Excel/CSV","*.xlsx *.xlsm *.csv")])
        if p:self.contacts.set(p)
    def load(self):
        try:self.store.load(self.contacts.get());self.render()
        except Exception as e:messagebox.showerror(APP_NAME,str(e))
    def refresh(self):
        try:
            self.store.refresh()
            self.render()
        except Exception as e:
            messagebox.showerror(APP_NAME,str(e))
    def add_driver_dialog(self):
        if not self.store.ready():
            return messagebox.showwarning(APP_NAME,"Connect Google Sheets or load a local database first.")
        AddDriver(self,self.add_driver)
    def add_driver(self,d):
        self.store.add_driver(d)
        self.render()
        saved=next((r for r in self.store.rows if str(r.get("id",""))==str(d.get("id",""))),d)
        self.queue_qr_cache_refresh([saved])
        self.set_status(f"Driver {d.get('id','')} added to {self.store.source_name()}.")
        return True

    def edit_driver_dialog(self):
        rs=self.selected()
        if len(rs)!=1:
            return messagebox.showwarning(APP_NAME,"Select exactly one driver to edit.")
        if self.store.mode!="google" and (not self.store.path or self.store.path.suffix.lower() not in (".xlsx",".xlsm")):
            return messagebox.showwarning(APP_NAME,"Editing requires Google Sheets or an Excel .xlsx/.xlsm file.")
        EditDriver(self,rs[0],self.save_driver_edit)

    def save_driver_edit(self,original_id,data):
        self.store.edit_driver(original_id,data)
        self.render()
        saved=next((r for r in self.store.rows if str(r.get("id",""))==str(data.get("id",""))),data)
        self.queue_qr_cache_refresh([saved])
        self.set_status(f"Driver {data.get('id','')} saved directly in {self.store.source_name()}.")
        return True

    def delete_driver(self):
        rs=self.selected()
        if len(rs)!=1:
            return messagebox.showwarning(APP_NAME,"Select exactly one driver to delete.")
        r=rs[0]
        if self.store.mode!="google" and (not self.store.path or self.store.path.suffix.lower() not in (".xlsx",".xlsm")):
            return messagebox.showwarning(APP_NAME,"Deleting requires Google Sheets or an Excel .xlsx/.xlsm file.")

        extra = "" if self.store.mode=="google" else "\n\nA backup copy will be created automatically."
        if not messagebox.askyesno(
            APP_NAME,
            f"Delete this driver from {self.store.source_name()}?\n\n{r['name']} ({r['id']})" + extra
        ):
            return
        try:
            self.store.delete_driver(r["id"])
            self.render()
            self.set_status(f"Driver {r['id']} deleted from {self.store.source_name()}.")
        except Exception as e:
            messagebox.showerror(APP_NAME,str(e))
    def add_files(self):
        for p in filedialog.askopenfilenames():
            if p not in self.attachments:self.attachments.append(p)
        self.attach_label.config(text=", ".join(Path(x).name for x in self.attachments[:3]) + (f" +{len(self.attachments)-3}" if len(self.attachments)>3 else ""))
    def clear_files(self):
        self.attachments=[];self.use_common_files.set(False);self.attach_label.config(text="No common attachments")
    def apply_template(self):
        self.msg.delete("1.0","end");self.msg.insert("1.0",self.templates.get(self.template.get(),""))
    def save_template(self):
        n=simpledialog.askstring(APP_NAME,"Template name:")
        if n:
            self.templates[n]=self.msg.get("1.0","end").rstrip()
            TEMPLATES_FILE.write_text(json.dumps(self.templates,ensure_ascii=False,indent=2),encoding="utf-8")
            self.tc["values"]=sorted(self.templates)
            self.template.set(n)
            self.set_status(f'Template "{n}" saved.')

    def edit_template(self):
        name=self.template.get().strip()
        if not name or name not in self.templates:
            return messagebox.showwarning(APP_NAME,"Choose a template first.")
        TemplateEditor(
            self,
            name,
            self.templates.get(name,""),
            self.save_template_changes,
            self.delete_template
        )

    def save_template_changes(self,old_name,new_name,body):
        if new_name!=old_name and new_name in self.templates:
            if not messagebox.askyesno(APP_NAME,f'Template "{new_name}" already exists. Replace it?'):
                return

        if old_name in self.templates and new_name!=old_name:
            del self.templates[old_name]

        self.templates[new_name]=body
        TEMPLATES_FILE.write_text(
            json.dumps(self.templates,ensure_ascii=False,indent=2),
            encoding="utf-8"
        )
        self.tc["values"]=sorted(self.templates)
        self.template.set(new_name)
        self.msg.delete("1.0","end")
        self.msg.insert("1.0",body)
        self.set_status(f'Template "{new_name}" updated.')

    def delete_template(self,name):
        if name in self.templates:
            del self.templates[name]
            TEMPLATES_FILE.write_text(
                json.dumps(self.templates,ensure_ascii=False,indent=2),
                encoding="utf-8"
            )
            names=sorted(self.templates)
            self.tc["values"]=names
            next_name=names[0] if names else ""
            self.template.set(next_name)
            self.msg.delete("1.0","end")
            if next_name:
                self.msg.insert("1.0",self.templates[next_name])
            self.set_status(f'Template "{name}" deleted.')

    def visible(self):
        q=self.search.get().lower().strip();out=[]
        for r in self.store.rows:
            if self.active.get() and clean(r["status"]) in ("not active","inactive","false","0","no","nein"):
                continue
            if q and q not in " ".join(str(r.get(k,"")) for k in ("id","name","phone","email","notes")).lower():
                continue
            out.append(r)
        return out

    def render(self):
        self.current=self.visible();self.tree.delete(*self.tree.get_children())
        visible_ids={r["id"] for r in self.current}
        checked_visible=visible_ids.intersection(self.checked_ids)

        if not checked_visible:
            master="☐"
        elif checked_visible==visible_ids and visible_ids:
            master="☑"
        else:
            master="◩"

        self.tree.heading("pick",text=master,command=self.toggle_select_all_header)

        for r in self.current:
            mark="☑" if r["id"] in self.checked_ids else "☐"
            self.tree.insert("", "end", values=(mark,r["id"],r["name"],display_phone(r["phone"]),r["email"],r["status"],r["last_contacted"],r["notes"]))
        active=sum(1 for r in self.store.rows if clean(r["status"]) not in ("not active","inactive","false","0","no","nein"))
        self.dashboard.set(f"Drivers {len(self.store.rows)} • Checked {len(self.checked_ids)} • Active {active} • Missing phone {sum(not r['phone'] for r in self.store.rows)} • Missing email {sum(not r['email'] for r in self.store.rows)}")

    def toggle_select_all_header(self):
        visible_ids={r["id"] for r in self.current}
        if not visible_ids:
            return

        checked_visible=visible_ids.intersection(self.checked_ids)

        # Normal master-checkbox behavior:
        # - if all visible rows are checked -> clear them all
        # - otherwise -> check them all
        if checked_visible==visible_ids:
            self.checked_ids.difference_update(visible_ids)
        else:
            self.checked_ids.update(visible_ids)

        self.render()

    def tree_click(self,event):
        region=self.tree.identify("region",event.x,event.y)
        column=self.tree.identify_column(event.x)
        item=self.tree.identify_row(event.y)
        if region=="cell" and column=="#1" and item:
            now=time.time()
            last_item,last_time=self._last_driver_checkbox_click
            if item==last_item and (now-last_time)<0.35:
                return "break"
            self._last_driver_checkbox_click=(item,now)
            vals=self.tree.item(item,"values")
            if vals:
                did=str(vals[1])
                if did in self.checked_ids:self.checked_ids.remove(did)
                else:self.checked_ids.add(did)
                self.render()
            return "break"

    def driver_select_all_shortcut(self,event=None):
        self.checked_ids.update(r.get("id","") for r in self.current if r.get("id",""))
        self.render()
        return "break"

    def driver_clear_shortcut(self,event=None):
        visible={r.get("id","") for r in self.current if r.get("id","")}
        self.checked_ids.difference_update(visible)
        self.render()
        return "break"

    def driver_space_toggle(self,event=None):
        sel=self.tree.selection() if hasattr(self,"tree") else ()
        if not sel:
            return "break"
        visible_by_index={str(i):r for i,r in enumerate(self.current)}
        for item in sel:
            vals=self.tree.item(item,"values")
            if not vals:
                continue
            did=str(vals[1])
            if did in self.checked_ids:
                self.checked_ids.remove(did)
            else:
                self.checked_ids.add(did)
        self.render()
        return "break"

    def selected(self):
        by={r["id"]:r for r in self.current}
        return [by[did] for did in self.checked_ids if did in by]

    def edit_notes(self):
        rs=self.selected()
        if len(rs)!=1:return messagebox.showwarning(APP_NAME,"Select exactly one driver.")
        r=rs[0];n=simpledialog.askstring(APP_NAME,"Notes:",initialvalue=r["notes"])
        if n is not None:self.store.update(r["id"],"notes",n);self.render()

    def format_msg(self,r):
        t=self.msg.get("1.0","end").rstrip()
        for k in ("name","id","phone","email","notes"):t=t.replace("{"+k+"}",r.get(k,""))
        return t

    def files_for(self,r):
        out=list(self.attachments) if self.use_common_files.get() else []
        if self.attach_driver_qr.get():
            try:
                qrp=self.ensure_driver_qr_cached(r)
                if qrp:
                    out.append(str(qrp))
            except Exception as e:
                raise RuntimeError(f"Could not prepare QR for {r.get('name','')}: {e}")
        return out

    def mark(self,r):
        try:self.store.update(r["id"],"last_contacted",datetime.now().strftime("%Y-%m-%d %H:%M"))
        except:pass

    def wa_one(self,r):
        if driver_is_inactive(r): raise RuntimeError("Driver is Not Active.")
        p=normalize_phone(r["phone"],self.cc.get())
        if not p:raise RuntimeError("Missing WhatsApp phone.")
        self.wa.send(p,self.format_msg(r),self.files_for(r));history_add(r,"WhatsApp","Message","SENT",self.template.get(),self.follow.get());self.mark(r)

    def email_one(self,r):
        if driver_is_inactive(r):
            raise RuntimeError("Driver is Not Active.")
        if not r["email"]:
            raise RuntimeError("Missing email.")

        subj=self.subject.get().replace("{name}",r["name"]).replace("{id}",r["id"])
        self.set_status(f"Sending email to {r['name']} <{r['email']}>...")

        self.mail.send(
            r["email"],
            subj,
            self.format_msg(r),
            self.files_for(r)
        )

        history_add(r,"Email","Message","SENT",subj,self.follow.get())
        self.mark(r)

    def _set_send_progress(self,done,total,sent,failed,no_whatsapp=0,started=None,finished=False,stopped=False):
        total=max(int(total or 0),1)
        done=max(0,min(int(done or 0),total))
        remaining=max(total-done,0)
        pct=(done/total)*100
        eta_text=""
        if started is not None and done>0 and remaining>0:
            elapsed=max(time.monotonic()-started,0.01)
            eta_text=f" • ETA {format_duration((elapsed/done)*remaining)}"
        if finished:
            text=(
                f"Done {done}/{total} • Sent {sent} • No WhatsApp {no_whatsapp} "
                f"• Failed {failed}"
            )
        elif stopped:
            text=(
                f"Stopped {done}/{total} • Sent {sent} • No WhatsApp {no_whatsapp} "
                f"• Failed {failed} • Left {remaining}"
            )
        else:
            text=(
                f"{done}/{total} done • Sent {sent} • No WhatsApp {no_whatsapp} "
                f"• Failed {failed} • Left {remaining}{eta_text}"
            )
        self.after(0,lambda:self.send_progress_value.set(pct))
        self.after(0,lambda:self.send_progress_text.set(text))

    def batch(self,mode):
        rows=self.selected()
        if not rows:return messagebox.showwarning(APP_NAME,"Select at least one driver.")
        if self.sending:
            return messagebox.showwarning(APP_NAME,"A send is already running. Stop it or wait until it finishes.")
        if not messagebox.askyesno(APP_NAME,f"Send to {len(rows)} checked driver(s) via {mode}?"):return
        try:delay=max(3,float(self.delay.get()))
        except:return messagebox.showerror(APP_NAME,"Delay must be a number.")
        self.stop=False
        self.sending=True
        try:self.send_button.configure(state="disabled")
        except Exception:pass
        self.send_progress_value.set(0)
        self.send_progress_text.set(f"0/{len(rows)} done • Sent 0 • No WhatsApp 0 • Failed 0 • Left {len(rows)}")
        def run():
            sent=failed=no_whatsapp=0
            done=0
            started=time.monotonic()
            try:
                for i,r in enumerate(rows,1):
                    if self.stop:
                        break
                    self.set_status(
                        f"Sending {mode} {i}/{len(rows)} • Sent {sent} • No WhatsApp {no_whatsapp} "
                        f"• Failed {failed} • {r['name']}"
                    )
                    try:
                        if mode=="WhatsApp":
                            self.wa_one(r)
                        elif mode=="Email":
                            self.email_one(r)
                        sent+=1
                    except WhatsAppRecipientError as e:
                        no_whatsapp+=1
                        history_add(
                            r,mode,"Message","NO WHATSAPP",
                            str(e),self.follow.get()
                        )
                    except Exception as e:
                        failed+=1
                        history_add(
                            r,mode,"Message","FAILED",
                            str(e),self.follow.get()
                        )
                    done=i
                    self._set_send_progress(
                        done,len(rows),sent,failed,no_whatsapp,started=started
                    )
                    if i<len(rows) and not self.stop:
                        time.sleep(delay)
                stopped=bool(self.stop and done<len(rows))
                if stopped:
                    self._set_send_progress(
                        done,len(rows),sent,failed,no_whatsapp,started=started,stopped=True
                    )
                    self.set_status(
                        f"Stopped. Processed {done}/{len(rows)}. Sent {sent}, "
                        f"No WhatsApp {no_whatsapp}, failed {failed}."
                    )
                else:
                    self._set_send_progress(
                        len(rows),len(rows),sent,failed,no_whatsapp,started=started,finished=True
                    )
                    self.set_status(
                        f"Finished {len(rows)}/{len(rows)}. Sent {sent}, "
                        f"No WhatsApp {no_whatsapp}, failed {failed}."
                    )
            finally:
                self.sending=False
                self.after(0,lambda:self.send_button.configure(state="normal"))
                self.after(0,self.history_refresh)
                self.after(0,self.refresh)
        threading.Thread(target=run,daemon=True).start()

    def send_selected_simple(self):
        mode=self.send_mode.get() or "WhatsApp"
        if self.send_timing.get()=="At time":
            self.schedule_send(mode)
        else:
            self.batch(mode)

    def load_scheduled_jobs(self):
        ensure_dirs()
        if not SCHEDULE_FILE.exists():
            return []
        try:
            data=json.loads(SCHEDULE_FILE.read_text(encoding="utf-8"))
            return data if isinstance(data,list) else []
        except Exception:
            return []

    def save_scheduled_jobs(self,jobs):
        ensure_dirs()
        SCHEDULE_FILE.write_text(json.dumps(jobs,ensure_ascii=False,indent=2),encoding="utf-8")

    def schedule_send(self,mode):
        rows=self.selected()
        if not rows:
            return messagebox.showwarning(APP_NAME,"Tick at least one driver.")

        try:
            send_at=datetime.strptime(
                self.schedule_date.get().strip()+" "+self.schedule_time.get().strip(),
                "%Y-%m-%d %H:%M"
            )
        except ValueError:
            return messagebox.showerror(
                APP_NAME,
                "Use date YYYY-MM-DD and time HH:MM.\n\nExample: 2026-09-22 14:30"
            )

        if send_at<=datetime.now():
            return messagebox.showerror(APP_NAME,"Scheduled time must be in the future.")

        try:
            delay=max(3,float(self.delay.get()))
        except ValueError:
            return messagebox.showerror(APP_NAME,"Delay must be a number.")

        driver_ids=[r["id"] for r in rows]
        names=", ".join(r["name"] or r["id"] for r in rows[:5])
        if len(rows)>5:
            names+=f" +{len(rows)-5} more"

        if not messagebox.askyesno(
            APP_NAME,
            f"Schedule {len(rows)} driver(s)?\n\nChannel: {mode}\nTime: {send_at.strftime('%Y-%m-%d %H:%M')}\n\n{names}"
        ):
            return

        job={
            "id":datetime.now().strftime("%Y%m%d%H%M%S%f"),
            "send_at":send_at.strftime("%Y-%m-%d %H:%M"),
            "channel":mode,
            "driver_ids":driver_ids,
            "message":self.msg.get("1.0","end").rstrip(),
            "subject":self.subject.get(),
            "delay":delay,
            "common_attachments":list(self.attachments) if self.use_common_files.get() else [],
            "attach_driver_qr":bool(self.attach_driver_qr.get()),
            "followup":self.follow.get(),
            "status":"Scheduled",
            "created":datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }

        jobs=self.load_scheduled_jobs()
        jobs.append(job)
        self.save_scheduled_jobs(jobs)
        self.refresh_scheduled_tab()
        self.set_status(f"Scheduled {len(rows)} driver(s) for {job['send_at']}.")
        messagebox.showinfo(APP_NAME,f"Scheduled for {job['send_at']}.")

    def refresh_scheduled_tab(self):
        if not hasattr(self,"st"):
            return

        jobs=self.load_scheduled_jobs()
        valid_ids={str(j.get("id","")) for j in jobs}
        self.scheduled_checked.intersection_update(valid_ids)

        self.st.delete(*self.st.get_children())
        for job in jobs:
            jid=str(job.get("id",""))
            ids=job.get("driver_ids",[])
            drivers=", ".join(ids[:8]) + (f" +{len(ids)-8}" if len(ids)>8 else "")
            label=drivers
            if job.get("kind")=="Shift Reminder":
                label=f"Shift reminder • {drivers} • {job.get('shift_start','')}"
            mark="☑" if jid in self.scheduled_checked else "☐"
            self.st.insert(
                "","end",iid=jid,
                values=(
                    mark,job.get("send_at",""),job.get("channel",""),label,
                    job.get("status",""),job.get("created","")
                )
            )

        all_ids={str(j.get("id","")) for j in jobs}
        checked=all_ids.intersection(self.scheduled_checked)
        master="☐" if not checked else ("☑" if checked==all_ids and all_ids else "◩")
        self.st.heading("pick",text=master,command=self.toggle_all_scheduled_header)

    def scheduled_tree_click(self,event):
        if self.st.identify("region",event.x,event.y)!="cell":
            return
        if self.st.identify_column(event.x)!="#1":
            return

        item=self.st.identify_row(event.y)
        if not item:
            return "break"

        now=time.time()
        last_item,last_time=self._last_schedule_checkbox_click
        if item==last_item and (now-last_time)<0.35:
            return "break"
        self._last_schedule_checkbox_click=(item,now)

        if item in self.scheduled_checked:
            self.scheduled_checked.remove(item)
        else:
            self.scheduled_checked.add(item)
        self.refresh_scheduled_tab()
        return "break"

    def select_all_scheduled(self):
        self.scheduled_checked={
            str(j.get("id",""))
            for j in self.load_scheduled_jobs()
            if str(j.get("id",""))
        }
        self.refresh_scheduled_tab()

    def clear_scheduled_checks(self):
        self.scheduled_checked.clear()
        self.refresh_scheduled_tab()

    def toggle_all_scheduled_header(self):
        jobs=self.load_scheduled_jobs()
        all_ids={str(j.get("id","")) for j in jobs if str(j.get("id",""))}
        if all_ids and all_ids.issubset(self.scheduled_checked):
            self.scheduled_checked.difference_update(all_ids)
        else:
            self.scheduled_checked.update(all_ids)
        self.refresh_scheduled_tab()

    def scheduled_select_all_shortcut(self,event=None):
        self.select_all_scheduled()
        return "break"

    def scheduled_clear_shortcut(self,event=None):
        self.clear_scheduled_checks()
        return "break"

    def scheduled_space_toggle(self,event=None):
        sel=self.st.selection() if hasattr(self,"st") else ()
        if not sel:
            return "break"
        for jid in sel:
            if jid in self.scheduled_checked:
                self.scheduled_checked.remove(jid)
            else:
                self.scheduled_checked.add(jid)
        self.refresh_scheduled_tab()
        return "break"

    def delete_scheduled_job(self):
        ids=set(self.scheduled_checked)

        # If nothing was explicitly checked, allow deleting highlighted rows too.
        if not ids and hasattr(self,"st"):
            ids.update(self.st.selection())

        if not ids:
            return messagebox.showwarning(APP_NAME,"Check one or more scheduled sends first.")

        jobs=self.load_scheduled_jobs()
        targets=[j for j in jobs if str(j.get("id","")) in ids]
        running=[j for j in targets if j.get("status")=="Sending"]
        deletable=[j for j in targets if j.get("status")!="Sending"]

        if not deletable:
            return messagebox.showwarning(APP_NAME,"The selected scheduled send(s) are already running.")

        msg=f"Delete {len(deletable)} scheduled send(s)?"
        if running:
            msg+=f"\n\n{len(running)} running item(s) will be kept."
        if not messagebox.askyesno(APP_NAME,msg):
            return

        delete_ids={str(j.get("id","")) for j in deletable}
        jobs=[j for j in jobs if str(j.get("id","")) not in delete_ids]
        self.save_scheduled_jobs(jobs)
        self.scheduled_checked.difference_update(delete_ids)
        self.refresh_scheduled_tab()
        self.set_status(f"Deleted {len(delete_ids)} scheduled send(s).")

    def check_scheduled_jobs(self):
        try:
            jobs=self.load_scheduled_jobs()
            changed=False
            now=datetime.now()
            for job in jobs:
                if job.get("status")!="Scheduled":
                    continue
                try:
                    due=datetime.strptime(job.get("send_at",""),"%Y-%m-%d %H:%M")
                except Exception:
                    job["status"]="Invalid"
                    changed=True
                    continue
                if due<=now:
                    job["status"]="Sending"
                    changed=True
                    self.run_scheduled_job(job)
            if changed:
                self.save_scheduled_jobs(jobs)
                self.refresh_scheduled_tab()
        finally:
            self.after(10000,self.check_scheduled_jobs)

    def run_scheduled_job(self,job):
        def run():
            jobs=self.load_scheduled_jobs()
            current=next((j for j in jobs if j.get("id")==job.get("id")),job)

            wanted=set(current.get("driver_ids",[]))
            rows=[r for r in self.store.rows if r["id"] in wanted]

            if not rows:
                current["status"]="Failed"
                current["error"]="No matching drivers loaded. Keep the same driver Excel file loaded."
                self.save_scheduled_job_result(current)
                return

            old_message=self.msg.get("1.0","end").rstrip()
            old_subject=self.subject.get()
            old_follow=self.follow.get()
            old_common=list(self.attachments)
            old_use_common=self.use_common_files.get()
            old_attach_qr=self.attach_driver_qr.get()
            old_delay=self.delay.get()

            try:
                self.msg.delete("1.0","end"); self.msg.insert("1.0",current.get("message",""))
                self.subject.set(current.get("subject","LTS Transport"))
                self.follow.set(current.get("followup","Done"))
                self.attachments=list(current.get("common_attachments",[]))
                self.use_common_files.set(bool(self.attachments))
                self.attach_driver_qr.set(bool(current.get("attach_driver_qr",False)))
                self.delay.set(str(current.get("delay",7)))

                sent=failed=0
                mode=current.get("channel","WhatsApp")
                delay=max(3,float(current.get("delay",7)))

                for i,r in enumerate(rows):
                    try:
                        if mode=="WhatsApp":
                            self.wa_one(r)
                        else:
                            self.email_one(r)
                        sent+=1
                    except Exception as e:
                        failed+=1
                        history_add(r,mode,"Scheduled Message",history_result_for_exception(e),str(e),current.get("followup",""))
                    if i<len(rows)-1:
                        time.sleep(delay)

                current["status"]="Done" if failed==0 else "Completed with errors"
                current["result"]=f"Sent {sent}, failed {failed}"
                current["completed"]=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            except Exception as e:
                current["status"]="Failed"
                current["error"]=str(e)
            finally:
                self.msg.delete("1.0","end"); self.msg.insert("1.0",old_message)
                self.subject.set(old_subject); self.follow.set(old_follow)
                self.attachments=old_common
                self.use_common_files.set(old_use_common)
                self.attach_driver_qr.set(old_attach_qr)
                self.delay.set(old_delay)
                self.save_scheduled_job_result(current)
                self.set_status(f"Scheduled send finished: {current.get('status','')}.")
                self.after(0,self.history_refresh)

        threading.Thread(target=run,daemon=True).start()

    def save_scheduled_job_result(self,updated):
        jobs=self.load_scheduled_jobs()
        found=False
        for i,j in enumerate(jobs):
            if j.get("id")==updated.get("id"):
                jobs[i]=updated
                found=True
                break
        if not found:
            jobs.append(updated)
        self.save_scheduled_jobs(jobs)
        self.after(0,self.refresh_scheduled_tab)

    def wa_selected(self):self.batch("WhatsApp")
    def email_selected(self):self.batch("Email")
    def smart_selected(self):self.batch(self.send_mode.get() or "WhatsApp")
    def stop_send(self):self.stop=True;self.set_status("Stopping after current driver...")

    def qr_cache_index_path(self):
        return self.qr_output_dir()/"qr_cache_index.json"

    def load_qr_cache_index(self):
        p=self.qr_cache_index_path()
        try:
            return json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}
        except Exception:
            return {}

    def save_qr_cache_index(self,data):
        p=self.qr_cache_index_path()
        p.parent.mkdir(parents=True,exist_ok=True)
        p.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf-8")

    def ensure_driver_qr_cached(self,r,force=False):
        did=str(r.get("id","")).strip()
        if not did:
            return None
        name=str(r.get("name","")).strip()
        path=self.qr_output_dir()/f"driver_{did}.png"
        index=self.load_qr_cache_index()
        signature={"name":name,"payload":f"D:{did}"}

        if not force and path.exists() and index.get(did)==signature:
            return path

        path=self.generate_driver_qr(r)
        index[did]=signature
        self.save_qr_cache_index(index)
        return path

    def queue_qr_cache_refresh(self,rows=None,force=False):
        rows=list(rows if rows is not None else self.store.rows)
        def run():
            built=0
            for r in rows:
                try:
                    before=self.qr_output_dir()/f"driver_{str(r.get('id','')).strip()}.png"
                    existed=before.exists()
                    self.ensure_driver_qr_cached(r,force=force)
                    if force or not existed:
                        built+=1
                except Exception:
                    pass
            if force:
                self.after(0,lambda:self.set_status(f"QR cache rebuilt for {len(rows)} driver(s)."))
        threading.Thread(target=run,daemon=True).start()

    def generate_selected_qr(self):
        # GENERATE QR CODE uses ONLY checked drivers.
        # Highlighting rows does not count as QR selection.
        by_id={str(r.get("id","")):r for r in self.current}
        rows=[by_id[did] for did in self.checked_ids if did in by_id]
        if not rows:
            return messagebox.showwarning(APP_NAME,"Check one or more drivers first.")

        count=len(rows)
        self.set_status(f"Generating QR for {count} checked driver(s)...")

        def run():
            ok=failed=0
            for r in rows:
                try:
                    self.ensure_driver_qr_cached(r,force=True)
                    ok+=1
                except Exception:
                    failed+=1
            self.after(
                0,
                lambda:self.set_status(
                    f"QR generation finished. Generated {ok}, failed {failed}. "
                    f"Folder: {self.qr_output_dir()}"
                )
            )
        threading.Thread(target=run,daemon=True).start()

    def open_qr_folder(self):
        try:
            p=self.qr_output_dir()
            if sys.platform=="darwin":
                subprocess.Popen(["open",str(p)])
            elif os.name=="nt":
                os.startfile(str(p))
            else:
                subprocess.Popen(["xdg-open",str(p)])
        except Exception as e:
            messagebox.showerror(APP_NAME,str(e))

    def qr_output_dir(self):
        # Keep generated QR cards inside the main Dispatcher folder.
        p=Path(__file__).resolve().parent/"QR"
        p.mkdir(parents=True,exist_ok=True)
        return p

    def _qr_font(self,size):
        from PIL import ImageFont
        candidates=[]
        if sys.platform=="darwin":
            candidates=[
                "/Library/Fonts/Arial Bold.ttf",
                "/System/Library/Fonts/Supplemental/Arial Bold.ttf",
                "/System/Library/Fonts/Supplemental/Helvetica.ttc",
            ]
        elif os.name=="nt":
            candidates=[
                r"C:\Windows\Fonts\arialbd.ttf",
                r"C:\Windows\Fonts\Arial.ttf",
            ]
        candidates += [
            "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
            "/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf",
        ]
        for fp in candidates:
            try:
                if Path(fp).exists():
                    return ImageFont.truetype(fp,size=size)
            except Exception:
                pass
        return ImageFont.load_default()

    def generate_driver_qr(self,r):
        """
        LTS QR card format:
        QR payload = D:<Driver ID>
        White square card, large centered QR, bold driver name, bold Driver ID.
        """
        try:
            import qrcode
            from PIL import Image, ImageDraw
        except Exception as e:
            raise RuntimeError(
                "QR support is not installed. Run INSTALL_WINDOWS.bat again.\n\n"
                + str(e)
            )

        did=str(r.get("id","")).strip()
        name=str(r.get("name","")).strip()
        if not did:
            raise RuntimeError("Driver ID is missing.")

        # Display name without LTS prefix on the QR card.
        display_name=re.sub(r"^\s*LTS\s+","",name,flags=re.I).strip() or name or did

        canvas=Image.new("RGB",(1400,1400),"white")
        draw=ImageDraw.Draw(canvas)

        qr=qrcode.QRCode(
            version=None,
            error_correction=qrcode.constants.ERROR_CORRECT_M,
            box_size=20,
            border=3,
        )
        qr.add_data(f"D:{did}")
        qr.make(fit=True)
        qimg=qr.make_image(fill_color="black",back_color="white").convert("RGB")
        qimg=qimg.resize((760,760),Image.Resampling.NEAREST)
        canvas.paste(qimg,((1400-760)//2,145))

        # Fit long names while keeping the same visual design.
        font_size=76
        while font_size>=42:
            name_font=self._qr_font(font_size)
            bbox=draw.textbbox((0,0),display_name,font=name_font)
            if (bbox[2]-bbox[0])<=1180:
                break
            font_size-=4

        id_font=self._qr_font(62)

        nb=draw.textbbox((0,0),display_name,font=name_font)
        nx=(1400-(nb[2]-nb[0]))//2
        draw.text((nx,1015),display_name,font=name_font,fill="black")

        ib=draw.textbbox((0,0),did,font=id_font)
        ix=(1400-(ib[2]-ib[0]))//2
        draw.text((ix,1135),did,font=id_font,fill="black")

        path=self.qr_output_dir()/f"driver_{did}.png"
        canvas.save(path,format="PNG")
        return path

    def view_qr(self):
        rs=self.selected()
        if len(rs)!=1:
            return messagebox.showwarning(APP_NAME,"Select exactly one driver to view the QR.")
        try:
            p=self.ensure_driver_qr_cached(rs[0])
            if sys.platform=="darwin":
                subprocess.Popen(["open",str(p)])
            elif os.name=="nt":
                os.startfile(str(p))
            else:
                subprocess.Popen(["xdg-open",str(p)])
            self.set_status(f"QR generated for {rs[0]['name']}.")
        except Exception as e:
            messagebox.showerror(APP_NAME,str(e))

    def send_qr_selected(self):
        rows=self.selected()
        if not rows:
            return messagebox.showwarning(APP_NAME,"Tick at least one driver.")
        if not messagebox.askyesno(
            APP_NAME,
            f"Generate and send QR to {len(rows)} checked driver(s) via WhatsApp?"
        ):
            return

        try:
            delay=max(3,float(self.delay.get()))
        except Exception:
            delay=7

        def run():
            sent=failed=0
            for i,r in enumerate(rows):
                try:
                    if driver_is_inactive(r):
                        raise RuntimeError("Driver is Not Active.")
                    phone=normalize_phone(r.get("phone",""),self.cc.get())
                    if not phone:
                        raise RuntimeError("Missing WhatsApp phone.")
                    qrp=self.ensure_driver_qr_cached(r)
                    driver_name=re.sub(r"^\s*LTS\s+","",str(r.get("name","")),flags=re.I).strip()
                    qr_message=(
                        f"Hallo {driver_name} 👋\n\n"
                        "Das ist dein persönlicher LTS QR-Code. "
                        "Er dient zur schnellen Identifikation im LTS-System.\n\n"
                        "Bitte speichere ihn auf deinem Handy und halte ihn bei Bedarf zum Scannen bereit."
                    )
                    self.wa.send(phone,qr_message,[str(qrp)])
                    history_add(r,"WhatsApp","Driver QR","SENT",f"D:{r.get('id','')}",self.follow.get())
                    self.mark(r)
                    sent+=1
                except Exception as e:
                    failed+=1
                    history_add(r,"WhatsApp","Driver QR",history_result_for_exception(e),str(e),self.follow.get())
                if i<len(rows)-1:
                    time.sleep(delay)
            self.set_status(f"QR sending finished. Sent {sent}, failed {failed}.")
            self.after(0,self.history_refresh)
            self.after(0,self.render)

        threading.Thread(target=run,daemon=True).start()

    def call_selected(self):
        rs=self.selected()
        if len(rs)!=1:return messagebox.showwarning(APP_NAME,"Select exactly one driver.")
        self._call(rs[0])

    def _call(self,r):
        p=normalize_phone(r["phone"],self.cc.get())
        if not p:return messagebox.showerror(APP_NAME,"Missing WhatsApp phone.")
        def run():
            try:self.wa.call(p);history_add(r,"WhatsApp","Voice Call","STARTED","",self.follow.get());self.after(0,self.history_refresh)
            except Exception as e:history_add(r,"WhatsApp","Voice Call","FAILED",str(e),self.follow.get());self.error(str(e))
        threading.Thread(target=run,daemon=True).start()

    def call_next(self):
        rs=self.selected()
        if rs:self.call_queue=rs;self.call_i=0
        if not self.call_queue:return messagebox.showwarning(APP_NAME,"Select drivers for call queue.")
        if self.call_i>=len(self.call_queue):self.call_queue=[];self.call_i=0;return messagebox.showinfo(APP_NAME,"Call queue finished.")
        r=self.call_queue[self.call_i];self.call_i+=1;self._call(r)

    def history_refresh(self):
        if not hasattr(self,"ht"):
            return

        self.ht.delete(*self.ht.get_children())

        if not HISTORY_FILE.exists():
            return

        rows=list(csv.DictReader(HISTORY_FILE.open("r",encoding="utf-8-sig",newline="")))
        query=self.history_search.get().strip().casefold() if hasattr(self,"history_search") else ""

        if query:
            rows=[
                r for r in rows
                if any(
                    query in str(r.get(k,"")).casefold()
                    for k in (
                        "Driver ID","Name","Channel","Action",
                        "Result","Detail","Follow-up"
                    )
                )
            ]

        for r in rows[-500:][::-1]:
            self.ht.insert(
                "",
                "end",
                values=(
                    r.get("Timestamp",""),
                    r.get("Driver ID",""),
                    r.get("Name",""),
                    r.get("Channel",""),
                    r.get("Action",""),
                    r.get("Result",""),
                    r.get("Detail",""),
                    r.get("Follow-up",""),
                )
            )

    def on_main_tab_changed(self,event=None):
        if not hasattr(self,"nb") or not hasattr(self,"send_bar"):
            return

        try:
            current=self.nb.nametowidget(self.nb.select())
        except Exception:
            return

        if current is self.dispatch_tab:
            if not self.send_bar.winfo_manager():
                # The send bar was originally packed before the expanding Notebook.
                # After pack_forget(), packing it normally appends it after the
                # Notebook, which can leave no visible space for the bar.  Restore
                # its original packing order explicitly so it always reappears.
                self.send_bar.pack(side="bottom",fill="x",before=self.nb)
                self.send_bar.lift()
                self.update_idletasks()
        else:
            if self.send_bar.winfo_manager():
                self.send_bar.pack_forget()

    def set_status(self,t):self.after(0,lambda:self.status.set(t))
    def error(self,t):self.after(0,lambda:messagebox.showerror(APP_NAME,t))
    def worker(self,fn):
        def r():
            try:fn();self.set_status("Ready.")
            except Exception as e:self.error(str(e))
        threading.Thread(target=r,daemon=True).start()

if __name__=="__main__":
    App().mainloop()
