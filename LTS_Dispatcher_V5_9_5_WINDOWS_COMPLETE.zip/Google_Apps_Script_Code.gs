/**
 * LTS Dispatcher Google Sheets Backend V5.9.2
 *
 * This web app can live in the Dispatcher spreadsheet while the actual driver
 * list lives in a separate Fleet spreadsheet. The Fleet sheet is opened by ID,
 * so its existing Apps Script project does not need to be replaced.
 *
 * Change API_TOKEN below before deployment.
 */

const API_TOKEN = 'CHANGE_THIS_TO_A_LONG_RANDOM_TOKEN';

const CONTACTS_SHEET = 'Contacts';
const DEFAULT_DRIVER_SHEET = 'Drivers';
const HISTORY_SHEET = 'Send History';

const CONTACT_HEADERS = [
  'Driver ID','Name','WhatsApp Phone','Email','Status','Last Contacted','Notes'
];

const FIELD_TO_HEADER = {
  id:'Driver ID',
  name:'Name',
  phone:'WhatsApp Phone',
  email:'Email',
  status:'Status',
  last_contacted:'Last Contacted',
  notes:'Notes'
};

const CONTACT_ALIASES = {
  id:['driver id','driverid','id','fahrer id','fahrer-id'],
  name:['name','driver name','fahrer','fahrer name'],
  phone:['whatsapp phone','phone','mobile','handy','handy nummer','dienst nummer'],
  email:['email','e-mail','e-mail fahrer','fahrer email','email fahrer'],
  status:['status','active','aktiv'],
  last_contacted:['last contacted','letzter kontakt','last contact'],
  notes:['notes','note','notizen','bemerkung','bemerkungen']
};

function doGet(e) {
  return jsonOut({ok:true, service:'LTS Dispatcher Google Sheets Backend'});
}

function doPost(e) {
  try {
    const body = JSON.parse((e.postData && e.postData.contents) || '{}');

    if (!body.token || body.token !== API_TOKEN) {
      return jsonOut({ok:false,error:'Unauthorized: API token is incorrect.'});
    }

    const action = String(body.action || '');
    const driverSpreadsheetId = String(body.driver_spreadsheet_id || '');
    const driverSheetName = String(body.driver_sheet_name || DEFAULT_DRIVER_SHEET);

    if (action === 'ping') {
      return jsonOut({ok:true, spreadsheet:SpreadsheetApp.getActive().getName()});
    }

    if (action === 'getContacts') {
      // Self-healing setup: every normal load verifies the shared driver layout.
      // This means the user never has to manually add Dispatcher columns to Fleet.
      const layout=ensureContactColumns_(driverSpreadsheetId,driverSheetName,true);
      return jsonOut({
        ok:true,
        layout:layoutInfo_(layout),
        contacts:getContacts_(driverSpreadsheetId,driverSheetName)
      });
    }

    if (action === 'syncContactLayout') {
      // Non-destructive automatic configuration. Fleet core columns A:D stay in place;
      // only the Dispatcher communication fields/layout are added or repaired.
      const layout=ensureContactColumns_(driverSpreadsheetId,driverSheetName,true);
      return jsonOut({ok:true,layout:layoutInfo_(layout)});
    }

    if (action === 'migrateContactsToFleet') {
      return jsonOut(Object.assign(
        {ok:true},
        migrateContactsToFleet_(
          String(body.source_sheet_name || CONTACTS_SHEET),
          driverSpreadsheetId,
          driverSheetName
        )
      ));
    }

    if (action === 'addDriver') {
      addDriver_(body.driver || {},driverSpreadsheetId,driverSheetName);
      return jsonOut({ok:true});
    }

    if (action === 'editDriver') {
      editDriver_(
        String(body.original_id || ''),
        body.driver || {},
        driverSpreadsheetId,
        driverSheetName
      );
      return jsonOut({ok:true});
    }

    if (action === 'deleteDriver') {
      deleteDriver_(String(body.driver_id || ''),driverSpreadsheetId,driverSheetName);
      return jsonOut({ok:true});
    }

    if (action === 'updateField') {
      updateField_(
        String(body.driver_id || ''),
        String(body.key || ''),
        body.value,
        driverSpreadsheetId,
        driverSheetName
      );
      return jsonOut({ok:true});
    }

    if (action === 'appendHistory') {
      appendHistory_(body.history || {});
      return jsonOut({ok:true});
    }

    if (action === 'getShifts') {
      return jsonOut({
        ok:true,
        shifts:getShifts_(
          String(body.date || ''),
          String(body.tp_spreadsheet_id || '')
        )
      });
    }

    if (action === 'addShift') {
      addShift_(
        String(body.date || ''),
        String(body.name || ''),
        String(body.shift_text || ''),
        String(body.driver_id || ''),
        String(body.phone || ''),
        String(body.email || ''),
        String(body.tp_spreadsheet_id || '')
      );
      return jsonOut({ok:true});
    }

    if (action === 'editShift') {
      editShift_(
        String(body.date || ''),
        Number(body.row_number || 0),
        String(body.name || ''),
        String(body.shift_text || ''),
        String(body.driver_id || ''),
        String(body.phone || ''),
        String(body.email || ''),
        String(body.tp_spreadsheet_id || '')
      );
      return jsonOut({ok:true});
    }

    if (action === 'deleteShift') {
      deleteShift_(
        String(body.date || ''),
        Number(body.row_number || 0),
        String(body.tp_spreadsheet_id || '')
      );
      return jsonOut({ok:true});
    }

    return jsonOut({ok:false,error:'Unknown action: ' + action});
  } catch (err) {
    return jsonOut({ok:false,error:String(err && err.message ? err.message : err)});
  }
}

function jsonOut(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

function sheet_(name) {
  const ss = SpreadsheetApp.getActive();
  const sh = ss.getSheetByName(name);
  if (!sh) throw new Error('Missing sheet: ' + name);
  return sh;
}

function driverSpreadsheet_(spreadsheetId) {
  const id=String(spreadsheetId || '').trim();
  return id ? SpreadsheetApp.openById(id) : SpreadsheetApp.getActive();
}

function driverSheet_(spreadsheetId,sheetName) {
  const ss=driverSpreadsheet_(spreadsheetId);
  const name=String(sheetName || DEFAULT_DRIVER_SHEET).trim() || DEFAULT_DRIVER_SHEET;
  const sh=ss.getSheetByName(name);
  if (!sh) {
    throw new Error('Driver sheet "' + name + '" was not found in spreadsheet "' + ss.getName() + '".');
  }
  return sh;
}

function normalizeHeader_(value) {
  return String(value || '').trim().toLowerCase().replace(/\s+/g,' ');
}

function headerState_(sh) {
  const lastCol=Math.max(sh.getLastColumn(),1);
  const headers=sh.getRange(1,1,1,lastCol).getDisplayValues()[0];
  const normalized={};
  headers.forEach((h,i)=>{
    const key=normalizeHeader_(h);
    if (key && normalized[key] === undefined) normalized[key]=i+1;
  });
  return {headers:headers,normalized:normalized,lastCol:lastCol};
}

function configureFleetDriverLayout_(sh,cols) {
  // Configure only the Drivers tab. Never clear/reorder data and never touch QR values.
  // Existing Fleet row heights/QR formatting are preserved.
  try {
    if (sh.getFrozenRows() < 1) sh.setFrozenRows(1);
  } catch (e) {}

  // Human-readable Fleet driver status. Existing TRUE/FALSE values are converted
  // to Active / Not Active and column C gets a dropdown for all current/future rows.
  try {
    // IMPORTANT: Fleet used checkbox validation (TRUE/FALSE). Remove that rule
    // before writing text values, otherwise Google Sheets rejects "Active".
    if (sh.getMaxRows() > 1) {
      sh.getRange(2,3,sh.getMaxRows()-1,1).clearDataValidations();
    }

    const lastRow=sh.getLastRow();
    if (lastRow >= 2) {
      const statusRange=sh.getRange(2,3,lastRow-1,1);
      const values=statusRange.getValues().map(r => {
        const raw=r[0];
        if (raw === '' || raw === null) return [''];
        if (raw === true) return ['Active'];
        if (raw === false) return ['Not Active'];
        const key=normalizeHeader_(raw);
        if (['true','1','yes','ja','active','aktiv'].indexOf(key) !== -1) return ['Active'];
        if (['false','0','no','nein','inactive','inaktiv','not active'].indexOf(key) !== -1) return ['Not Active'];
        return [String(raw)];
      });
      statusRange.setValues(values);
    }

    const validation=SpreadsheetApp.newDataValidation()
      .requireValueInList(['Active','Not Active'],true)
      .setAllowInvalid(false)
      .build();
    if (sh.getMaxRows() > 1) {
      sh.getRange(2,3,sh.getMaxRows()-1,1).setDataValidation(validation);
    }
    sh.setColumnWidth(3,110);
    applyDriverStatusColors_(sh);
  } catch (e) {}

  // Keep the familiar Fleet header appearance. Prefer copying the existing QR header
  // formatting to each Dispatcher communication column without imposing a new theme.
  try {
    const source=sh.getRange(1,4);
    ['phone','email','last_contacted','notes'].forEach(key => {
      if (cols[key]) source.copyFormatToRange(sh,cols[key],cols[key],1,1);
    });
  } catch (e) {
    try {
      const used=[cols.phone,cols.email,cols.last_contacted,cols.notes].filter(Boolean);
      used.forEach(col => sh.getRange(1,col)
        .setFontWeight('bold')
        .setBackground('#1769aa')
        .setFontColor('#ffffff')
        .setHorizontalAlignment('center'));
    } catch (_) {}
  }

  // Useful widths for the shared fields. Core Fleet columns are left untouched.
  try {
    if (cols.phone) sh.setColumnWidth(cols.phone,170);
    if (cols.email) sh.setColumnWidth(cols.email,240);
    if (cols.last_contacted) sh.setColumnWidth(cols.last_contacted,165);
    if (cols.notes) sh.setColumnWidth(cols.notes,260);
  } catch (e) {}

  try {
    const dataRows=Math.max(sh.getLastRow()-1,1);
    [cols.phone,cols.email,cols.last_contacted,cols.notes].filter(Boolean).forEach(col => {
      sh.getRange(2,col,dataRows,1).setVerticalAlignment('middle').setWrap(true);
    });
    if (cols.last_contacted) {
      sh.getRange(2,cols.last_contacted,dataRows,1).setNumberFormat('dd.MM.yyyy HH:mm');
    }
  } catch (e) {}

  return {sh:sh,cols:cols};
}

function layoutInfo_(layout) {
  const sh=layout && layout.sh;
  const cols=(layout && layout.cols) || {};
  return {
    spreadsheet:sh ? sh.getParent().getName() : '',
    sheet:sh ? sh.getName() : '',
    columns:cols,
    auto_configured:true
  };
}

function ensureFleetDriverColumns_(sh,createMissing) {
  // FleetControl Drivers is a fixed core layout:
  // A Driver ID | B Name | C Active | D QR Code
  // Dispatcher communication fields are added to the right only.
  const core=['Driver ID','Name','Active','QR Code'];
  core.forEach((header,i)=>{
    const cell=sh.getRange(1,i+1);
    const current=normalizeHeader_(cell.getDisplayValue());
    const acceptable=(
      (i===0 && CONTACT_ALIASES.id.indexOf(current)!==-1) ||
      (i===1 && CONTACT_ALIASES.name.indexOf(current)!==-1) ||
      (i===2 && CONTACT_ALIASES.status.indexOf(current)!==-1) ||
      (i===3 && (current==='qr code' || current==='qr'))
    );
    // Repair blank/accidentally overwritten Fleet headers only; data starts row 2.
    if (!acceptable) cell.setValue(header);
  });

  let state=headerState_(sh);
  const cols={id:1,name:2,status:3};
  const desired={phone:'WhatsApp Phone',email:'Email',last_contacted:'Last Contacted',notes:'Notes'};
  const preferred={phone:5,email:6,last_contacted:7,notes:8};

  Object.keys(desired).forEach(key=>{
    const aliases=CONTACT_ALIASES[key] || [normalizeHeader_(desired[key])];
    let col=0;
    for (let i=0;i<aliases.length;i++) {
      const found=state.normalized[normalizeHeader_(aliases[i])];
      if (found) { col=found; break; }
    }
    if (!col && createMissing) {
      const preferredCol=preferred[key];
      const preferredHeader=normalizeHeader_(sh.getRange(1,preferredCol).getDisplayValue());
      if (!preferredHeader) {
        col=preferredCol;
      } else {
        col=Math.max(sh.getLastColumn()+1,9);
      }
      sh.getRange(1,col).setValue(desired[key]);
      state=headerState_(sh);
    }
    cols[key]=col;
  });

  return configureFleetDriverLayout_(sh,cols);
}


function applyDriverStatusColors_(sh) {
  if (!sh || sh.getMaxRows() < 2) return;

  const statusRange=sh.getRange(2,3,sh.getMaxRows()-1,1);

  try {
    // Remove only older FleetControl status-color rules so repeated setup does
    // not keep adding duplicate conditional-format rules. Other sheet rules stay.
    const kept=(sh.getConditionalFormatRules() || []).filter(rule => {
      try {
        const condition=rule.getBooleanCondition();
        if (!condition) return true;

        const values=condition.getCriteriaValues() || [];
        const target=values.length ? String(values[0] || '').trim().toLowerCase() : '';
        if (target !== 'active' && target !== 'not active') return true;

        const touchesStatus=(rule.getRanges() || []).some(r =>
          r.getColumn() <= 3 && r.getLastColumn() >= 3 && r.getLastRow() >= 2
        );
        return !touchesStatus;
      } catch (e) {
        return true;
      }
    });

    const activeRule=SpreadsheetApp.newConditionalFormatRule()
      .whenTextEqualTo('Active')
      .setBackground('#d9ead3')
      .setFontColor('#137333')
      .setBold(true)
      .setRanges([statusRange])
      .build();

    const inactiveRule=SpreadsheetApp.newConditionalFormatRule()
      .whenTextEqualTo('Not Active')
      .setBackground('#f4cccc')
      .setFontColor('#b31412')
      .setBold(true)
      .setRanges([statusRange])
      .build();

    sh.setConditionalFormatRules(kept.concat([activeRule,inactiveRule]));
  } catch (e) {
    // Fallback: color current rows even if conditional formatting cannot be set.
    try {
      const values=statusRange.getDisplayValues();
      const backgrounds=[];
      const fontColors=[];
      const fontWeights=[];
      values.forEach(r => {
        const v=String(r[0] || '').trim().toLowerCase();
        if (v === 'active') {
          backgrounds.push(['#d9ead3']);
          fontColors.push(['#137333']);
          fontWeights.push(['bold']);
        } else if (v === 'not active') {
          backgrounds.push(['#f4cccc']);
          fontColors.push(['#b31412']);
          fontWeights.push(['bold']);
        } else {
          backgrounds.push([null]);
          fontColors.push([null]);
          fontWeights.push(['normal']);
        }
      });
      statusRange.setBackgrounds(backgrounds);
      statusRange.setFontColors(fontColors);
      statusRange.setFontWeights(fontWeights);
    } catch (_) {}
  }
}

function ensureContactColumns_(spreadsheetId,sheetName,createMissing) {
  const sh=driverSheet_(spreadsheetId,sheetName);

  if (normalizeHeader_(sh.getName()) === 'drivers') {
    return ensureFleetDriverColumns_(sh,createMissing);
  }

  let state=headerState_(sh);
  const cols={};
  let nextCol=state.lastCol+1;

  Object.keys(FIELD_TO_HEADER).forEach(key=>{
    const aliases=CONTACT_ALIASES[key] || [normalizeHeader_(FIELD_TO_HEADER[key])];
    let col=0;
    for (let i=0;i<aliases.length;i++) {
      const found=state.normalized[normalizeHeader_(aliases[i])];
      if (found) { col=found; break; }
    }
    if (!col && createMissing) {
      col=nextCol++;
      sh.getRange(1,col).setValue(FIELD_TO_HEADER[key]);
      state.normalized[normalizeHeader_(FIELD_TO_HEADER[key])]=col;
    }
    cols[key]=col;
  });

  if (!cols.id || !cols.name) {
    throw new Error(
      'Driver sheet needs a Driver ID/ID column and a Name/Fahrer column. ' +
      'Existing extra Fleet columns are allowed.'
    );
  }
  return {sh:sh,cols:cols};
}

function getContacts_(spreadsheetId,sheetName) {
  const sh=driverSheet_(spreadsheetId,sheetName);
  const values=sh.getDataRange().getDisplayValues();
  if (values.length < 2) return [];

  const headers=values[0];
  const out=[];
  for (let r=1;r<values.length;r++) {
    const row=values[r];
    const obj={};
    let any=false;
    headers.forEach((h,i) => {
      const header=String(h || '').trim();
      if (header) {
        obj[header]=row[i] || '';
        if (String(row[i] || '').trim()) any=true;
      }
    });
    if (any) out.push(obj);
  }
  return out;
}

function findDriverRow_(sh,idCol,driverId) {
  const wanted=String(driverId || '').trim().toLowerCase();
  if (!wanted) throw new Error('Driver ID is required.');
  const last=sh.getLastRow();
  if (last < 2) return -1;
  const ids=sh.getRange(2,idCol,last-1,1).getDisplayValues();
  for (let i=0;i<ids.length;i++) {
    if (String(ids[i][0] || '').trim().toLowerCase() === wanted) return i+2;
  }
  return -1;
}

function normalizePhone_(value) {
  let d=String(value || '').replace(/\D/g,'');
  if (d.indexOf('00')===0) d=d.substring(2);
  if (d.indexOf('0')===0) d='43'+d.replace(/^0+/, '');
  return d;
}

function findPhoneRow_(sh,phoneCol,phone) {
  const wanted=normalizePhone_(phone);
  if (!phoneCol || !wanted) return -1;
  const last=sh.getLastRow();
  if (last < 2) return -1;
  const phones=sh.getRange(2,phoneCol,last-1,1).getDisplayValues();
  for (let i=0;i<phones.length;i++) {
    if (normalizePhone_(phones[i][0]) === wanted) return i+2;
  }
  return -1;
}

function driverValue_(driver,key) {
  const v=driver[key];
  return v === undefined || v === null ? '' : String(v);
}

function statusBoolean_(value) {
  const key=normalizeHeader_(value);
  if (['true','1','yes','ja','active','aktiv'].indexOf(key) !== -1) return true;
  if (['false','0','no','nein','inactive','inaktiv','not active'].indexOf(key) !== -1) return false;
  // Dispatcher only offers Active / Not Active. Unknown values default to true
  // rather than writing text into FleetControl's boolean Active column.
  return true;
}

function sheetValueForField_(sh,col,key,value) {
  if (key !== 'status') return value === undefined || value === null ? '' : String(value);

  const normalized=statusBoolean_(value);
  const header=normalizeHeader_(sh.getRange(1,col).getDisplayValue());

  // The shared Fleet Drivers sheet stores human-readable text in column C.
  if (normalizeHeader_(sh.getName()) === 'drivers' && (header === 'active' || header === 'aktiv')) {
    return normalized ? 'Active' : 'Not Active';
  }

  // Keep compatibility with any other sheet that uses a real boolean Active column.
  if (header === 'active' || header === 'aktiv') {
    return normalized;
  }

  return normalized ? 'Active' : 'Not Active';
}

function rowLabel_(sh,row,cols) {
  if (row < 2) return '';
  const id=cols.id ? String(sh.getRange(row,cols.id).getDisplayValue() || '').trim() : '';
  const name=cols.name ? String(sh.getRange(row,cols.name).getDisplayValue() || '').trim() : '';
  return (name || 'Existing driver') + (id ? ' (Driver ID ' + id + ')' : '');
}

function addDriver_(driver,spreadsheetId,sheetName) {
  const x=ensureContactColumns_(spreadsheetId,sheetName,true);
  const sh=x.sh, cols=x.cols;
  const id=driverValue_(driver,'id').trim();
  const name=driverValue_(driver,'name').trim();
  if (!id || !name) throw new Error('Driver ID and Name are required.');

  const duplicateId=findDriverRow_(sh,cols.id,id);
  if (duplicateId !== -1) {
    throw new Error('Driver ID already exists: ' + id + ' — ' + rowLabel_(sh,duplicateId,cols));
  }

  const phone=driverValue_(driver,'phone');
  const duplicatePhone=findPhoneRow_(sh,cols.phone,phone);
  if (duplicatePhone !== -1) {
    throw new Error('This WhatsApp phone is already assigned to ' + rowLabel_(sh,duplicatePhone,cols) + '.');
  }

  const row=Math.max(sh.getLastRow()+1,2);

  // For the shared Fleet Drivers sheet, inherit the previous driver's visual
  // formatting and data validation (especially the Active / Not Active dropdown)
  // without copying any values or QR code content.
  if (normalizeHeader_(sh.getName()) === 'drivers' && row > 2) {
    try {
      const width=Math.max(sh.getLastColumn(),8);
      sh.getRange(row-1,1,1,width).copyFormatToRange(sh,1,width,row,row);
      const validations=sh.getRange(row-1,1,1,width).getDataValidations();
      sh.getRange(row,1,1,width).setDataValidations(validations);
      sh.setRowHeight(row,sh.getRowHeight(row-1));
    } catch (e) {}
  }

  Object.keys(FIELD_TO_HEADER).forEach(key => {
    const col=cols[key];
    if (col) sh.getRange(row,col).setValue(sheetValueForField_(sh,col,key,driver[key]));
  });
  SpreadsheetApp.flush();
}

function editDriver_(originalId,driver,spreadsheetId,sheetName) {
  const x=ensureContactColumns_(spreadsheetId,sheetName,true);
  const sh=x.sh, cols=x.cols;
  const row=findDriverRow_(sh,cols.id,originalId);
  if (row === -1) throw new Error('Driver ID not found: ' + originalId);

  const newId=driverValue_(driver,'id').trim();
  const name=driverValue_(driver,'name').trim();
  if (!newId || !name) throw new Error('Driver ID and Name are required.');

  const duplicateId=findDriverRow_(sh,cols.id,newId);
  if (duplicateId !== -1 && duplicateId !== row) {
    throw new Error('Driver ID already exists: ' + newId + ' — ' + rowLabel_(sh,duplicateId,cols));
  }

  const phone=driverValue_(driver,'phone');
  const duplicatePhone=findPhoneRow_(sh,cols.phone,phone);
  if (duplicatePhone !== -1 && duplicatePhone !== row) {
    throw new Error('This WhatsApp phone is already assigned to ' + rowLabel_(sh,duplicatePhone,cols) + '.');
  }

  Object.keys(FIELD_TO_HEADER).forEach(key => {
    const col=cols[key];
    if (col) sh.getRange(row,col).setValue(sheetValueForField_(sh,col,key,driver[key]));
  });
  SpreadsheetApp.flush();
}

function deleteDriver_(driverId,spreadsheetId,sheetName) {
  const x=ensureContactColumns_(spreadsheetId,sheetName,false);
  const sh=x.sh, cols=x.cols;
  const row=findDriverRow_(sh,cols.id,driverId);
  if (row === -1) throw new Error('Driver ID not found: ' + driverId);
  sh.deleteRow(row);
  SpreadsheetApp.flush();
}

function updateField_(driverId,key,value,spreadsheetId,sheetName) {
  if (!FIELD_TO_HEADER[key]) throw new Error('Unsupported field: ' + key);

  const x=ensureContactColumns_(spreadsheetId,sheetName,true);
  const sh=x.sh, cols=x.cols;
  const row=findDriverRow_(sh,cols.id,driverId);
  if (row === -1) throw new Error('Driver ID not found: ' + driverId);
  if (!cols[key]) throw new Error('Driver sheet has no column for: ' + key);

  sh.getRange(row,cols[key]).setValue(sheetValueForField_(sh,cols[key],key,value));
  SpreadsheetApp.flush();
}

function sourceContactsNormalized_(sourceSheetName) {
  const ss=SpreadsheetApp.getActive();
  const name=String(sourceSheetName || CONTACTS_SHEET).trim() || CONTACTS_SHEET;
  const sh=ss.getSheetByName(name);
  if (!sh) throw new Error('Source Contacts sheet "' + name + '" was not found in the Dispatcher spreadsheet.');

  const values=sh.getDataRange().getDisplayValues();
  if (values.length < 2) return [];
  const headers=values[0].map(normalizeHeader_);

  const colFor=(key)=>{
    const aliases=CONTACT_ALIASES[key] || [];
    for (let i=0;i<aliases.length;i++) {
      const idx=headers.indexOf(normalizeHeader_(aliases[i]));
      if (idx!==-1) return idx;
    }
    return -1;
  };

  const cols={};
  Object.keys(FIELD_TO_HEADER).forEach(key=>cols[key]=colFor(key));
  if (cols.id===-1 || cols.name===-1) {
    throw new Error('Source Contacts sheet needs Driver ID and Name columns.');
  }

  const out=[];
  for (let r=1;r<values.length;r++) {
    const row=values[r];
    const item={};
    Object.keys(cols).forEach(key=>{
      item[key]=cols[key]===-1 ? '' : String(row[cols[key]] || '').trim();
    });
    if (item.id || item.name) out.push(item);
  }
  return out;
}

function migrateContactsToFleet_(sourceSheetName,spreadsheetId,sheetName) {
  const source=sourceContactsNormalized_(sourceSheetName);
  const x=ensureContactColumns_(spreadsheetId,sheetName,true);
  const sh=x.sh, cols=x.cols;

  if (normalizeHeader_(sh.getName()) !== 'drivers') {
    throw new Error('Migration target must be the Fleet Drivers tab. Configured target: ' + sh.getName());
  }

  const idCounts={};
  source.forEach(d=>{
    const id=String(d.id || '').trim().toLowerCase();
    if (id) idCounts[id]=(idCounts[id] || 0)+1;
  });
  const duplicateIds=Object.keys(idCounts).filter(id=>idCounts[id]>1);
  const duplicateSet={};
  duplicateIds.forEach(id=>duplicateSet[id]=true);

  let matched=0, updated=0, missing=0, phoneConflictCount=0;
  const missingIds=[];
  const phoneConflicts=[];

  source.forEach(driver=>{
    const id=String(driver.id || '').trim();
    if (!id || duplicateSet[id.toLowerCase()]) return;

    const row=findDriverRow_(sh,cols.id,id);
    if (row===-1) {
      missing++;
      if (missingIds.length<50) missingIds.push(id);
      return;
    }
    matched++;
    let changed=false;

    // Driver ID is the migration key and is never modified here.
    if (driver.name && cols.name) {
      const current=String(sh.getRange(row,cols.name).getDisplayValue() || '').trim();
      if (current!==driver.name) {
        sh.getRange(row,cols.name).setValue(driver.name);
        changed=true;
      }
    }

    if (driver.status && cols.status) {
      const wanted=sheetValueForField_(sh,cols.status,'status',driver.status);
      const current=sh.getRange(row,cols.status).getValue();
      if (String(current)!==String(wanted)) {
        sh.getRange(row,cols.status).setValue(wanted);
        changed=true;
      }
    }

    if (driver.phone && cols.phone) {
      const other=findPhoneRow_(sh,cols.phone,driver.phone);
      if (other!==-1 && other!==row) {
        phoneConflictCount++;
        if (phoneConflicts.length<30) {
          phoneConflicts.push(id + ' → ' + rowLabel_(sh,other,cols));
        }
      } else {
        const current=String(sh.getRange(row,cols.phone).getDisplayValue() || '').trim();
        if (normalizePhone_(current)!==normalizePhone_(driver.phone)) {
          sh.getRange(row,cols.phone).setValue(driver.phone);
          changed=true;
        }
      }
    }

    ['email','last_contacted','notes'].forEach(key=>{
      if (!driver[key] || !cols[key]) return;
      const current=String(sh.getRange(row,cols[key]).getDisplayValue() || '').trim();
      if (current!==driver[key]) {
        sh.getRange(row,cols[key]).setValue(driver[key]);
        changed=true;
      }
    });

    if (changed) updated++;
  });

  SpreadsheetApp.flush();
  return {
    source_count:source.length,
    matched:matched,
    updated:updated,
    missing_count:missing,
    missing_ids:missingIds,
    duplicate_source_count:duplicateIds.length,
    duplicate_source_ids:duplicateIds.slice(0,50),
    phone_conflict_count:phoneConflictCount,
    phone_conflicts:phoneConflicts,
    qr_cells_changed:0,
    target_spreadsheet:sh.getParent().getName(),
    target_sheet:sh.getName()
  };
}

function appendHistory_(h) {
  const sh=sheet_(HISTORY_SHEET);
  const headers=['Timestamp','Driver ID','Name','Channel','Action','Result','Detail','Follow-up'];

  if (sh.getLastRow() === 0) {
    sh.getRange(1,1,1,headers.length).setValues([headers]);
  }

  const map={};
  headers.forEach(k => map[k] = h[k] === undefined || h[k] === null ? '' : h[k]);
  sh.appendRow(headers.map(k => map[k]));
}


/* TP LISTE DAILY SHEETS
   Sheet: DD.MM.YYYY
   B = SCHICHT
   C = NAME
   Data starts row 4
*/

function tpSheetName_(isoDate) {
  const m=String(isoDate || '').match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!m) throw new Error('Invalid date. Expected YYYY-MM-DD.');
  return m[3] + '.' + m[2] + '.' + m[1];
}

function tpSpreadsheet_(spreadsheetId) {
  const id=String(spreadsheetId || '').trim();
  if (id) {
    return SpreadsheetApp.openById(id);
  }
  return SpreadsheetApp.getActive();
}

function tpSheet_(isoDate, spreadsheetId) {
  const name=tpSheetName_(isoDate);
  const ss=tpSpreadsheet_(spreadsheetId);
  const sh=ss.getSheetByName(name);
  if (!sh) {
    throw new Error(
      'No daily TP sheet "' + name + '" exists in spreadsheet "' + ss.getName() + '".'
    );
  }
  return sh;
}

function shiftStartMinutes_(shiftText) {
  const m=String(shiftText || '').match(/([01]?\d|2[0-3]):([0-5]\d)/);
  if (!m) return 999999;
  return Number(m[1])*60 + Number(m[2]);
}

function ensureTpIdentityColumns_(sh) {
  // X/Y/Z are hidden helper columns used only by LTS Dispatcher.
  // Visible TP layout (including B=SCHICHT and C=NAME) stays unchanged.
  const needed=26;
  if (sh.getMaxColumns() < needed) {
    sh.insertColumnsAfter(sh.getMaxColumns(), needed-sh.getMaxColumns());
  }

  sh.getRange(1,24).setValue('LTS Driver ID');
  sh.getRange(1,25).setValue('LTS Phone');
  sh.getRange(1,26).setValue('LTS Email');

  try {
    sh.hideColumns(24,3);
  } catch (e) {}
}

function getShifts_(isoDate, spreadsheetId) {
  const sh=tpSheet_(isoDate, spreadsheetId);
  const last=Math.max(sh.getLastRow(),3);
  if (last < 4) return [];
  ensureTpIdentityColumns_(sh);
  const values=sh.getRange(4,2,last-3,25).getDisplayValues();
  const out=[];
  values.forEach((row,i)=>{
    const shiftText=String(row[0] || '').trim();   // B
    const name=String(row[1] || '').trim();        // C
    const driverId=String(row[22] || '').trim();   // X
    const phone=String(row[23] || '').trim();      // Y
    const email=String(row[24] || '').trim();      // Z
    if (name) out.push({
      row_number:i+4,
      shift_text:shiftText,
      name:name,
      driver_id:driverId,
      phone:phone,
      email:email
    });
  });
  out.sort((a,b)=>{
    const d=shiftStartMinutes_(a.shift_text)-shiftStartMinutes_(b.shift_text);
    return d !== 0 ? d : a.name.localeCompare(b.name);
  });
  return out;
}

function findShiftInsertRow_(sh,shiftText) {
  const mins=shiftStartMinutes_(shiftText);
  const last=Math.max(sh.getLastRow(),3);
  for (let row=4;row<=last;row++) {
    const existing=String(sh.getRange(row,2).getDisplayValue() || '').trim();
    const name=String(sh.getRange(row,3).getDisplayValue() || '').trim();
    if (!existing && !name) continue;
    if (mins < shiftStartMinutes_(existing)) return row;
  }
  return Math.max(last+1,4);
}

function addShift_(isoDate,name,shiftText,driverId,phone,email,spreadsheetId) {
  if (!name || !shiftText) throw new Error('Driver and shift are required.');
  const sh=tpSheet_(isoDate, spreadsheetId);
  ensureTpIdentityColumns_(sh);
  const row=findShiftInsertRow_(sh,shiftText);
  sh.insertRowBefore(row);
  sh.getRange(row,2).setValue(shiftText);
  sh.getRange(row,3).setValue(name);
  sh.getRange(row,24).setValue(driverId);
  sh.getRange(row,25).setValue(phone);
  sh.getRange(row,26).setValue(email);
}

function editShift_(isoDate,rowNumber,name,shiftText,driverId,phone,email,spreadsheetId) {
  if (rowNumber < 4) throw new Error('Invalid TP-list row.');
  const sh=tpSheet_(isoDate, spreadsheetId);
  ensureTpIdentityColumns_(sh);
  if (rowNumber > sh.getLastRow()) throw new Error('TP-list row does not exist.');

  const lastCol=Math.max(sh.getLastColumn(),26);
  const values=sh.getRange(rowNumber,1,1,lastCol).getValues()[0];
  values[1]=shiftText;
  values[2]=name;
  values[23]=driverId;
  values[24]=phone;
  values[25]=email;

  sh.deleteRow(rowNumber);
  const target=findShiftInsertRow_(sh,shiftText);
  sh.insertRowBefore(target);
  sh.getRange(target,1,1,lastCol).setValues([values]);
}

function deleteShift_(isoDate,rowNumber,spreadsheetId) {
  if (rowNumber < 4) throw new Error('Invalid TP-list row.');
  const sh=tpSheet_(isoDate, spreadsheetId);
  if (rowNumber > sh.getLastRow()) throw new Error('TP-list row does not exist.');
  sh.deleteRow(rowNumber);
}
