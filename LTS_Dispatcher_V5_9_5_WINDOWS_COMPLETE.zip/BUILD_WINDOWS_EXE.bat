@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  set "PY=py -3"
) else (
  set "PY=python"
)
%PY% -m pip install pyinstaller
if errorlevel 1 goto :fail
%PY% -m PyInstaller --noconfirm --clean --onefile --windowed --name "LTS_Dispatcher" ^
  --hidden-import=win32com.client --hidden-import=pythoncom --collect-all pywinauto ^
  "LTS_Dispatcher_Windows.py"
if errorlevel 1 goto :fail
echo.
echo Build complete.
echo EXE: dist\LTS_Dispatcher.exe
echo.
pause
exit /b 0
:fail
echo.
echo EXE build failed. Check the error above.
pause
exit /b 1
