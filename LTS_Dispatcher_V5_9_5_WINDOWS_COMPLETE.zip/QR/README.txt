Generated driver QR codes are saved in this folder by LTS Dispatcher.
