LTS Dispatcher V5.9.5 - WINDOWS

QUICK START
1. Install Python 3.11+ from python.org. During setup tick "Add python.exe to PATH".
2. Install WhatsApp Desktop from Microsoft Store and sign in.
3. Double-click INSTALL_WINDOWS.bat once.
4. Double-click START_WINDOWS.bat.
5. Your Google Sheets / FleetControl setup is the same as the Mac version.

EMAIL
- Windows email sending uses classic Microsoft Outlook desktop through the local Outlook profile.
- Open Outlook and sign in before using TEST EMAIL.

WHATSAPP
- WhatsApp sending uses the official whatsapp:// link to open the driver chat and Windows UI Automation to paste/send.
- Invalid / non-WhatsApp numbers are logged as NO WHATSAPP and the batch continues when WhatsApp exposes the rejection dialog to Windows UI Automation.
- Keep WhatsApp Desktop installed, signed in, and not running as Administrator. Run Dispatcher at the same privilege level.

BULK SEND
- Live progress remains: Done / Sent / No WhatsApp / Failed / Left / ETA.

OPTIONAL EXE
- Double-click BUILD_WINDOWS_EXE.bat.
- When finished, use dist\LTS_Dispatcher.exe.

GOOGLE / FLEET
- No separate Windows backend is required. Use the same Google_Apps_Script_Code.gs and FleetControl files included in this package.
