@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 "LTS_Dispatcher_Windows.py"
) else (
  python "LTS_Dispatcher_Windows.py"
)
if errorlevel 1 (
  echo.
  echo LTS Dispatcher stopped with an error.
  echo Run INSTALL_WINDOWS.bat first if needed.
  echo.
  pause
)
